import {
  EmergencyCategory,
  IGuidanceSnapshot,
  IncidentSeverity,
} from '../models/Incident.js';
import { CAMPUS_LOCATIONS } from '../config/campusData.js';

export interface TriageInput {
  emergencyType: EmergencyCategory;
  severity: IncidentSeverity;
  description: string;
  locationNodeId?: string;
  isPanicMode?: boolean;
  timestamp?: Date;
}

export interface TriageResult {
  riskScore: number;
  confidence: number;
  aiAdjustedSeverity: IncidentSeverity;
  detectedSignals: string[];
  recommendedUnit: string;
  routingTier: 1 | 2 | 3;
  reasoning: string;
  guidance: IGuidanceSnapshot;
}

const SEVERITY_BASE: Record<IncidentSeverity, number> = {
  Low: 25,
  Medium: 50,
  High: 76,
  Critical: 92,
};

const CRITICAL_KEYWORDS: Array<{ pattern: RegExp; signal: string; boost: number; floorSeverity?: IncidentSeverity }> = [
  { pattern: /\b(unconscious|not breathing|cardiac|seizure|choking|overdose)\b/i, signal: 'Life-threatening medical symptom', boost: 28, floorSeverity: 'Critical' },
  { pattern: /\b(bleeding|blood|fracture|chest pain|fainted|collapsed|anaphylaxis)\b/i, signal: 'Acute medical trauma', boost: 20, floorSeverity: 'High' },
  { pattern: /\b(weapon|knife|gun|assault|attack|intruder|break-in|fire|smoke|explosion)\b/i, signal: 'Active physical threat / hazard', boost: 30, floorSeverity: 'Critical' },
  { pattern: /\b(followed|stalking|harass|trapped|locked in|unsafe|threatened)\b/i, signal: 'Personal safety threat indicator', boost: 18, floorSeverity: 'High' },
  { pattern: /\b(suicide|self-harm|end my life|kill myself|hopeless|panic attack)\b/i, signal: 'Acute mental health crisis', boost: 26, floorSeverity: 'Critical' },
  { pattern: /\b(power outage|gas leak|water burst|short circuit|sparking|elevator stuck)\b/i, signal: 'Critical hostel infrastructure hazard', boost: 16, floorSeverity: 'High' },
  { pattern: /\b(dark|alone|dead battery|phone dying|lost|disoriented|injured)\b/i, signal: 'Late-night vulnerability factor', boost: 10 },
];

const SEVERITY_ORDER: IncidentSeverity[] = ['Low', 'Medium', 'High', 'Critical'];

function maxSeverity(a: IncidentSeverity, b: IncidentSeverity): IncidentSeverity {
  return SEVERITY_ORDER.indexOf(a) >= SEVERITY_ORDER.indexOf(b) ? a : b;
}

export function getGuidanceForCategory(
  category: EmergencyCategory,
  severity: IncidentSeverity
): IGuidanceSnapshot {
  const baseEscalation = [
    {
      level: 1,
      targetRole:
        category === 'Medical Emergency' || category === 'Mental Health'
          ? '24/7 Campus Medical & Crisis Triage'
          : 'Night Patrol Desk & Hostel Warden',
      slaSeconds: severity === 'Critical' ? 60 : severity === 'High' ? 120 : 240,
      action: 'Instant SMS, WhatsApp & Live Console Alert Dispatch',
    },
    {
      level: 2,
      targetRole: 'Chief Security Commander & Rapid Response Unit',
      slaSeconds: severity === 'Critical' ? 120 : 240,
      action: 'Auto-escalation if unacknowledged or high-risk triage',
    },
    {
      level: 3,
      targetRole: 'Dean On-Call & External EMS / 911 Bridge',
      slaSeconds: 360,
      action: 'Executive crisis override & municipal emergency handoff',
    },
  ];

  const catalog: Record<EmergencyCategory, Omit<IGuidanceSnapshot, 'escalationFlow'>> = {
    'Medical Emergency': {
      recommendedActions: [
        'Stay still and keep your phone line open for the campus paramedic callback.',
        'If safe, unlock your room door or move toward the nearest ground-floor lobby.',
        'Do not attempt to walk alone to the clinic if experiencing dizziness, chest pain, or bleeding.',
      ],
      emergencySteps: [
        'Verify airway and breathing; place person in recovery position if unconscious but breathing.',
        'Apply firm, continuous pressure with clean cloth if there is active bleeding.',
        'Have someone meet the Campus Ambulance at the nearest building entrance or turn on corridor lights.',
        'Keep student ID and known allergy/medication info ready for paramedics.',
      ],
      contactSuggestions: [
        { name: 'Campus 24/7 Urgent Care & Ambulance', role: 'On-Campus Medical Dispatch', phone: '+1-555-0911', available24x7: true, priority: 'primary' },
        { name: 'Campus Security Rapid Patrol', role: 'Escort & Door Access', phone: '+1-555-0999', available24x7: true, priority: 'secondary' },
        { name: 'Municipal EMS / 911', role: 'External Trauma Service', phone: '911', available24x7: true, priority: 'external' },
      ],
    },
    'Security Emergency': {
      recommendedActions: [
        'Move immediately to a locked, well-lit interior room or 24/7 staffed building.',
        'Silence your phone ringer if hiding; keep screen brightness low.',
        'Do not confront suspicious individuals directly—let armed/trained campus patrol intercept.',
      ],
      emergencySteps: [
        'Lock and barricade doors if an active threat is nearby.',
        'Note clothing, direction of travel, or vehicle details only from a safe vantage point.',
        'If near a Blue-Light Emergency Pole, press the red beacon button for instant CCTV lock-on.',
        'Await verified badge identification before opening any secured door.',
      ],
      contactSuggestions: [
        { name: 'Campus Security Command HQ', role: '24/7 Armed & Mobile Patrol', phone: '+1-555-0999', available24x7: true, priority: 'primary' },
        { name: 'Night Patrol Supervisor', role: 'Zone Rapid Intercept', phone: '+1-555-0199', available24x7: true, priority: 'secondary' },
        { name: 'Local Police Emergency', role: 'Municipal Law Enforcement', phone: '911', available24x7: true, priority: 'external' },
      ],
    },
    'Personal Safety': {
      recommendedActions: [
        'Head toward the nearest Lit Safe-Walk Corridor, Central Library, or staffed Hostel Desk.',
        'Stay on the phone with a trusted friend or the 24/7 Safe-Walk dispatcher while moving.',
        'Trust your instincts—request an immediate motorized security escort rather than walking alone.',
      ],
      emergencySteps: [
        'Move to a populated or CCTV-monitored hub (Library Atrium, Student Union, Security Booth).',
        'Enable live GPS sharing in the app so Patrol Unit Alpha can track your exact path.',
        'Avoid shortcuts through unlit trails, parking lots, or closed academic wings.',
        'Wait inside the safe point until the dispatched officer verifies your incident code.',
      ],
      contactSuggestions: [
        { name: '24/7 Safe-Walk Escort Dispatch', role: 'Campus Safety Shuttle & Escort', phone: '+1-555-0955', available24x7: true, priority: 'primary' },
        { name: 'Campus Security Command HQ', role: 'Immediate Patrol Response', phone: '+1-555-0999', available24x7: true, priority: 'secondary' },
        { name: 'Title IX & Student Advocacy On-Call', role: 'Confidential Support', phone: '+1-555-0820', available24x7: true, priority: 'external' },
      ],
    },
    'Mental Health': {
      recommendedActions: [
        'You are not alone—our 2 A.M. crisis counselors are awake, confidential, and ready to listen.',
        'Move to a quiet, comfortable space where you feel physically safe.',
        'Try the 4-4-4-4 box breathing exercise on the Mental Health Support page while awaiting callback.',
      ],
      emergencySteps: [
        'Take three slow breaths: inhale 4 seconds, hold 4 seconds, exhale 6 seconds.',
        'Remove or distance yourself from anything that could cause immediate harm.',
        'Keep your phone nearby; a trained campus counselor will reach out within 2 minutes.',
        'If you prefer, request an anonymous text/voice check-in or ask a Resident Advisor to sit with you.',
      ],
      contactSuggestions: [
        { name: 'Campus 24/7 Crisis Counselor', role: 'Confidential Psychological Support', phone: '+1-555-0800', available24x7: true, priority: 'primary' },
        { name: 'Campus Medical Triage Nurse', role: 'On-Campus Wellness Clinic', phone: '+1-555-0911', available24x7: true, priority: 'secondary' },
        { name: '988 Suicide & Crisis Lifeline', role: 'National 24/7 Free Confidential Line', phone: '988', available24x7: true, priority: 'external' },
      ],
    },
    'Hostel Problems': {
      recommendedActions: [
        'Report electrical sparks, gas odors, flooding, or broken exterior locks as High/Critical priority.',
        'If locked out after midnight, remain inside the hostel vestibule or nearest lit security desk.',
        'Do not attempt DIY repairs on exposed wiring, HVAC panels, or elevator doors.',
      ],
      emergencySteps: [
        'For gas smell or burning odor: evacuate the room immediately, do not flip light switches, alert neighbors.',
        'For water leaks: unplug floor electronics if safe and shut off local valve if accessible.',
        'For lockouts or access-card failure: keep your student ID ready for the Night Warden.',
        'For elevator entrapment: press the cab alarm button and stay inside; patrol & facilities are en route.',
      ],
      contactSuggestions: [
        { name: 'On-Duty Hostel Night Warden', role: 'Residential Hall Operations', phone: '+1-555-0101', available24x7: true, priority: 'primary' },
        { name: '24/7 Facilities & Maintenance Rapid Team', role: 'Utilities, Locks & Elevators', phone: '+1-555-0444', available24x7: true, priority: 'secondary' },
        { name: 'Campus Security Command HQ', role: 'Master Key & Emergency Access', phone: '+1-555-0999', available24x7: true, priority: 'secondary' },
      ],
    },
    'Lost on Campus': {
      recommendedActions: [
        'Stop near the closest landmark, building sign, or illuminated walkway rather than wandering further.',
        'Look around for a glowing Blue-Light Emergency Pole or campus wayfinding totem.',
        'A Safe-Walk patrol cart can pick you up from your GPS pin and drop you at your hostel.',
      ],
      emergencySteps: [
        'Stay in a well-lit area with visible building signage or road markings.',
        'Check the Interactive Campus Map for the nearest 24/7 Safe Hub (Central Library or Student Union).',
        'Keep GPS active and share any visible building code (e.g., ENG-04, LIB-01) in your report.',
        'Wait for the campus shuttle or security golf-cart escort.',
      ],
      contactSuggestions: [
        { name: '24/7 Safe-Walk Shuttle & Escort', role: 'Campus Navigation & Pickup', phone: '+1-555-0955', available24x7: true, priority: 'primary' },
        { name: 'Campus Security Dispatch', role: 'GPS Locate & Patrol Pickup', phone: '+1-555-0999', available24x7: true, priority: 'secondary' },
      ],
    },
    'Other Emergency': {
      recommendedActions: [
        'Ensure your immediate physical safety first before documenting additional details.',
        'Stay near a well-lit campus landmark and keep your contact number reachable.',
        'Our central dispatch officer will triage your request and route the right specialist unit.',
      ],
      emergencySteps: [
        'Move out of traffic, hazards, or isolated blind spots.',
        'Provide clear details on people involved, exact floor/room, and immediate risks.',
        'Follow dispatcher instructions when contacted by phone or WhatsApp.',
      ],
      contactSuggestions: [
        { name: 'Campus Security Command HQ', role: 'Central 24/7 Triage Desk', phone: '+1-555-0999', available24x7: true, priority: 'primary' },
        { name: 'Student Affairs On-Call Officer', role: 'General Late-Night Assistance', phone: '+1-555-0700', available24x7: true, priority: 'secondary' },
      ],
    },
  };

  return {
    ...catalog[category],
    escalationFlow: baseEscalation,
  };
}

export function evaluateEmergencyTriage(input: TriageInput): TriageResult {
  const ts = input.timestamp || new Date();
  const hour = ts.getHours();
  const isLateNightWindow = hour >= 23 || hour < 6;

  let score = SEVERITY_BASE[input.severity];
  let adjustedSeverity: IncidentSeverity = input.severity;
  const detectedSignals: string[] = [];

  if (input.isPanicMode) {
    score = Math.max(score, 96);
    adjustedSeverity = 'Critical';
    detectedSignals.push('One-Click Panic Mode Activated');
  }

  for (const rule of CRITICAL_KEYWORDS) {
    if (rule.pattern.test(input.description)) {
      score += rule.boost;
      detectedSignals.push(rule.signal);
      if (rule.floorSeverity) {
        adjustedSeverity = maxSeverity(adjustedSeverity, rule.floorSeverity);
      }
    }
  }

  if (isLateNightWindow) {
    score += 7;
    detectedSignals.push('Late-night vulnerability window (23:00–06:00)');
  }

  const node = CAMPUS_LOCATIONS.find((n) => n.id === input.locationNodeId);
  if (node && node.riskWeight > 1.1) {
    score = Math.round(score * node.riskWeight);
    detectedSignals.push(`High-isolation campus zone (${node.zone})`);
  }

  if (
    input.emergencyType === 'Medical Emergency' ||
    input.emergencyType === 'Security Emergency'
  ) {
    score += 6;
  }

  const clampedScore = Math.min(100, Math.max(10, Math.round(score)));

  if (clampedScore >= 88) {
    adjustedSeverity = 'Critical';
  } else if (clampedScore >= 70) {
    adjustedSeverity = maxSeverity(adjustedSeverity, 'High');
  }

  let recommendedUnit = 'Patrol Unit Alpha (Mobile Security)';
  if (input.emergencyType === 'Medical Emergency') {
    recommendedUnit =
      adjustedSeverity === 'Critical'
        ? 'Campus Ambulance + Trauma Paramedic Team'
        : '24/7 Urgent Care Rapid Medic';
  } else if (input.emergencyType === 'Mental Health') {
    recommendedUnit = 'On-Call Crisis Counselor + Wellness Support';
  } else if (input.emergencyType === 'Hostel Problems') {
    recommendedUnit =
      adjustedSeverity === 'Critical' || adjustedSeverity === 'High'
        ? 'Night Warden + Emergency Facilities Crew'
        : 'Residential Hall Duty Warden';
  } else if (input.emergencyType === 'Lost on Campus') {
    recommendedUnit = 'Safe-Walk Electric Shuttle #2';
  } else if (input.emergencyType === 'Security Emergency') {
    recommendedUnit =
      adjustedSeverity === 'Critical'
        ? 'Armed Patrol Unit + Security Commander'
        : 'Zone Security Patrol Unit';
  }

  const routingTier: 1 | 2 | 3 =
    input.isPanicMode || adjustedSeverity === 'Critical'
      ? 2
      : 1;

  const reasoning =
    detectedSignals.length > 0
      ? `Computed risk score ${clampedScore}/100 based on ${detectedSignals.join('; ')}. Routed to ${recommendedUnit} at Tier ${routingTier}.`
      : `Standard triage profile (${clampedScore}/100) for ${input.emergencyType} (${adjustedSeverity}). Routed to ${recommendedUnit}.`;

  return {
    riskScore: clampedScore,
    confidence: detectedSignals.length > 0 ? 0.94 : 0.87,
    aiAdjustedSeverity: adjustedSeverity,
    detectedSignals,
    recommendedUnit,
    routingTier,
    reasoning,
    guidance: getGuidanceForCategory(input.emergencyType, adjustedSeverity),
  };
}
