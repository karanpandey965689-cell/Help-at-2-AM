'use client';

import React, { useEffect, useState } from 'react';
import {
  MapPin,
  ShieldCheck,
  Lightbulb,
  Bus,
  PhoneCall,
  Radio,
} from 'lucide-react';
import { apiRequest } from '@/lib/api';
import {
  CampusLocationNode,
  ReadinessMetrics,
  SafeWalkCorridor,
} from '@/lib/types';
import { CampusMap } from '@/components/map/CampusMap';
import { ReadinessGauge } from '@/components/emergency/ReadinessGauge';

export default function CampusSafetyPage() {
  const [locations, setLocations] = useState<CampusLocationNode[]>([]);
  const [corridors, setCorridors] = useState<SafeWalkCorridor[]>([]);
  const [readiness, setReadiness] = useState<ReadinessMetrics | null>(null);

  useEffect(() => {
    apiRequest<{
      locations: CampusLocationNode[];
      safeWalkCorridors: SafeWalkCorridor[];
    }>('/campus/locations')
      .then((res) => {
        setLocations(res.locations);
        setCorridors(res.safeWalkCorridors);
      })
      .catch(() => {});

    apiRequest<ReadinessMetrics>('/campus/readiness')
      .then(setReadiness)
      .catch(() => {});
  }, []);

  const blueLights = locations.filter((l) => l.type === 'blue_light');
  const hubs24x7 = locations.filter((l) => l.open24x7);

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 space-y-8">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
        <div className="lg:col-span-7 space-y-2">
          <div className="inline-flex items-center gap-2 font-mono text-xs uppercase tracking-wider text-cyan-400">
            <ShieldCheck className="h-4 w-4" />
            Campus Safety &amp; Late-Night Awareness Hub
          </div>
          <h1 className="text-3xl font-black text-white">
            Safe-Walk Corridors, Blue-Light Poles &amp; 24/7 Safe Havens
          </h1>
          <p className="text-sm text-slate-300">
            Explore well-lit campus paths, active security kiosks, emergency intercom poles, and late-night shuttle pickup zones.
          </p>
        </div>
        <div className="lg:col-span-5">
          <ReadinessGauge readiness={readiness} />
        </div>
      </div>

      {/* Live Campus Safety Map */}
      <CampusMap
        locations={locations}
        safeCorridors={corridors}
        heightClass="h-[430px]"
      />

      {/* Info Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        <div className="glass-panel rounded-2xl p-5 space-y-3">
          <div className="flex items-center gap-2 text-sm font-bold text-white">
            <Lightbulb className="h-4 w-4 text-cyan-400" />
            Lit Safe-Walk Corridors
          </div>
          <div className="space-y-2.5">
            {corridors.map((c) => (
              <div
                key={c.id}
                className="rounded-xl border border-slate-800 bg-slate-900/70 p-3 text-xs"
              >
                <p className="font-bold text-white">{c.name}</p>
                <p className="text-emerald-300 font-mono text-[11px] mt-1">
                  Status: {c.lightingStatus}
                </p>
              </div>
            ))}
          </div>
        </div>

        <div className="glass-panel rounded-2xl p-5 space-y-3">
          <div className="flex items-center gap-2 text-sm font-bold text-white">
            <Radio className="h-4 w-4 text-blue-400" />
            Blue-Light Emergency Poles
          </div>
          <div className="space-y-2.5">
            {blueLights.map((b) => (
              <div
                key={b.id}
                className="rounded-xl border border-slate-800 bg-slate-900/70 p-3 text-xs"
              >
                <p className="font-bold text-white">{b.name}</p>
                <p className="text-slate-400 mt-0.5">{b.zone}</p>
                <p className="text-cyan-300 font-mono text-[11px] mt-1">
                  {b.nearestSafePoint}
                </p>
              </div>
            ))}
          </div>
        </div>

        <div className="glass-panel rounded-2xl p-5 space-y-3">
          <div className="flex items-center gap-2 text-sm font-bold text-white">
            <Bus className="h-4 w-4 text-amber-400" />
            2 A.M. Night Shuttle &amp; Escort
          </div>
          <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-3.5 text-xs space-y-2">
            <p className="text-slate-300">
              Electric Safe-Walk shuttles loop every <strong>12 minutes</strong> between Central Library, Student Union, and all 4 Residential Halls from 11:00 PM to 5:30 AM.
            </p>
            <a
              href="tel:+15550955"
              className="inline-flex items-center gap-1.5 rounded-lg bg-amber-500/20 border border-amber-500/40 px-3 py-1.5 font-mono text-xs font-bold text-amber-200"
            >
              <PhoneCall className="h-3.5 w-3.5" />
              Request Escort: +1-555-0955
            </a>
          </div>

          <div className="pt-2">
            <p className="text-xs font-bold text-white mb-2 flex items-center gap-1.5">
              <MapPin className="h-3.5 w-3.5 text-emerald-400" />
              24/7 Open Campus Safe Havens ({hubs24x7.length})
            </p>
            <div className="max-h-36 overflow-y-auto space-y-1.5 pr-1">
              {hubs24x7.map((hub) => (
                <div
                  key={hub.id}
                  className="flex items-center justify-between text-[11px] text-slate-300 border-b border-slate-800/60 pb-1"
                >
                  <span className="truncate">{hub.name}</span>
                  <span className="font-mono text-emerald-400 shrink-0 ml-2">
                    {hub.code}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
