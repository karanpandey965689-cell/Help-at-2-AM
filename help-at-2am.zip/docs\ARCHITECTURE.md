# System, Database, API & Notification Architecture — Help at 2 A.M.

## 1. High-Level Service Architecture

```
+---------------------------+        HTTPS / SSE        +------------------------------+
|  Next.js 15 Web App       | <-----------------------> |  Express + TypeScript API    |
|  - Landing & Emergency UI |                           |  - JWT Auth & RBAC           |
|  - Panic Mode Beacon      |                           |  - AI Decision Engine        |
|  - OSM / Leaflet Maps     |                           |  - SSE Live Event Stream     |
|  - Admin Operations Hub   |                           |  - Escalation Watchdog       |
+---------------------------+                           +--------------+---------------+
                                                                       |
                    +--------------------------------------------------+--------------------+
                    |                                                  |                    |
                    v                                                  v                    v
          +---------+---------+                           +------------+--------+   +-------+--------+
          |  MongoDB 7.0      |                           | Notification Router |   | Readiness &    |
          |  - users          |                           | - Twilio SMS        |   | Analytics      |
          |  - incidents      |                           | - WhatsApp API      |   | Aggregator     |
          |  - adminsettings  |                           | - SMTP Email        |   +----------------+
          |  - notificationlogs                           +---------------------+
          +-------------------+
```

## 2. Database Structure (MongoDB / Mongoose)

### `users`
- `name`, `email` (unique), `passwordHash` (bcrypt), `role` (`student` | `responder` | `admin` | `super_admin`)
- `studentId`, `phone`, `hostel`, `department`, `emergencyContactName`, `emergencyContactPhone`
- `onDuty`, `responderUnit`
- Index: `{ role: 1, onDuty: 1 }`

### `incidents`
- `incidentCode` (unique, e.g. `2AM-8841-01`), `reporterId`, `reporterName`, `isAnonymous`, `isPanicMode`
- `emergencyType` (7 categories), `severity`, `aiAdjustedSeverity`, `status` (`pending` | `active` | `escalated` | `resolved`)
- `description`, `contactNumber`
- `location`: `{ method: 'map'|'hostel'|'building'|'gps', label, zone, nodeId, floorOrRoom, coordinates: { lat, lng }, gpsAccuracyMeters }`
- `aiTriage`: `{ riskScore, confidence, detectedSignals[], recommendedUnit, routingTier, reasoning }`
- `guidance`: `{ recommendedActions[], emergencySteps[], contactSuggestions[], escalationFlow[] }`
- `escalation`: `{ currentLevel (1|2|3), maxLevel, nextEscalationAt, escalatedCount, autoEscalated, assignedResponder, assignedAdminName }`
- `metrics`: `{ acknowledgedAt, dispatchedAt, resolvedAt, ackTimeSeconds, resolveTimeSeconds }`
- `timeline[]`: chronological audit log (`INCIDENT_CREATED`, `PANIC_TRIGGERED`, `AI_TRIAGE_COMPLETED`, `ALERT_DISPATCHED`, `ACKNOWLEDGED`, `RESPONDER_ASSIGNED`, `AUTO_ESCALATED`, `MANUAL_ESCALATED`, `NOTE_ADDED`, `RESOLVED`)
- Indexes: `{ status: 1, createdAt: -1 }`, `{ emergencyType: 1, severity: 1 }`, `{ 'escalation.nextEscalationAt': 1, status: 1 }`, `{ 'location.zone': 1 }`

### `adminsettings`
- `channels`: `{ smsEnabled, whatsappEnabled, emailEnabled }`
- `slaSeconds`: `{ Critical, High, Medium, Low }`
- `escalationEnabled`: boolean
- `readinessConfig`: `{ patrolUnitsActive, medicalStaffOnDuty, counselorAvailable }`
- `recipients[]`: `{ name, role, level (1|2|3), smsPhone, whatsappPhone, email, categories[], active }`

### `notificationlogs`
- `incidentId`, `incidentCode`, `channel` (`sms` | `whatsapp` | `email`), `recipientName`, `recipientRole`, `recipientAddress`, `escalationLevel`, `messageBody`, `status` (`sent` | `simulated` | `failed`), `provider`, `providerMessageId`, `errorMessage`

## 3. REST & SSE API Endpoints

| Method | Endpoint | Auth | Purpose |
|---|---|---|---|
| GET | `/api/health` | Public | API & MongoDB health check |
| POST | `/api/auth/register` | Public | Student registration (returns JWT) |
| POST | `/api/auth/login` | Public | Student / Admin login (returns JWT) |
| GET | `/api/auth/me` | JWT | Current authenticated profile |
| GET | `/api/campus/locations` | Public | Campus buildings, hostels, blue-light poles, safe corridors |
| GET | `/api/campus/nearest` | Public | Nearest campus node to GPS lat/lng |
| GET | `/api/campus/readiness` | Public | Live Emergency Readiness Score (0–100) |
| GET | `/api/guidance/categories` | Public | All 7 categories & default guidance |
| POST | `/api/guidance/evaluate` | Public | Real-time AI triage & guidance preview |
| POST | `/api/incidents` | Optional JWT | Submit emergency report, run AI triage, dispatch alerts |
| POST | `/api/incidents/panic` | Optional JWT | One-click Panic Mode Critical beacon |
| GET | `/api/incidents/my` | JWT | Student's submitted incidents |
| GET | `/api/incidents/:id` | Public | Incident details, timeline & alert delivery receipts |
| GET | `/api/incidents/:id/stream` | Public | SSE live updates for a specific incident |
| POST | `/api/incidents/:id/note` | Optional JWT | Append live situation note to timeline |
| GET | `/api/admin/stream` | Admin JWT | SSE live operations feed |
| GET | `/api/admin/incidents` | Admin JWT | Filterable incident list (status, category, severity, search) |
| PATCH | `/api/admin/incidents/:id/acknowledge` | Admin JWT | Acknowledge case & record MTTA |
| PATCH | `/api/admin/incidents/:id/assign` | Admin JWT | Assign responder unit |
| PATCH | `/api/admin/incidents/:id/escalate` | Admin JWT | Manually escalate to next tier |
| PATCH | `/api/admin/incidents/:id/resolve` | Admin JWT | Resolve case & record MTTR |
| GET | `/api/admin/analytics` | Admin JWT | Response metrics, hourly trend, zone breakdown, heatmap |
| GET | `/api/admin/notifications` | Admin JWT | SMS/WhatsApp/Email delivery audit logs |
| GET/PUT | `/api/admin/settings` | Admin JWT | Configure alert channels, SLAs & admin recipients |
| POST | `/api/admin/escalation/sweep` | Admin JWT | Trigger immediate SLA escalation sweep |

## 4. Notification & Smart Escalation Architecture

Every incident generates the standardized payload:

```text
Student Assistance Request

Type:
[Emergency Type]

Location:
[Location]

Description:
[Issue Description]

Time:
[Timestamp]

Priority:
[Severity]
```

1. **Tier 1 Dispatch**: Sent immediately on submission to category-matched Tier 1 recipients (e.g., Night Patrol Desk for Security, Medical Officer for Medical/Mental Health).
2. **Panic / Critical Override**: Simultaneously alerts Tier 1 + Tier 2 Command.
3. **No-Response Watchdog**: Every `ESCALATION_CHECK_INTERVAL_MS` (default 10s), `escalationWorker.ts` queries unacknowledged incidents whose `nextEscalationAt <= now` and automatically promotes them to Tier 2 or Tier 3, dispatching escalation alerts and emitting `incident:escalated` via SSE.
