'use client';

import React, { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { motion } from 'framer-motion';
import {
  HeartHandshake,
  PhoneCall,
  Wind,
  Sparkles,
  Send,
  ShieldCheck,
  Loader2,
} from 'lucide-react';
import { apiRequest } from '@/lib/api';
import { IncidentRecord } from '@/lib/types';

const BREATH_PHASES = [
  { label: 'Inhale Slowly', duration: 4, scale: 1.32 },
  { label: 'Hold Gently', duration: 4, scale: 1.32 },
  { label: 'Exhale Completely', duration: 6, scale: 0.92 },
];

export default function MentalHealthSupportPage() {
  const router = useRouter();
  const [breathingActive, setBreathingActive] = useState(true);
  const [phaseIdx, setPhaseIdx] = useState(0);
  const [secondsLeft, setSecondsLeft] = useState(BREATH_PHASES[0].duration);

  const [callbackPhone, setCallbackPhone] = useState('');
  const [feelingNote, setFeelingNote] = useState('');
  const [anonymous, setAnonymous] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!breathingActive) return;
    const timer = setInterval(() => {
      setSecondsLeft((prev) => {
        if (prev <= 1) {
          const next = (phaseIdx + 1) % BREATH_PHASES.length;
          setPhaseIdx(next);
          return BREATH_PHASES[next].duration;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [breathingActive, phaseIdx]);

  const handleCounselorRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const res = await apiRequest<{ incident: IncidentRecord }>('/incidents', {
        method: 'POST',
        body: JSON.stringify({
          emergencyType: 'Mental Health',
          severity: 'High',
          description:
            feelingNote.trim() ||
            'Student requested a confidential 2 A.M. mental health counselor callback.',
          contactNumber: callbackPhone || 'CHAT / ANONYMOUS',
          isAnonymous: anonymous,
          location: {
            method: 'building',
            label: 'Confidential Student Wellness Request',
            zone: 'Academic Core',
            nodeId: 'bldg-central-library',
            coordinates: { lat: 37.4276, lng: -122.1695 },
          },
        }),
      });
      router.push(`/incidents/${res.incident._id}`);
    } finally {
      setSubmitting(false);
    }
  };

  const currentPhase = BREATH_PHASES[phaseIdx];

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6 space-y-10">
      {/* Calm Sanctuary Header */}
      <div className="rounded-3xl border border-teal-500/30 bg-gradient-to-br from-teal-950/40 via-slate-900/90 to-[#050811] p-7 sm:p-10 space-y-4">
        <div className="inline-flex items-center gap-2 rounded-full border border-teal-400/30 bg-teal-500/10 px-3.5 py-1 text-xs font-semibold text-teal-300">
          <HeartHandshake className="h-4 w-4" />
          24/7 Confidential Campus Sanctuary
        </div>
        <h1 className="text-3xl sm:text-4xl font-bold text-white">
          You don’t have to carry tonight alone.
        </h1>
        <p className="max-w-2xl text-sm sm:text-base text-slate-300 leading-relaxed">
          Late-night stress, panic attacks, grief, or loneliness feel heavier at 2 A.M. Our licensed on-call campus counselors are awake right now—reach out anonymously or connect directly.
        </p>

        <div className="flex flex-wrap gap-3 pt-2">
          <a
            href="tel:+15550800"
            className="inline-flex items-center gap-2 rounded-xl bg-teal-500 px-5 py-3 text-sm font-bold text-slate-950 hover:bg-teal-400 transition-colors"
          >
            <PhoneCall className="h-4 w-4" />
            Call Campus Crisis Counselor (+1-555-0800)
          </a>
          <a
            href="tel:988"
            className="inline-flex items-center gap-2 rounded-xl border border-teal-500/40 bg-teal-500/10 px-5 py-3 text-sm font-bold text-teal-200 hover:bg-teal-500/20 transition-colors"
          >
            <PhoneCall className="h-4 w-4" />
            Dial 988 Suicide &amp; Crisis Lifeline
          </a>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-7 items-start">
        {/* Guided Breathing Widget */}
        <div className="lg:col-span-5 glass-panel rounded-3xl p-7 flex flex-col items-center text-center space-y-6">
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-teal-300">
            <Wind className="h-4 w-4" />
            4-4-6 Calming Breath Pacer
          </div>

          <div className="relative flex h-56 w-56 items-center justify-center">
            <motion.div
              animate={{
                scale: breathingActive ? currentPhase.scale : 1,
              }}
              transition={{ duration: currentPhase.duration, ease: 'easeInOut' }}
              className="flex h-36 w-36 flex-col items-center justify-center rounded-full border-2 border-teal-400/50 bg-gradient-to-br from-teal-500/30 to-cyan-500/15 shadow-2xl shadow-teal-950/60"
            >
              <span className="font-mono text-3xl font-black text-white">
                {secondsLeft}s
              </span>
              <span className="text-xs font-semibold text-teal-200 mt-1">
                {currentPhase.label}
              </span>
            </motion.div>
          </div>

          <button
            type="button"
            onClick={() => setBreathingActive(!breathingActive)}
            className="rounded-xl border border-slate-700 bg-slate-900 px-4 py-2 text-xs font-semibold text-slate-200 hover:bg-slate-800"
          >
            {breathingActive ? 'Pause Breathing Guide' : 'Resume Breathing Guide'}
          </button>

          {/* 5-4-3-2-1 Grounding */}
          <div className="w-full text-left rounded-2xl border border-slate-800 bg-slate-900/60 p-4 space-y-2">
            <p className="text-xs font-bold text-white flex items-center gap-1.5">
              <Sparkles className="h-3.5 w-3.5 text-teal-300" />
              5-4-3-2-1 Sensory Grounding
            </p>
            <ul className="text-xs text-slate-300 space-y-1">
              <li>• Name <strong>5</strong> things you can see around you</li>
              <li>• Feel <strong>4</strong> textures you can touch right now</li>
              <li>• Notice <strong>3</strong> subtle sounds in the room</li>
              <li>• Identify <strong>2</strong> scents or fresh air cues</li>
              <li>• Focus on <strong>1</strong> steady breath out</li>
            </ul>
          </div>
        </div>

        {/* Confidential Counselor Callback Form */}
        <form
          onSubmit={handleCounselorRequest}
          className="lg:col-span-7 glass-panel rounded-3xl p-7 space-y-5"
        >
          <div className="space-y-1">
            <h2 className="text-xl font-bold text-white">
              Request an Immediate Counselor Check-In
            </h2>
            <p className="text-xs text-slate-400">
              Your request routes directly to our Campus Wellness Triage Officer with zero academic record impact.
            </p>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              How can we support you tonight?
            </label>
            <textarea
              rows={4}
              value={feelingNote}
              onChange={(e) => setFeelingNote(e.target.value)}
              placeholder="Share as much or as little as you feel comfortable with..."
              className="w-full rounded-xl border border-slate-700 bg-slate-950 px-4 py-3 text-sm text-white placeholder:text-slate-500 focus:border-teal-400 focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-end">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Callback Number (Optional if anonymous)
              </label>
              <input
                value={callbackPhone}
                onChange={(e) => setCallbackPhone(e.target.value)}
                placeholder="+1-555-0142"
                className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3.5 py-2.5 text-sm text-white focus:border-teal-400 focus:outline-none"
              />
            </div>

            <label className="flex items-center gap-2.5 rounded-xl border border-slate-800 bg-slate-900/60 px-3.5 py-2.5 cursor-pointer">
              <input
                type="checkbox"
                checked={anonymous}
                onChange={(e) => setAnonymous(e.target.checked)}
                className="h-4 w-4 rounded border-slate-600 text-teal-500"
              />
              <span className="text-xs text-slate-200">Keep identity confidential</span>
            </label>
          </div>

          <button
            type="submit"
            disabled={submitting}
            className="flex w-full items-center justify-center gap-2 rounded-xl bg-teal-500 py-3.5 text-sm font-bold text-slate-950 hover:bg-teal-400 transition-colors disabled:opacity-60"
          >
            {submitting ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Send className="h-4 w-4" />
            )}
            Connect Me With an On-Call Counselor
          </button>

          <div className="flex items-center gap-2 text-[11px] text-slate-400 pt-1">
            <ShieldCheck className="h-4 w-4 text-teal-400 shrink-0" />
            <span>
              Protected under university medical confidentiality &amp; crisis care privacy protocols.
            </span>
          </div>
        </form>
      </div>
    </div>
  );
}
