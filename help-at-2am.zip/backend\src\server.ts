import { createApp } from './app.js';
import { connectDatabase } from './config/database.js';
import { env } from './config/env.js';
import { seedDatabaseIfEmpty } from './seeds/seedDatabase.js';
import { startEscalationWorker } from './services/escalationWorker.js';

async function bootstrap() {
  await connectDatabase();
  await seedDatabaseIfEmpty();
  startEscalationWorker();

  const app = createApp();
  app.listen(env.port, () => {
    console.log(
      `[Server] Help at 2 A.M. API listening on http://localhost:${env.port}`
    );
  });
}

bootstrap().catch((err) => {
  console.error('[Server] Fatal startup failure:', err);
  process.exit(1);
});
