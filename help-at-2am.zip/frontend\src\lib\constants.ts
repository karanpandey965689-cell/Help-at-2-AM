import { EmergencyCategory, IncidentSeverity, IncidentStatus } from './types';

export const EMERGENCY_CATEGORIES: Array<{
  id: EmergencyCategory;
  shortLabel: string;
  tagline: string;
  defaultSeverity: IncidentSeverity;
  accent: string;
  badgeBg: string;
}> = [
  {
    id: 'Medical Emergency',
    shortLabel: 'Medical',
    tagline: 'Injury, chest pain, fainting, allergic reaction, illness',
    defaultSeverity: 'Critical',
    accent: 'text-rose-400 border-rose-500/40 bg-rose-500/10',
    badgeBg: 'bg-rose-500/20 text-rose-300 border-rose-500/40',
  },
  {
    id: 'Security Emergency',
    shortLabel: 'Security',
    tagline: 'Intruder, suspicious activity, theft, physical threat',
    defaultSeverity: 'Critical',
    accent: 'text-red-400 border-red-500/40 bg-red-500/10',
    badgeBg: 'bg-red-500/20 text-red-300 border-red-500/40',
  },
  {
    id: 'Personal Safety',
    shortLabel: 'Safety',
    tagline: 'Being followed, unsafe dark route, need Safe-Walk escort',
    defaultSeverity: 'High',
    accent: 'text-amber-400 border-amber-500/40 bg-amber-500/10',
    badgeBg: 'bg-amber-500/20 text-amber-300 border-amber-500/40',
  },
  {
    id: 'Mental Health',
    shortLabel: 'Mental Health',
    tagline: 'Panic attack, emotional crisis, urgent confidential talk',
    defaultSeverity: 'High',
    accent: 'text-teal-300 border-teal-500/40 bg-teal-500/10',
    badgeBg: 'bg-teal-500/20 text-teal-200 border-teal-500/40',
  },
  {
    id: 'Hostel Problems',
    shortLabel: 'Hostel',
    tagline: 'Lockout, power failure, water burst, elevator jam, gas odor',
    defaultSeverity: 'Medium',
    accent: 'text-cyan-400 border-cyan-500/40 bg-cyan-500/10',
    badgeBg: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40',
  },
  {
    id: 'Lost on Campus',
    shortLabel: 'Lost',
    tagline: 'Disoriented at night, low phone battery, need shuttle pickup',
    defaultSeverity: 'Medium',
    accent: 'text-indigo-400 border-indigo-500/40 bg-indigo-500/10',
    badgeBg: 'bg-indigo-500/20 text-indigo-300 border-indigo-500/40',
  },
  {
    id: 'Other Emergency',
    shortLabel: 'Other',
    tagline: 'Any urgent late-night campus problem needing assistance',
    defaultSeverity: 'Medium',
    accent: 'text-slate-300 border-slate-500/40 bg-slate-500/10',
    badgeBg: 'bg-slate-500/20 text-slate-300 border-slate-500/40',
  },
];

export const SEVERITY_STYLES: Record<IncidentSeverity, string> = {
  Critical: 'bg-rose-500/20 text-rose-300 border-rose-500/50',
  High: 'bg-amber-500/20 text-amber-300 border-amber-500/50',
  Medium: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/50',
  Low: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50',
};

export const STATUS_STYLES: Record<IncidentStatus, string> = {
  pending: 'bg-amber-500/15 text-amber-300 border-amber-500/40',
  active: 'bg-cyan-500/15 text-cyan-300 border-cyan-500/40',
  escalated: 'bg-rose-500/20 text-rose-300 border-rose-500/50',
  resolved: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/40',
};
