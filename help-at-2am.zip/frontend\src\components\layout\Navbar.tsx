'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  ShieldAlert,
  Radio,
  HeartHandshake,
  MapPin,
  LayoutDashboard,
  Menu,
  X,
  LogIn,
  LogOut,
  AlertOctagon,
  Settings,
} from 'lucide-react';
import { useAuth } from '@/lib/authContext';

export function Navbar() {
  const pathname = usePathname();
  const { user, logout } = useAuth();
  const [mobileOpen, setMobileOpen] = useState(false);

  const isAdmin =
    user?.role === 'admin' ||
    user?.role === 'super_admin' ||
    user?.role === 'responder';

  const navLinks = [
    { href: '/emergency', label: 'Emergency Hub', icon: Radio },
    { href: '/mental-health', label: 'Mental Health', icon: HeartHandshake },
    { href: '/safety', label: 'Campus Safety', icon: MapPin },
    { href: '/admin', label: 'Admin Ops', icon: LayoutDashboard },
  ];

  return (
    <header className="sticky top-0 z-50 border-b border-slate-800/80 bg-[#050811]/90 backdrop-blur-xl">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6">
        <Link href="/" className="flex items-center gap-3 group">
          <div className="relative flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-rose-500/25 via-cyan-500/20 to-slate-900 border border-rose-500/40 shadow-lg shadow-rose-950/30">
            <ShieldAlert className="h-5 w-5 text-rose-400 group-hover:scale-110 transition-transform" />
            <span className="absolute -right-1 -top-1 flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500" />
            </span>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-base font-bold tracking-tight text-white">
                Help at 2 A.M.
              </span>
              <span className="hidden sm:inline-flex items-center rounded-full border border-emerald-500/30 bg-emerald-500/10 px-2 py-0.5 font-mono text-[10px] font-medium text-emerald-300">
                24/7 LIVE
              </span>
            </div>
            <p className="text-[11px] text-slate-400">
              University Crisis &amp; Safety Command
            </p>
          </div>
        </Link>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-1">
          {navLinks.map((item) => {
            const active =
              pathname === item.href ||
              (item.href !== '/' && pathname?.startsWith(item.href));
            const Icon = item.icon;
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium transition-colors ${
                  active
                    ? 'bg-slate-800/90 text-white border border-slate-700'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
                }`}
              >
                <Icon className="h-4 w-4 text-cyan-400" />
                {item.label}
              </Link>
            );
          })}
          {isAdmin && (
            <Link
              href="/admin/settings"
              className={`flex items-center gap-1.5 rounded-lg px-3 py-2 text-sm font-medium transition-colors ${
                pathname === '/admin/settings'
                  ? 'bg-slate-800/90 text-white border border-slate-700'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
              }`}
            >
              <Settings className="h-4 w-4 text-amber-400" />
              Alert Config
            </Link>
          )}
        </nav>

        {/* Actions */}
        <div className="flex items-center gap-2.5">
          <Link
            href="/panic"
            className="inline-flex items-center gap-1.5 rounded-lg bg-rose-600 px-3.5 py-2 text-xs sm:text-sm font-bold text-white shadow-lg shadow-rose-900/40 hover:bg-rose-500 transition-all border border-rose-400/40"
          >
            <AlertOctagon className="h-4 w-4 animate-pulse" />
            <span>PANIC MODE</span>
          </Link>

          {user ? (
            <div className="hidden sm:flex items-center gap-2 rounded-lg border border-slate-800 bg-slate-900/70 px-3 py-1.5">
              <div className="text-right">
                <p className="text-xs font-semibold text-white leading-none">
                  {user.name}
                </p>
                <p className="font-mono text-[10px] uppercase text-cyan-400 mt-0.5">
                  {user.role}
                </p>
              </div>
              <button
                onClick={logout}
                title="Sign out"
                className="rounded-md p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white transition-colors"
              >
                <LogOut className="h-4 w-4" />
              </button>
            </div>
          ) : (
            <Link
              href="/login"
              className="hidden sm:inline-flex items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-900 px-3 py-2 text-xs font-semibold text-slate-200 hover:bg-slate-800 transition-colors"
            >
              <LogIn className="h-3.5 w-3.5 text-cyan-400" />
              Sign In
            </Link>
          )}

          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className="md:hidden rounded-lg border border-slate-800 bg-slate-900 p-2 text-slate-300"
            aria-label="Toggle Menu"
          >
            {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {mobileOpen && (
        <div className="md:hidden border-t border-slate-800 bg-[#070c18] px-4 py-3 space-y-1.5">
          {navLinks.map((item) => {
            const Icon = item.icon;
            return (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setMobileOpen(false)}
                className="flex items-center gap-2.5 rounded-lg px-3 py-2.5 text-sm font-medium text-slate-200 hover:bg-slate-800/70"
              >
                <Icon className="h-4 w-4 text-cyan-400" />
                {item.label}
              </Link>
            );
          })}
          {user ? (
            <button
              onClick={() => {
                logout();
                setMobileOpen(false);
              }}
              className="flex w-full items-center gap-2.5 rounded-lg px-3 py-2.5 text-sm font-medium text-rose-300 hover:bg-slate-800/70"
            >
              <LogOut className="h-4 w-4" />
              Sign Out ({user.name})
            </button>
          ) : (
            <Link
              href="/login"
              onClick={() => setMobileOpen(false)}
              className="flex items-center gap-2.5 rounded-lg px-3 py-2.5 text-sm font-medium text-cyan-300 hover:bg-slate-800/70"
            >
              <LogIn className="h-4 w-4" />
              Sign In / Admin Access
            </Link>
          )}
        </div>
      )}
    </header>
  );
}
