import React from 'react';
import Link from 'next/link';
import { ShieldCheck, PhoneCall } from 'lucide-react';

export function Footer() {
  return (
    <footer className="border-t border-slate-800/80 bg-[#04070f] py-10 text-slate-400">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="space-y-1.5">
          <div className="flex items-center gap-2 text-white font-semibold">
            <ShieldCheck className="h-4 w-4 text-cyan-400" />
            <span>Help at 2 A.M. — Campus Emergency Operations Platform</span>
          </div>
          <p className="text-xs text-slate-500">
            24/7 Student Crisis Guidance, Smart Escalation &amp; Multi-Channel Campus Dispatch Architecture.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-5 text-xs">
          <Link href="/emergency" className="hover:text-white transition-colors">
            Report Emergency
          </Link>
          <Link href="/panic" className="text-rose-400 hover:text-rose-300 transition-colors">
            Panic Mode
          </Link>
          <Link href="/mental-health" className="hover:text-white transition-colors">
            Mental Health Sanctuary
          </Link>
          <Link href="/safety" className="hover:text-white transition-colors">
            Campus Safety Map
          </Link>
          <Link href="/admin" className="hover:text-white transition-colors">
            Admin Command
          </Link>
          <span className="inline-flex items-center gap-1.5 rounded-full border border-slate-800 bg-slate-900 px-3 py-1 font-mono text-emerald-400">
            <PhoneCall className="h-3 w-3" />
            Campus HQ: +1-555-0999
          </span>
        </div>
      </div>
    </footer>
  );
}
