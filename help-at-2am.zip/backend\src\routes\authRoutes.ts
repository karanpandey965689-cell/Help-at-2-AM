import { Router, Response } from 'express';
import bcrypt from 'bcryptjs';
import { z } from 'zod';
import { User } from '../models/User.js';
import {
  AuthenticatedRequest,
  requireAuth,
  signJwtToken,
} from '../middleware/auth.js';
import { validateBody } from '../middleware/validate.js';

const router = Router();

const registerSchema = z.object({
  name: z.string().min(2).max(100),
  email: z.string().email(),
  password: z.string().min(6).max(128),
  phone: z.string().min(7).max(25),
  studentId: z.string().optional(),
  hostel: z.string().optional(),
  department: z.string().optional(),
  emergencyContactName: z.string().optional(),
  emergencyContactPhone: z.string().optional(),
});

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
});

router.post(
  '/register',
  validateBody(registerSchema),
  async (req, res: Response) => {
    const existing = await User.findOne({ email: req.body.email.toLowerCase() });
    if (existing) {
      res.status(409).json({ error: 'An account with this email already exists' });
      return;
    }

    const passwordHash = await bcrypt.hash(req.body.password, 10);
    const user = await User.create({
      ...req.body,
      email: req.body.email.toLowerCase(),
      passwordHash,
      role: 'student',
    });

    const token = signJwtToken({
      userId: user._id.toString(),
      email: user.email,
      role: user.role,
      name: user.name,
    });

    res.status(201).json({
      token,
      user: {
        id: user._id.toString(),
        name: user.name,
        email: user.email,
        role: user.role,
        phone: user.phone,
        studentId: user.studentId,
        hostel: user.hostel,
        department: user.department,
      },
    });
  }
);

router.post('/login', validateBody(loginSchema), async (req, res: Response) => {
  const user = await User.findOne({ email: req.body.email.toLowerCase() });
  if (!user) {
    res.status(401).json({ error: 'Invalid email or password' });
    return;
  }

  const valid = await user.comparePassword(req.body.password);
  if (!valid) {
    res.status(401).json({ error: 'Invalid email or password' });
    return;
  }

  const token = signJwtToken({
    userId: user._id.toString(),
    email: user.email,
    role: user.role,
    name: user.name,
  });

  res.json({
    token,
    user: {
      id: user._id.toString(),
      name: user.name,
      email: user.email,
      role: user.role,
      phone: user.phone,
      studentId: user.studentId,
      hostel: user.hostel,
      department: user.department,
      responderUnit: user.responderUnit,
    },
  });
});

router.get('/me', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  const user = await User.findById(req.user!.userId).select('-passwordHash');
  if (!user) {
    res.status(404).json({ error: 'User not found' });
    return;
  }
  res.json({ user });
});

export default router;
