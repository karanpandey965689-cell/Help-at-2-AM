'use client';

import React, { useEffect, useRef } from 'react';
import type LType from 'leaflet';
import {
  CampusLocationNode,
  IncidentRecord,
  SafeWalkCorridor,
} from '@/lib/types';

export interface HeatmapPoint {
  lat: number;
  lng: number;
  weight: number;
  zone: string;
  category: string;
  status: string;
}

interface CampusMapProps {
  center?: { lat: number; lng: number; zoom?: number };
  locations: CampusLocationNode[];
  safeCorridors?: SafeWalkCorridor[];
  incidents?: IncidentRecord[];
  heatmapPoints?: HeatmapPoint[];
  showHeatmap?: boolean;
  interactiveSelect?: boolean;
  selectedCoordinates?: { lat: number; lng: number } | null;
  onSelectPoint?: (coords: { lat: number; lng: number }) => void;
  onSelectNode?: (node: CampusLocationNode) => void;
  heightClass?: string;
}

export function CampusMap({
  center = { lat: 37.4275, lng: -122.1697, zoom: 16 },
  locations,
  safeCorridors = [],
  incidents = [],
  heatmapPoints = [],
  showHeatmap = false,
  interactiveSelect = false,
  selectedCoordinates = null,
  onSelectPoint,
  onSelectNode,
  heightClass = 'h-[380px]',
}: CampusMapProps) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<LType.Map | null>(null);
  const layersRef = useRef<LType.LayerGroup | null>(null);

  useEffect(() => {
    let mounted = true;

    async function initMap() {
      if (!containerRef.current || mapRef.current) return;
      const L = (await import('leaflet')).default;
      if (!mounted || !containerRef.current) return;

      const map = L.map(containerRef.current, {
        center: [center.lat, center.lng],
        zoom: center.zoom || 16,
        zoomControl: true,
      });

      L.tileLayer(
        'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png',
        {
          attribution:
            '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> &copy; CARTO',
          maxZoom: 20,
        }
      ).addTo(map);

      const layerGroup = L.layerGroup().addTo(map);
      mapRef.current = map;
      layersRef.current = layerGroup;

      if (interactiveSelect && onSelectPoint) {
        map.on('click', (e: LType.LeafletMouseEvent) => {
          onSelectPoint({
            lat: Number(e.latlng.lat.toFixed(6)),
            lng: Number(e.latlng.lng.toFixed(6)),
          });
        });
      }
    }

    initMap();

    return () => {
      mounted = false;
      if (mapRef.current) {
        mapRef.current.remove();
        mapRef.current = null;
        layersRef.current = null;
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    let cancelled = false;

    async function syncLayers() {
      if (!mapRef.current || !layersRef.current) return;
      const L = (await import('leaflet')).default;
      if (cancelled || !layersRef.current) return;

      const group = layersRef.current;
      group.clearLayers();

      // 1. Safe-Walk Corridors
      for (const corridor of safeCorridors) {
        L.polyline(corridor.path, {
          color: '#06b6d4',
          weight: 4,
          opacity: 0.65,
          dashArray: '8 6',
        })
          .bindPopup(
            `<div class="text-xs"><strong>${corridor.name}</strong><br/>Lighting: ${corridor.lightingStatus}</div>`
          )
          .addTo(group);
      }

      // 2. Heatmap overlay
      if (showHeatmap && heatmapPoints.length > 0) {
        for (const pt of heatmapPoints) {
          const radius = 55 + pt.weight * 75;
          const color =
            pt.weight >= 0.85
              ? '#f43f5e'
              : pt.weight >= 0.6
              ? '#f59e0b'
              : '#06b6d4';

          L.circle([pt.lat, pt.lng], {
            radius,
            color,
            weight: 1,
            opacity: 0.35,
            fillColor: color,
            fillOpacity: 0.28,
          }).addTo(group);
        }
      }

      // 3. Campus POI Nodes
      const typeColors: Record<CampusLocationNode['type'], string> = {
        hostel: '#38bdf8',
        building: '#94a3b8',
        medical: '#10b981',
        security: '#f59e0b',
        blue_light: '#3b82f6',
        safe_zone: '#2dd4bf',
      };

      for (const node of locations) {
        const color = typeColors[node.type] || '#94a3b8';
        const marker = L.circleMarker(
          [node.coordinates.lat, node.coordinates.lng],
          {
            radius: node.type === 'security' || node.type === 'medical' ? 8 : 6,
            color: '#0f172a',
            weight: 2,
            fillColor: color,
            fillOpacity: 0.9,
          }
        );

        marker.bindPopup(
          `<div class="text-xs space-y-1">
            <div class="font-bold text-white">${node.name}</div>
            <div class="text-slate-300">${node.zone} · <span class="font-mono">${node.code}</span></div>
            <div class="text-cyan-300">Safe Point: ${node.nearestSafePoint}</div>
          </div>`
        );

        if (onSelectNode) {
          marker.on('click', () => onSelectNode(node));
        }

        marker.addTo(group);
      }

      // 4. Live Incidents
      for (const inc of incidents) {
        const sev = inc.aiAdjustedSeverity || inc.severity;
        const color =
          inc.status === 'resolved'
            ? '#10b981'
            : sev === 'Critical' || inc.isPanicMode
            ? '#f43f5e'
            : sev === 'High'
            ? '#f59e0b'
            : '#06b6d4';

        if (inc.status !== 'resolved' && (sev === 'Critical' || inc.isPanicMode)) {
          L.circle([inc.location.coordinates.lat, inc.location.coordinates.lng], {
            radius: 42,
            color: '#f43f5e',
            weight: 1.5,
            fillColor: '#f43f5e',
            fillOpacity: 0.16,
          }).addTo(group);
        }

        const incMarker = L.circleMarker(
          [inc.location.coordinates.lat, inc.location.coordinates.lng],
          {
            radius: 9,
            color: '#ffffff',
            weight: 2,
            fillColor: color,
            fillOpacity: 1,
          }
        );

        incMarker.bindPopup(
          `<div class="text-xs space-y-1">
            <div class="font-mono font-bold text-rose-300">${inc.incidentCode} · ${sev.toUpperCase()}</div>
            <div class="font-semibold text-white">${inc.emergencyType}</div>
            <div class="text-slate-300">${inc.location.label}</div>
            <div class="text-cyan-300 uppercase">Status: ${inc.status}</div>
          </div>`
        );
        incMarker.addTo(group);
      }

      // 5. User-selected pin
      if (selectedCoordinates) {
        L.circle([selectedCoordinates.lat, selectedCoordinates.lng], {
          radius: 30,
          color: '#f43f5e',
          weight: 2,
          fillColor: '#f43f5e',
          fillOpacity: 0.2,
        }).addTo(group);

        L.circleMarker([selectedCoordinates.lat, selectedCoordinates.lng], {
          radius: 9,
          color: '#ffffff',
          weight: 2.5,
          fillColor: '#f43f5e',
          fillOpacity: 1,
        })
          .bindPopup('<div class="text-xs font-bold">Selected Emergency Pin</div>')
          .addTo(group);
      }
    }

    syncLayers();
    return () => {
      cancelled = true;
    };
  }, [
    locations,
    safeCorridors,
    incidents,
    heatmapPoints,
    showHeatmap,
    selectedCoordinates,
    onSelectNode,
  ]);

  return (
    <div className="relative overflow-hidden rounded-2xl border border-slate-800 bg-[#070c18]">
      <div ref={containerRef} className={`w-full ${heightClass}`} />
      <div className="flex flex-wrap items-center justify-between gap-2 border-t border-slate-800/80 bg-[#070c18]/95 px-3.5 py-2 text-[11px] text-slate-400">
        <div className="flex flex-wrap items-center gap-3">
          <span className="inline-flex items-center gap-1.5">
            <span className="h-2.5 w-2.5 rounded-full bg-sky-400" /> Hostels
          </span>
          <span className="inline-flex items-center gap-1.5">
            <span className="h-2.5 w-2.5 rounded-full bg-emerald-400" /> 24/7 Medical
          </span>
          <span className="inline-flex items-center gap-1.5">
            <span className="h-2.5 w-2.5 rounded-full bg-amber-400" /> Security HQ
          </span>
          <span className="inline-flex items-center gap-1.5">
            <span className="h-2.5 w-2.5 rounded-full bg-blue-500" /> Blue-Light Pole
          </span>
          <span className="inline-flex items-center gap-1.5">
            <span className="h-0.5 w-4 bg-cyan-400" /> Safe-Walk Corridor
          </span>
        </div>
        {interactiveSelect && (
          <span className="font-mono text-cyan-300">
            Click anywhere on map to drop emergency pin
          </span>
        )}
      </div>
    </div>
  );
}
