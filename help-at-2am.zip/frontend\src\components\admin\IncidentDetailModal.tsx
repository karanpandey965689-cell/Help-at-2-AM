'use client';

import React, { useState } from 'react';
import {
  X,
  CheckCircle2,
  UserPlus,
  ArrowUpCircle,
  ShieldCheck,
  MapPin,
  Phone,
  Cpu,
} from 'lucide-react';
import { IncidentRecord } from '@/lib/types';
import { SEVERITY_STYLES, STATUS_STYLES } from '@/lib/constants';
import { TimelineView } from '@/components/emergency/TimelineView';

export function IncidentDetailModal({
  incident,
  onClose,
  onAcknowledge,
  onAssign,
  onEscalate,
  onResolve,
}: {
  incident: IncidentRecord | null;
  onClose: () => void;
  onAcknowledge: (id: string) => Promise<void>;
  onAssign: (id: string, responderUnit: string) => Promise<void>;
  onEscalate: (id: string) => Promise<void>;
  onResolve: (id: string, summary: string) => Promise<void>;
}) {
  const [responderUnit, setResponderUnit] = useState('Patrol Unit Alpha');
  const [resolutionSummary, setResolutionSummary] = useState(
    'Responder verified student safety and closed incident.'
  );
  const [busy, setBusy] = useState(false);

  if (!incident) return null;

  const effectiveSev = incident.aiAdjustedSeverity || incident.severity;

  const runAction = async (fn: () => Promise<void>) => {
    setBusy(true);
    try {
      await fn();
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4">
      <div className="max-h-[90vh] w-full max-w-4xl overflow-y-auto rounded-3xl border border-slate-700 bg-[#080d1a] p-6 shadow-2xl space-y-6">
        <div className="flex items-start justify-between gap-4 border-b border-slate-800 pb-4">
          <div className="space-y-1">
            <div className="flex flex-wrap items-center gap-2">
              <span className="font-mono text-sm font-black text-cyan-300">
                {incident.incidentCode}
              </span>
              <span
                className={`rounded-full border px-2.5 py-0.5 text-[10px] font-bold uppercase ${
                  STATUS_STYLES[incident.status]
                }`}
              >
                {incident.status}
              </span>
              <span
                className={`rounded-full border px-2.5 py-0.5 text-[10px] font-bold ${
                  SEVERITY_STYLES[effectiveSev]
                }`}
              >
                {effectiveSev}
              </span>
              <span className="rounded-full border border-amber-500/40 bg-amber-500/10 px-2.5 py-0.5 font-mono text-[10px] text-amber-300">
                TIER {incident.escalation.currentLevel}
              </span>
            </div>
            <h2 className="text-xl font-bold text-white">
              {incident.emergencyType}
            </h2>
          </div>

          <button
            onClick={onClose}
            className="rounded-xl border border-slate-800 bg-slate-900 p-2 text-slate-400 hover:text-white"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Summary & AI Triage */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-4 space-y-2 text-xs">
            <p className="font-bold text-slate-300 uppercase tracking-wider text-[11px]">
              Incident Report
            </p>
            <p className="text-sm text-white leading-relaxed">{incident.description}</p>
            <div className="pt-2 space-y-1 text-slate-400">
              <p className="flex items-center gap-1.5">
                <MapPin className="h-3.5 w-3.5 text-cyan-400" />
                {incident.location.label}{' '}
                {incident.location.floorOrRoom
                  ? `(${incident.location.floorOrRoom})`
                  : ''}
              </p>
              <p className="flex items-center gap-1.5">
                <Phone className="h-3.5 w-3.5 text-emerald-400" />
                Reporter: {incident.reporterName} · {incident.contactNumber}
              </p>
            </div>
          </div>

          <div className="rounded-2xl border border-cyan-500/30 bg-cyan-950/20 p-4 space-y-2 text-xs">
            <div className="flex items-center justify-between">
              <span className="flex items-center gap-1.5 font-bold text-cyan-300 uppercase tracking-wider text-[11px]">
                <Cpu className="h-3.5 w-3.5" />
                AI Triage Analysis
              </span>
              <span className="font-mono font-bold text-white">
                Risk {incident.aiTriage.riskScore}/100
              </span>
            </div>
            <p className="text-slate-200 leading-relaxed">
              {incident.aiTriage.reasoning}
            </p>
            <p className="font-mono text-[11px] text-emerald-300">
              Recommended: {incident.aiTriage.recommendedUnit}
            </p>
          </div>
        </div>

        {/* Admin Command Actions */}
        {incident.status !== 'resolved' && (
          <div className="rounded-2xl border border-slate-800 bg-slate-900/70 p-4 space-y-4">
            <p className="text-xs font-bold uppercase tracking-wider text-slate-300">
              Command Dispatch Actions
            </p>

            <div className="flex flex-wrap gap-2.5">
              <button
                disabled={busy}
                onClick={() => runAction(() => onAcknowledge(incident._id))}
                className="inline-flex items-center gap-1.5 rounded-xl bg-cyan-500 px-4 py-2 text-xs font-bold text-slate-950 hover:bg-cyan-400 disabled:opacity-50"
              >
                <CheckCircle2 className="h-4 w-4" />
                Acknowledge Case
              </button>

              <button
                disabled={busy || incident.escalation.currentLevel >= 3}
                onClick={() => runAction(() => onEscalate(incident._id))}
                className="inline-flex items-center gap-1.5 rounded-xl border border-rose-500/40 bg-rose-500/15 px-4 py-2 text-xs font-bold text-rose-200 hover:bg-rose-500/25 disabled:opacity-50"
              >
                <ArrowUpCircle className="h-4 w-4" />
                Escalate to Next Tier
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2 border-t border-slate-800">
              <div className="flex gap-2">
                <select
                  value={responderUnit}
                  onChange={(e) => setResponderUnit(e.target.value)}
                  className="flex-1 rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-xs text-white"
                >
                  <option value="Patrol Unit Alpha">Patrol Unit Alpha</option>
                  <option value="Campus Ambulance #1">Campus Ambulance #1</option>
                  <option value="Night Warden Desk">Night Warden Desk</option>
                  <option value="On-Call Crisis Counselor">
                    On-Call Crisis Counselor
                  </option>
                  <option value="Safe-Walk Shuttle #2">Safe-Walk Shuttle #2</option>
                  <option value="Facilities Emergency Crew">
                    Facilities Emergency Crew
                  </option>
                </select>
                <button
                  disabled={busy}
                  onClick={() =>
                    runAction(() => onAssign(incident._id, responderUnit))
                  }
                  className="inline-flex items-center gap-1.5 rounded-xl bg-sky-600 px-3.5 py-2 text-xs font-bold text-white hover:bg-sky-500 disabled:opacity-50"
                >
                  <UserPlus className="h-3.5 w-3.5" />
                  Assign
                </button>
              </div>

              <div className="flex gap-2">
                <input
                  value={resolutionSummary}
                  onChange={(e) => setResolutionSummary(e.target.value)}
                  className="flex-1 rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-xs text-white"
                  placeholder="Resolution summary..."
                />
                <button
                  disabled={busy}
                  onClick={() =>
                    runAction(() => onResolve(incident._id, resolutionSummary))
                  }
                  className="inline-flex items-center gap-1.5 rounded-xl bg-emerald-600 px-3.5 py-2 text-xs font-bold text-white hover:bg-emerald-500 disabled:opacity-50"
                >
                  <ShieldCheck className="h-3.5 w-3.5" />
                  Resolve
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Full Audit Timeline */}
        <div className="space-y-3">
          <h3 className="text-sm font-bold text-white">
            Incident Audit Timeline
          </h3>
          <TimelineView events={incident.timeline} />
        </div>
      </div>
    </div>
  );
}
