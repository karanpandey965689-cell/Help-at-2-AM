export interface CampusLocationNode {
  id: string;
  name: string;
  code: string;
  type: 'hostel' | 'building' | 'medical' | 'security' | 'blue_light' | 'safe_zone';
  zone: string;
  coordinates: { lat: number; lng: number };
  floors?: string[];
  open24x7: boolean;
  riskWeight: number; // 1.0 = normal, >1.0 = higher isolation late at night
  nearestSafePoint: string;
  wardenOrContact?: string;
}

export const CAMPUS_CENTER = {
  lat: 37.4275,
  lng: -122.1697,
  zoom: 16,
  name: 'Northridge University Campus',
};

export const CAMPUS_LOCATIONS: CampusLocationNode[] = [
  // Hostels
  {
    id: 'hostel-aurora-a',
    name: 'Aurora Residence Hall A (North)',
    code: 'HST-A',
    type: 'hostel',
    zone: 'North Residential Quad',
    coordinates: { lat: 37.4314, lng: -122.1728 },
    floors: ['Ground', 'Floor 1', 'Floor 2', 'Floor 3', 'Floor 4'],
    open24x7: true,
    riskWeight: 1.05,
    nearestSafePoint: 'North Gate Security Kiosk',
    wardenOrContact: '+1-555-0101',
  },
  {
    id: 'hostel-beacon-b',
    name: 'Beacon Engineering Hall B',
    code: 'HST-B',
    type: 'hostel',
    zone: 'North Residential Quad',
    coordinates: { lat: 37.4309, lng: -122.1699 },
    floors: ['Ground', 'Floor 1', 'Floor 2', 'Floor 3'],
    open24x7: true,
    riskWeight: 1.05,
    nearestSafePoint: 'Blue-Light Pole N2',
    wardenOrContact: '+1-555-0102',
  },
  {
    id: 'hostel-cedar-c',
    name: 'Cedar Women’s Residence C',
    code: 'HST-C',
    type: 'hostel',
    zone: 'West Residential Commons',
    coordinates: { lat: 37.4282, lng: -122.1749 },
    floors: ['Ground', 'Floor 1', 'Floor 2', 'Floor 3', 'Floor 4'],
    open24x7: true,
    riskWeight: 1.15,
    nearestSafePoint: 'West Commons Guard Post',
    wardenOrContact: '+1-555-0103',
  },
  {
    id: 'hostel-delta-d',
    name: 'Delta Graduate Apartments D',
    code: 'HST-D',
    type: 'hostel',
    zone: 'South Residential Village',
    coordinates: { lat: 37.4234, lng: -122.1715 },
    floors: ['Block 1', 'Block 2', 'Block 3', 'Block 4'],
    open24x7: true,
    riskWeight: 1.2,
    nearestSafePoint: 'South Village Security Booth',
    wardenOrContact: '+1-555-0104',
  },

  // Campus Buildings
  {
    id: 'bldg-central-library',
    name: 'Central Library (24/7 Late-Night Study Wing)',
    code: 'LIB-01',
    type: 'building',
    zone: 'Academic Core',
    coordinates: { lat: 37.4276, lng: -122.1695 },
    floors: ['Lower Level', 'Main Atrium', 'Floor 2 Quiet Zone', 'Floor 3 Labs'],
    open24x7: true,
    riskWeight: 0.9,
    nearestSafePoint: 'Library Front Security Desk',
  },
  {
    id: 'bldg-eng-quad',
    name: 'Turing Engineering & Robotics Complex',
    code: 'ENG-04',
    type: 'building',
    zone: 'Science & Tech Sector',
    coordinates: { lat: 37.4292, lng: -122.1718 },
    floors: ['Basement Labs', 'Floor 1', 'Floor 2', 'Floor 3'],
    open24x7: false,
    riskWeight: 1.25,
    nearestSafePoint: 'Blue-Light Pole E1',
  },
  {
    id: 'bldg-student-union',
    name: 'Student Union & Night Commons',
    code: 'STU-02',
    type: 'building',
    zone: 'Central Plaza',
    coordinates: { lat: 37.4268, lng: -122.1704 },
    floors: ['Food Court', 'Student Lounge', 'Level 2'],
    open24x7: true,
    riskWeight: 0.95,
    nearestSafePoint: 'Central Plaza Safe Hub',
  },
  {
    id: 'bldg-science-labs',
    name: 'BioSciences & Chemistry Research Wing',
    code: 'SCI-07',
    type: 'building',
    zone: 'East Research Park',
    coordinates: { lat: 37.4281, lng: -122.1656 },
    floors: ['Ground', 'Cleanroom Floor 1', 'Floor 2'],
    open24x7: false,
    riskWeight: 1.35,
    nearestSafePoint: 'East Park Shuttle Stop',
  },
  {
    id: 'bldg-sports-complex',
    name: 'Athletics Stadium & Perimeter Track',
    code: 'ATH-09',
    type: 'building',
    zone: 'East Athletics Perimeter',
    coordinates: { lat: 37.4254, lng: -122.1642 },
    floors: ['Main Field', 'Indoor Arena', 'Parking Lot C'],
    open24x7: false,
    riskWeight: 1.4,
    nearestSafePoint: 'Blue-Light Pole A3',
  },

  // Medical & Security Command Hubs
  {
    id: 'med-health-center',
    name: 'Campus 24/7 Urgent Care & Trauma Clinic',
    code: 'MED-24',
    type: 'medical',
    zone: 'Central Medical Precinct',
    coordinates: { lat: 37.4261, lng: -122.1682 },
    open24x7: true,
    riskWeight: 0.8,
    nearestSafePoint: 'On-Site Ambulance Bay',
    wardenOrContact: '+1-555-0911',
  },
  {
    id: 'sec-command-hq',
    name: 'Campus Security Command & Dispatch HQ',
    code: 'SEC-HQ',
    type: 'security',
    zone: 'Main Gate Boulevard',
    coordinates: { lat: 37.4296, lng: -122.1674 },
    open24x7: true,
    riskWeight: 0.75,
    nearestSafePoint: 'Main Gate Dispatch Center',
    wardenOrContact: '+1-555-0999',
  },

  // Blue-light Poles & Safe Zones
  {
    id: 'blp-north-walk',
    name: 'Blue-Light Emergency Pole #N2 (North Walkway)',
    code: 'BLP-N2',
    type: 'blue_light',
    zone: 'North Residential Quad',
    coordinates: { lat: 37.4301, lng: -122.1705 },
    open24x7: true,
    riskWeight: 1.0,
    nearestSafePoint: 'Direct Intercom to SEC-HQ',
  },
  {
    id: 'blp-west-trail',
    name: 'Blue-Light Emergency Pole #W4 (Cedar Grove Trail)',
    code: 'BLP-W4',
    type: 'blue_light',
    zone: 'West Residential Commons',
    coordinates: { lat: 37.4274, lng: -122.1736 },
    open24x7: true,
    riskWeight: 1.1,
    nearestSafePoint: 'Direct Intercom to SEC-HQ',
  },
  {
    id: 'safe-plaza-hub',
    name: '24/7 Safe-Walk Escort & Shuttle Hub',
    code: 'SAFE-01',
    type: 'safe_zone',
    zone: 'Central Plaza',
    coordinates: { lat: 37.4271, lng: -122.1691 },
    open24x7: true,
    riskWeight: 0.85,
    nearestSafePoint: 'Lit Safe Corridor Junction',
  },
];

export const SAFE_WALK_CORRIDORS: Array<{
  id: string;
  name: string;
  path: Array<[number, number]>;
  lightingStatus: 'Optimal LED' | 'Patrolled';
}> = [
  {
    id: 'corridor-north-spine',
    name: 'North Hostel – Library Lit Spine',
    lightingStatus: 'Optimal LED',
    path: [
      [37.4314, -122.1728],
      [37.4301, -122.1705],
      [37.4276, -122.1695],
      [37.4268, -122.1704],
    ],
  },
  {
    id: 'corridor-east-medical',
    name: 'Security HQ – Medical Clinic Corridor',
    lightingStatus: 'Patrolled',
    path: [
      [37.4296, -122.1674],
      [37.4271, -122.1691],
      [37.4261, -122.1682],
    ],
  },
  {
    id: 'corridor-west-south',
    name: 'West Residences – South Village Safe Path',
    lightingStatus: 'Optimal LED',
    path: [
      [37.4282, -122.1749],
      [37.4274, -122.1736],
      [37.4268, -122.1704],
      [37.4234, -122.1715],
    ],
  },
];

export function findNearestCampusNode(lat: number, lng: number): CampusLocationNode {
  let closest = CAMPUS_LOCATIONS[0];
  let bestDist = Number.MAX_VALUE;
  for (const node of CAMPUS_LOCATIONS) {
    const dLat = node.coordinates.lat - lat;
    const dLng = node.coordinates.lng - lng;
    const dist = dLat * dLat + dLng * dLng;
    if (dist < bestDist) {
      bestDist = dist;
      closest = node;
    }
  }
  return closest;
}
