import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import request from 'supertest';
import { connectDatabase, disconnectDatabase } from '../config/database.js';
import { createApp } from '../app.js';
import { seedDatabaseIfEmpty } from '../seeds/seedDatabase.js';
import { runEscalationSweep } from '../services/escalationWorker.js';
import { Incident } from '../models/Incident.js';

process.env.USE_IN_MEMORY_DB = 'true';
process.env.NODE_ENV = 'test';

const app = createApp();
let adminToken = '';
let studentToken = '';
let createdIncidentId = '';

before(async () => {
  await connectDatabase();
  await seedDatabaseIfEmpty();
});

after(async () => {
  await disconnectDatabase();
});

describe('Help at 2 A.M. Core API Suite', () => {
  it('returns operational health status', async () => {
    const res = await request(app).get('/api/health');
    assert.equal(res.status, 200);
    assert.equal(res.body.status, 'operational');
    assert.equal(res.body.database.connected, true);
  });

  it('authenticates seeded student and admin via JWT', async () => {
    const stuRes = await request(app)
      .post('/api/auth/login')
      .send({ email: 'student@campus.edu', password: 'Student@2AM' });
    assert.equal(stuRes.status, 200);
    assert.ok(stuRes.body.token);
    assert.equal(stuRes.body.user.role, 'student');
    studentToken = stuRes.body.token;

    const admRes = await request(app)
      .post('/api/auth/login')
      .send({ email: 'admin@campus.edu', password: 'Command@2AM' });
    assert.equal(admRes.status, 200);
    assert.ok(admRes.body.token);
    assert.equal(admRes.body.user.role, 'admin');
    adminToken = admRes.body.token;
  });

  it('returns campus map nodes, safe corridors, and Emergency Readiness Score', async () => {
    const locRes = await request(app).get('/api/campus/locations');
    assert.equal(locRes.status, 200);
    assert.ok(Array.isArray(locRes.body.locations));
    assert.ok(locRes.body.locations.length >= 10);

    const readyRes = await request(app).get('/api/campus/readiness');
    assert.equal(readyRes.status, 200);
    assert.ok(readyRes.body.score >= 0 && readyRes.body.score <= 100);
    assert.ok(readyRes.body.grade);
  });

  it('submits an incident, runs AI triage, and formats exact admin notification message', async () => {
    const res = await request(app)
      .post('/api/incidents')
      .set('Authorization', `Bearer ${studentToken}`)
      .send({
        emergencyType: 'Medical Emergency',
        severity: 'High',
        description: 'Student collapsed with severe chest pain and difficulty breathing.',
        contactNumber: '+1-555-0142',
        location: {
          method: 'hostel',
          label: 'Aurora Residence Hall A (North)',
          zone: 'North Residential Quad',
          nodeId: 'hostel-aurora-a',
          floorOrRoom: 'Floor 2, Room 214',
          coordinates: { lat: 37.4314, lng: -122.1728 },
        },
      });

    assert.equal(res.status, 201);
    assert.ok(res.body.incident._id);
    createdIncidentId = res.body.incident._id;
    assert.equal(res.body.incident.aiAdjustedSeverity, 'Critical');
    assert.ok(res.body.incident.aiTriage.riskScore >= 88);
    assert.match(res.body.alertMessage, /Student Assistance Request/);
    assert.match(res.body.alertMessage, /Type:\nMedical Emergency/);
    assert.match(res.body.alertMessage, /Priority:\nCritical/);
    assert.ok(res.body.notificationsDispatched > 0);
  });

  it('triggers Panic Mode one-click emergency beacon', async () => {
    const res = await request(app)
      .post('/api/incidents/panic')
      .send({
        contactNumber: '+1-555-0199',
        coordinates: { lat: 37.4281, lng: -122.1656, accuracy: 12 },
      });

    assert.equal(res.status, 201);
    assert.equal(res.body.incident.isPanicMode, true);
    assert.equal(res.body.incident.aiAdjustedSeverity, 'Critical');
    assert.equal(res.body.incident.timeline[0].eventType, 'PANIC_TRIGGERED');
  });

  it('executes No-Response Auto-Escalation when SLA timer elapses', async () => {
    await Incident.findByIdAndUpdate(createdIncidentId, {
      'escalation.currentLevel': 1,
      'escalation.nextEscalationAt': new Date(Date.now() - 5000),
    });

    const swept = await runEscalationSweep();
    assert.ok(swept >= 1);

    const updated = await Incident.findById(createdIncidentId);
    assert.equal(updated?.status, 'escalated');
    assert.equal(updated?.escalation.currentLevel, 2);
    assert.equal(updated?.escalation.autoEscalated, true);
  });

  it('allows admin to acknowledge, assign, resolve, and configure notification settings', async () => {
    const ackRes = await request(app)
      .patch(`/api/admin/incidents/${createdIncidentId}/acknowledge`)
      .set('Authorization', `Bearer ${adminToken}`);
    assert.equal(ackRes.status, 200);
    assert.equal(ackRes.body.incident.status, 'active');

    const assignRes = await request(app)
      .patch(`/api/admin/incidents/${createdIncidentId}/assign`)
      .set('Authorization', `Bearer ${adminToken}`)
      .send({ responderUnit: 'Campus Ambulance #2' });
    assert.equal(assignRes.status, 200);
    assert.equal(
      assignRes.body.incident.escalation.assignedResponder,
      'Campus Ambulance #2'
    );

    const resolveRes = await request(app)
      .patch(`/api/admin/incidents/${createdIncidentId}/resolve`)
      .set('Authorization', `Bearer ${adminToken}`)
      .send({ resolutionSummary: 'Paramedics arrived and stabilized student.' });
    assert.equal(resolveRes.status, 200);
    assert.equal(resolveRes.body.incident.status, 'resolved');

    const analyticsRes = await request(app)
      .get('/api/admin/analytics')
      .set('Authorization', `Bearer ${adminToken}`);
    assert.equal(analyticsRes.status, 200);
    assert.ok(analyticsRes.body.totalIncidents >= 8);
    assert.ok(Array.isArray(analyticsRes.body.heatmapPoints));

    const settingsGet = await request(app)
      .get('/api/admin/settings')
      .set('Authorization', `Bearer ${adminToken}`);
    assert.equal(settingsGet.status, 200);
    assert.ok(Array.isArray(settingsGet.body.settings.recipients));
  });
});
