'use client';

import React, { useState } from 'react';
import {
  CheckSquare,
  Square,
  PhoneCall,
  ArrowUpRight,
  Cpu,
  ShieldAlert,
} from 'lucide-react';
import { GuidanceSnapshot } from '@/lib/types';

export function GuidancePanel({
  guidance,
  triage,
}: {
  guidance: GuidanceSnapshot | null;
  triage?: {
    riskScore: number;
    recommendedUnit: string;
    detectedSignals: string[];
    reasoning: string;
  } | null;
}) {
  const [checkedSteps, setCheckedSteps] = useState<Record<number, boolean>>({});

  if (!guidance) return null;

  const toggleStep = (idx: number) => {
    setCheckedSteps((prev) => ({ ...prev, [idx]: !prev[idx] }));
  };

  return (
    <div className="space-y-4">
      {triage && (
        <div className="rounded-2xl border border-cyan-500/30 bg-gradient-to-br from-cyan-950/35 to-slate-900/90 p-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-cyan-300">
              <Cpu className="h-4 w-4" />
              AI Decision Engine Triage
            </div>
            <span className="rounded-full border border-cyan-500/40 bg-cyan-500/15 px-2.5 py-0.5 font-mono text-xs font-bold text-cyan-200">
              Risk Score: {triage.riskScore}/100
            </span>
          </div>
          <p className="mt-2 text-xs text-slate-200 leading-relaxed">
            {triage.reasoning}
          </p>
          <div className="mt-2.5 flex flex-wrap gap-1.5">
            <span className="rounded-md bg-slate-800 px-2 py-1 font-mono text-[11px] text-emerald-300">
              Dispatch Unit: {triage.recommendedUnit}
            </span>
            {triage.detectedSignals.map((sig, i) => (
              <span
                key={i}
                className="rounded-md border border-amber-500/30 bg-amber-500/10 px-2 py-1 text-[11px] text-amber-200"
              >
                {sig}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* Recommended Actions */}
      <div className="glass-panel rounded-2xl p-5">
        <h3 className="flex items-center gap-2 text-sm font-bold text-white">
          <ShieldAlert className="h-4 w-4 text-amber-400" />
          Immediate Recommended Actions
        </h3>
        <ul className="mt-3 space-y-2">
          {guidance.recommendedActions.map((action, idx) => (
            <li
              key={idx}
              className="flex items-start gap-2.5 rounded-xl border border-slate-800/80 bg-slate-900/60 px-3.5 py-2.5 text-xs text-slate-200"
            >
              <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-amber-500/20 font-mono text-[10px] font-bold text-amber-300">
                {idx + 1}
              </span>
              <span className="leading-relaxed">{action}</span>
            </li>
          ))}
        </ul>
      </div>

      {/* Emergency Steps Checklist */}
      <div className="glass-panel rounded-2xl p-5">
        <h3 className="text-sm font-bold text-white">
          Step-by-Step Emergency Protocol
        </h3>
        <p className="text-xs text-slate-400 mt-0.5">
          Tap each step as you complete it while response units are en route.
        </p>
        <div className="mt-3 space-y-2">
          {guidance.emergencySteps.map((step, idx) => {
            const done = Boolean(checkedSteps[idx]);
            return (
              <button
                key={idx}
                type="button"
                onClick={() => toggleStep(idx)}
                className={`flex w-full items-start gap-2.5 rounded-xl border p-3 text-left text-xs transition-all ${
                  done
                    ? 'border-emerald-500/40 bg-emerald-500/10 text-emerald-200 line-through'
                    : 'border-slate-800 bg-slate-900/60 text-slate-200 hover:border-slate-700'
                }`}
              >
                {done ? (
                  <CheckSquare className="h-4 w-4 shrink-0 text-emerald-400 mt-0.5" />
                ) : (
                  <Square className="h-4 w-4 shrink-0 text-slate-500 mt-0.5" />
                )}
                <span className="leading-relaxed">{step}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Direct Contacts */}
      <div className="glass-panel rounded-2xl p-5">
        <h3 className="text-sm font-bold text-white">
          Direct Contact Suggestions (24/7)
        </h3>
        <div className="mt-3 grid grid-cols-1 gap-2.5">
          {guidance.contactSuggestions.map((contact, idx) => (
            <div
              key={idx}
              className="flex items-center justify-between gap-3 rounded-xl border border-slate-800 bg-slate-900/70 px-3.5 py-2.5"
            >
              <div>
                <p className="text-xs font-bold text-white">{contact.name}</p>
                <p className="text-[11px] text-slate-400">{contact.role}</p>
              </div>
              <a
                href={`tel:${contact.phone}`}
                className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 font-mono text-xs font-bold transition-colors ${
                  contact.priority === 'primary'
                    ? 'bg-emerald-600 text-white hover:bg-emerald-500'
                    : 'border border-slate-700 bg-slate-800 text-slate-200 hover:bg-slate-700'
                }`}
              >
                <PhoneCall className="h-3.5 w-3.5" />
                {contact.phone}
              </a>
            </div>
          ))}
        </div>
      </div>

      {/* Escalation Flow */}
      <div className="glass-panel rounded-2xl p-5">
        <h3 className="flex items-center gap-2 text-sm font-bold text-white">
          <ArrowUpRight className="h-4 w-4 text-rose-400" />
          Smart No-Response Escalation Flow
        </h3>
        <div className="mt-3 space-y-2.5">
          {guidance.escalationFlow.map((tier) => (
            <div
              key={tier.level}
              className="flex items-start gap-3 rounded-xl border border-slate-800 bg-slate-950/60 p-3"
            >
              <span className="flex h-6 w-12 shrink-0 items-center justify-center rounded-md bg-rose-500/15 border border-rose-500/30 font-mono text-[11px] font-bold text-rose-300">
                TIER {tier.level}
              </span>
              <div className="flex-1">
                <div className="flex items-center justify-between gap-2">
                  <p className="text-xs font-bold text-white">{tier.targetRole}</p>
                  <span className="font-mono text-[10px] text-amber-300">
                    SLA: {tier.slaSeconds}s
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 mt-0.5">{tier.action}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
