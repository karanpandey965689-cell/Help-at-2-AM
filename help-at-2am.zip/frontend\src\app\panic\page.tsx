'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { PhoneCall, ShieldAlert, Radio, ArrowLeft } from 'lucide-react';
import { PanicButton } from '@/components/emergency/PanicButton';
import { EmergencyCategory } from '@/lib/types';
import { useAuth } from '@/lib/authContext';

export default function PanicModePage() {
  const { user } = useAuth();
  const [contactNumber, setContactNumber] = useState(user?.phone || '+1-555-0199');
  const [category, setCategory] = useState<EmergencyCategory>('Security Emergency');

  return (
    <div className="mx-auto max-w-4xl px-4 py-10 sm:px-6">
      <Link
        href="/emergency"
        className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-400 hover:text-white mb-6"
      >
        <ArrowLeft className="h-4 w-4" />
        Back to Standard Emergency Report
      </Link>

      <div className="rounded-3xl border border-rose-500/40 bg-gradient-to-b from-rose-950/35 via-[#090d1a] to-[#050811] p-6 sm:p-10 text-center space-y-8 shadow-2xl shadow-rose-950/30">
        <div className="space-y-3">
          <div className="inline-flex items-center gap-2 rounded-full border border-rose-500/40 bg-rose-500/15 px-4 py-1.5 font-mono text-xs font-bold uppercase tracking-widest text-rose-300">
            <Radio className="h-3.5 w-3.5 animate-ping" />
            Priority Critical Beacon
          </div>
          <h1 className="text-3xl sm:text-4xl font-black text-white">
            One-Click Panic Mode
          </h1>
          <p className="mx-auto max-w-xl text-sm text-slate-300">
            Pressing <strong className="text-rose-300">HELP NOW</strong> immediately locks your live GPS coordinates, creates a Critical Priority incident, and dispatches Tier 1 &amp; Tier 2 SMS, WhatsApp, Email, and Command Center alerts.
          </p>
        </div>

        {/* Optional quick configuration */}
        <div className="mx-auto max-w-lg grid grid-cols-1 sm:grid-cols-2 gap-3 text-left">
          <div>
            <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-1">
              Emergency Focus
            </label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value as EmergencyCategory)}
              className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-xs text-white focus:border-rose-400 focus:outline-none"
            >
              <option value="Security Emergency">Security Emergency</option>
              <option value="Medical Emergency">Medical Emergency</option>
              <option value="Personal Safety">Personal Safety</option>
              <option value="Mental Health">Mental Health Crisis</option>
            </select>
          </div>
          <div>
            <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-1">
              Callback Phone
            </label>
            <input
              value={contactNumber}
              onChange={(e) => setContactNumber(e.target.value)}
              className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-xs text-white focus:border-rose-400 focus:outline-none"
            />
          </div>
        </div>

        {/* Huge HELP NOW Button */}
        <div className="py-4 flex justify-center">
          <PanicButton
            contactNumber={contactNumber}
            category={category}
            size="lg"
          />
        </div>

        {/* Direct Voice Lines */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-4 border-t border-slate-800/80 text-left">
          <a
            href="tel:+15550999"
            className="flex items-center justify-between rounded-2xl border border-slate-800 bg-slate-900/80 p-4 hover:border-rose-400/50 transition-colors"
          >
            <div>
              <p className="text-xs font-bold text-white">Security HQ</p>
              <p className="font-mono text-xs text-rose-300 mt-0.5">+1-555-0999</p>
            </div>
            <PhoneCall className="h-5 w-5 text-rose-400" />
          </a>

          <a
            href="tel:+15550911"
            className="flex items-center justify-between rounded-2xl border border-slate-800 bg-slate-900/80 p-4 hover:border-emerald-400/50 transition-colors"
          >
            <div>
              <p className="text-xs font-bold text-white">24/7 Campus Medic</p>
              <p className="font-mono text-xs text-emerald-300 mt-0.5">+1-555-0911</p>
            </div>
            <ShieldAlert className="h-5 w-5 text-emerald-400" />
          </a>

          <a
            href="tel:911"
            className="flex items-center justify-between rounded-2xl border border-slate-800 bg-slate-900/80 p-4 hover:border-amber-400/50 transition-colors"
          >
            <div>
              <p className="text-xs font-bold text-white">External 911 EMS</p>
              <p className="font-mono text-xs text-amber-300 mt-0.5">Dial 911</p>
            </div>
            <PhoneCall className="h-5 w-5 text-amber-400" />
          </a>
        </div>
      </div>
    </div>
  );
}
