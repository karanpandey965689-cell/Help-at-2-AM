'use client';

import React from 'react';
import { BarChart3, Clock, AlertTriangle, Activity } from 'lucide-react';
import { ReadinessMetrics } from '@/lib/types';

export interface AnalyticsPayload {
  totalIncidents: number;
  panicCount: number;
  autoEscalatedCount: number;
  escalationRate: number;
  byCategory: Record<string, number>;
  bySeverity: Record<string, number>;
  byStatus: Record<string, number>;
  hourlyTrend: Array<{ hour: string; count: number }>;
  zoneBreakdown: Array<{
    zone: string;
    count: number;
    criticalCount: number;
    lat: number;
    lng: number;
  }>;
  heatmapPoints: Array<{
    lat: number;
    lng: number;
    weight: number;
    zone: string;
    category: string;
    status: string;
  }>;
  readiness: ReadinessMetrics;
}

export function AnalyticsCharts({ analytics }: { analytics: AnalyticsPayload | null }) {
  if (!analytics) return null;

  const maxHourCount = Math.max(1, ...analytics.hourlyTrend.map((h) => h.count));
  const categoryEntries = Object.entries(analytics.byCategory).sort(
    (a, b) => b[1] - a[1]
  );
  const maxCatCount = Math.max(1, ...categoryEntries.map(([, c]) => c));

  return (
    <div className="space-y-5">
      {/* Response Time & Operational Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="glass-panel rounded-2xl p-4">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Mean Time to Ack (MTTA)</span>
            <Clock className="h-4 w-4 text-cyan-400" />
          </div>
          <p className="mt-2 font-mono text-3xl font-black text-white">
            {analytics.readiness.liveSnapshot.avgAckSeconds}s
          </p>
          <p className="text-[11px] text-emerald-400 mt-1">
            Target SLA: &lt; 60s Critical
          </p>
        </div>

        <div className="glass-panel rounded-2xl p-4">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Mean Time to Resolve (MTTR)</span>
            <Activity className="h-4 w-4 text-emerald-400" />
          </div>
          <p className="mt-2 font-mono text-3xl font-black text-white">
            {Math.round(analytics.readiness.liveSnapshot.avgResolveSeconds / 60)}m
          </p>
          <p className="text-[11px] text-slate-400 mt-1">
            {analytics.readiness.liveSnapshot.resolvedTodayCount} resolved today
          </p>
        </div>

        <div className="glass-panel rounded-2xl p-4">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Auto-Escalation Rate</span>
            <AlertTriangle className="h-4 w-4 text-amber-400" />
          </div>
          <p className="mt-2 font-mono text-3xl font-black text-amber-300">
            {analytics.escalationRate}%
          </p>
          <p className="text-[11px] text-slate-400 mt-1">
            {analytics.autoEscalatedCount} no-response triggers
          </p>
        </div>

        <div className="glass-panel rounded-2xl p-4">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Panic Mode Activations</span>
            <BarChart3 className="h-4 w-4 text-rose-400" />
          </div>
          <p className="mt-2 font-mono text-3xl font-black text-rose-400">
            {analytics.panicCount}
          </p>
          <p className="text-[11px] text-slate-400 mt-1">
            Out of {analytics.totalIncidents} total logged cases
          </p>
        </div>
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Hourly Distribution */}
        <div className="lg:col-span-7 glass-panel rounded-2xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-white">
                24-Hour Incident Distribution
              </h3>
              <p className="text-xs text-slate-400">
                Tracks late-night surge windows (00:00 – 05:00)
              </p>
            </div>
            <span className="font-mono text-[11px] text-cyan-400">LIVE AGGREGATE</span>
          </div>

          <div className="flex items-end gap-1.5 h-44 pt-4">
            {analytics.hourlyTrend.map((pt) => {
              const pct = Math.max(6, Math.round((pt.count / maxHourCount) * 100));
              const isLateNight =
                pt.hour.startsWith('00') ||
                pt.hour.startsWith('01') ||
                pt.hour.startsWith('02') ||
                pt.hour.startsWith('03') ||
                pt.hour.startsWith('04');
              return (
                <div
                  key={pt.hour}
                  className="flex-1 flex flex-col items-center gap-1 group"
                  title={`${pt.hour}: ${pt.count} incident(s)`}
                >
                  <span className="font-mono text-[9px] text-slate-400 opacity-0 group-hover:opacity-100 transition-opacity">
                    {pt.count}
                  </span>
                  <div className="w-full flex items-end h-32 bg-slate-900/50 rounded-t">
                    <div
                      style={{ height: `${pt.count === 0 ? 4 : pct}%` }}
                      className={`w-full rounded-t transition-all ${
                        pt.count === 0
                          ? 'bg-slate-800/60'
                          : isLateNight
                          ? 'bg-rose-500/80'
                          : 'bg-cyan-500/80'
                      }`}
                    />
                  </div>
                  <span className="font-mono text-[8px] text-slate-500">
                    {pt.hour.slice(0, 2)}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Category Breakdown & Zone Risk */}
        <div className="lg:col-span-5 glass-panel rounded-2xl p-5 space-y-4">
          <h3 className="text-sm font-bold text-white">
            Category &amp; Zone Risk Breakdown
          </h3>
          <div className="space-y-2.5">
            {categoryEntries.map(([cat, count]) => (
              <div key={cat} className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-300">{cat}</span>
                  <span className="font-mono font-bold text-white">{count}</span>
                </div>
                <div className="h-2 rounded-full bg-slate-900 overflow-hidden">
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-cyan-500 to-rose-500"
                    style={{ width: `${Math.round((count / maxCatCount) * 100)}%` }}
                  />
                </div>
              </div>
            ))}
          </div>

          <div className="pt-3 border-t border-slate-800 space-y-2">
            <p className="text-xs font-bold text-slate-300">Top Hotspot Zones</p>
            {analytics.zoneBreakdown.slice(0, 4).map((z) => (
              <div
                key={z.zone}
                className="flex items-center justify-between text-xs rounded-lg bg-slate-900/60 px-3 py-1.5"
              >
                <span className="text-slate-300 truncate">{z.zone}</span>
                <span className="font-mono text-[11px] text-amber-300 shrink-0 ml-2">
                  {z.count} cases ({z.criticalCount} high/crit)
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
