import bcrypt from 'bcryptjs';
import { connectDatabase, disconnectDatabase } from '../config/database.js';
import { User } from '../models/User.js';
import { Incident } from '../models/Incident.js';
import { getOrCreateAdminSettings } from '../models/AdminSettings.js';
import { evaluateEmergencyTriage } from '../services/decisionEngine.js';
import { dispatchIncidentAlerts } from '../services/notificationService.js';

export async function seedDatabaseIfEmpty(): Promise<void> {
  await getOrCreateAdminSettings();

  const existingUsers = await User.countDocuments();
  if (existingUsers === 0) {
    const studentHash = await bcrypt.hash('Student@2AM', 10);
    const adminHash = await bcrypt.hash('Command@2AM', 10);

    await User.insertMany([
      {
        name: 'Aarav Mehta',
        email: 'student@campus.edu',
        passwordHash: studentHash,
        role: 'student',
        studentId: 'NRU-2026-4418',
        phone: '+1-555-0142',
        hostel: 'Aurora Residence Hall A (North)',
        department: 'Computer Science',
        emergencyContactName: 'Priya Mehta',
        emergencyContactPhone: '+1-555-0188',
      },
      {
        name: 'Maya Chen',
        email: 'maya.chen@campus.edu',
        passwordHash: studentHash,
        role: 'student',
        studentId: 'NRU-2026-5109',
        phone: '+1-555-0163',
        hostel: 'Cedar Women’s Residence C',
        department: 'Biomedical Engineering',
      },
      {
        name: 'Cmdr. Marcus Vance',
        email: 'admin@campus.edu',
        passwordHash: adminHash,
        role: 'admin',
        phone: '+1-555-0999',
        onDuty: true,
        responderUnit: 'Security Command HQ',
      },
      {
        name: 'Dr. Elena Rostova',
        email: 'medical.admin@campus.edu',
        passwordHash: adminHash,
        role: 'super_admin',
        phone: '+1-555-0911',
        onDuty: true,
        responderUnit: '24/7 Campus Trauma Clinic',
      },
    ]);
    console.log('[Seed] Created default student and command admin accounts.');
  }

  const existingIncidents = await Incident.countDocuments();
  if (existingIncidents === 0) {
    const student = await User.findOne({ email: 'student@campus.edu' });
    const now = Date.now();

    const seeds = [
      {
        incidentCode: '2AM-8841-01',
        emergencyType: 'Medical Emergency' as const,
        severity: 'Critical' as const,
        status: 'active' as const,
        description:
          'Roommate collapsed in 3rd-floor study lounge with dizziness and shortness of breath.',
        contactNumber: '+1-555-0142',
        isPanicMode: false,
        location: {
          method: 'hostel' as const,
          label: 'Aurora Residence Hall A (North)',
          zone: 'North Residential Quad',
          nodeId: 'hostel-aurora-a',
          floorOrRoom: 'Floor 3 · Study Lounge',
          coordinates: { lat: 37.4314, lng: -122.1728 },
        },
        createdAt: new Date(now - 14 * 60 * 1000),
        ackSeconds: 32,
        assignedResponder: 'Campus Ambulance Unit #1',
      },
      {
        incidentCode: '2AM-7732-02',
        emergencyType: 'Personal Safety' as const,
        severity: 'High' as const,
        status: 'pending' as const,
        description:
          'Walking back from BioSciences wing; exterior path lights are flickering and someone is loitering near Lot C.',
        contactNumber: '+1-555-0163',
        isPanicMode: false,
        location: {
          method: 'building' as const,
          label: 'BioSciences & Chemistry Research Wing',
          zone: 'East Research Park',
          nodeId: 'bldg-science-labs',
          floorOrRoom: 'West Exit Walkway',
          coordinates: { lat: 37.4281, lng: -122.1656 },
        },
        createdAt: new Date(now - 3 * 60 * 1000),
      },
      {
        incidentCode: '2AM-6190-03',
        emergencyType: 'Hostel Problems' as const,
        severity: 'High' as const,
        status: 'escalated' as const,
        description:
          'Electrical panel sparking on Floor 2 corridor and elevator doors jammed between floors.',
        contactNumber: '+1-555-0177',
        isPanicMode: false,
        location: {
          method: 'hostel' as const,
          label: 'Beacon Engineering Hall B',
          zone: 'North Residential Quad',
          nodeId: 'hostel-beacon-b',
          floorOrRoom: 'Floor 2 · East Wing',
          coordinates: { lat: 37.4309, lng: -122.1699 },
        },
        createdAt: new Date(now - 9 * 60 * 1000),
        autoEscalated: true,
      },
      {
        incidentCode: '2AM-5402-04',
        emergencyType: 'Mental Health' as const,
        severity: 'Medium' as const,
        status: 'resolved' as const,
        description:
          'Experiencing severe anxiety and panic attack ahead of thesis defense; need someone to talk to.',
        contactNumber: '+1-555-0194',
        isPanicMode: false,
        location: {
          method: 'building' as const,
          label: 'Central Library (24/7 Late-Night Study Wing)',
          zone: 'Academic Core',
          nodeId: 'bldg-central-library',
          floorOrRoom: 'Floor 2 Quiet Zone',
          coordinates: { lat: 37.4276, lng: -122.1695 },
        },
        createdAt: new Date(now - 115 * 60 * 1000),
        ackSeconds: 41,
        resolveSeconds: 1320,
        assignedResponder: 'On-Call Crisis Counselor (Dr. Lin)',
      },
      {
        incidentCode: '2AM-4108-05',
        emergencyType: 'Lost on Campus' as const,
        severity: 'Low' as const,
        status: 'resolved' as const,
        description:
          'Visiting exchange student disoriented near Athletics Perimeter Track; phone at 8% battery.',
        contactNumber: '+1-555-0129',
        isPanicMode: false,
        location: {
          method: 'gps' as const,
          label: 'Athletics Stadium & Perimeter Track',
          zone: 'East Athletics Perimeter',
          nodeId: 'bldg-sports-complex',
          coordinates: { lat: 37.4254, lng: -122.1642 },
          gpsAccuracyMeters: 14,
        },
        createdAt: new Date(now - 190 * 60 * 1000),
        ackSeconds: 55,
        resolveSeconds: 480,
        assignedResponder: 'Safe-Walk Electric Shuttle #2',
      },
      {
        incidentCode: '2AM-9015-06',
        emergencyType: 'Security Emergency' as const,
        severity: 'Critical' as const,
        status: 'resolved' as const,
        description:
          'Unauthorized individual tailgating into Cedar Women’s Residence C main lobby.',
        contactNumber: '+1-555-0163',
        isPanicMode: true,
        location: {
          method: 'map' as const,
          label: 'Cedar Women’s Residence C',
          zone: 'West Residential Commons',
          nodeId: 'hostel-cedar-c',
          floorOrRoom: 'Main Vestibule',
          coordinates: { lat: 37.4282, lng: -122.1749 },
        },
        createdAt: new Date(now - 260 * 60 * 1000),
        ackSeconds: 24,
        resolveSeconds: 310,
        assignedResponder: 'Patrol Unit Alpha + Shift Commander',
      },
    ];

    for (const s of seeds) {
      const triage = evaluateEmergencyTriage({
        emergencyType: s.emergencyType,
        severity: s.severity,
        description: s.description,
        locationNodeId: s.location.nodeId,
        isPanicMode: s.isPanicMode,
        timestamp: s.createdAt,
      });

      const timeline = [
        {
          eventType: (s.isPanicMode ? 'PANIC_TRIGGERED' : 'INCIDENT_CREATED') as 'PANIC_TRIGGERED' | 'INCIDENT_CREATED',
          title: s.isPanicMode
            ? 'PANIC MODE Beacon Activated'
            : 'Emergency Assistance Request Submitted',
          description: `${s.emergencyType} reported at ${s.location.label}.`,
          actorName: student?.name || 'Campus Student',
          actorRole: 'student',
          timestamp: s.createdAt,
        },
        {
          eventType: 'AI_TRIAGE_COMPLETED' as const,
          title: `AI Decision Engine: Risk Score ${triage.riskScore}/100`,
          description: triage.reasoning,
          actorName: 'Help@2AM Triage Engine',
          actorRole: 'system',
          timestamp: new Date(s.createdAt.getTime() + 2000),
        },
      ];

      if (s.ackSeconds) {
        timeline.push({
          eventType: 'ACKNOWLEDGED' as unknown as 'INCIDENT_CREATED',
          title: 'Acknowledged by Cmdr. Marcus Vance',
          description: `Acknowledged in ${s.ackSeconds}s.`,
          actorName: 'Cmdr. Marcus Vance',
          actorRole: 'admin',
          timestamp: new Date(s.createdAt.getTime() + s.ackSeconds * 1000),
        });
      }

      if (s.autoEscalated) {
        timeline.push({
          eventType: 'AUTO_ESCALATED' as unknown as 'INCIDENT_CREATED',
          title: 'No-Response Auto-Escalation to Level 2',
          description: 'Escalated automatically to Chief Security Commander after SLA timer elapsed.',
          actorName: 'Smart Escalation Engine',
          actorRole: 'system',
          timestamp: new Date(s.createdAt.getTime() + 125000),
        });
      }

      if (s.resolveSeconds) {
        timeline.push({
          eventType: 'RESOLVED' as unknown as 'INCIDENT_CREATED',
          title: 'Incident Resolved & Closed',
          description: 'Responder confirmed student safe and situation stabilized.',
          actorName: 'Cmdr. Marcus Vance',
          actorRole: 'admin',
          timestamp: new Date(s.createdAt.getTime() + s.resolveSeconds * 1000),
        });
      }

      const inc = await Incident.create({
        incidentCode: s.incidentCode,
        reporterId: student?._id,
        reporterName: student?.name || 'Campus Student',
        isAnonymous: false,
        isPanicMode: s.isPanicMode,
        emergencyType: s.emergencyType,
        severity: s.severity,
        aiAdjustedSeverity: triage.aiAdjustedSeverity,
        status: s.status,
        description: s.description,
        contactNumber: s.contactNumber,
        location: s.location,
        aiTriage: {
          riskScore: triage.riskScore,
          confidence: triage.confidence,
          detectedSignals: triage.detectedSignals,
          recommendedUnit: triage.recommendedUnit,
          routingTier: triage.routingTier,
          reasoning: triage.reasoning,
        },
        guidance: triage.guidance,
        escalation: {
          currentLevel: s.autoEscalated ? 2 : triage.routingTier,
          maxLevel: 3,
          escalatedCount: s.autoEscalated ? 1 : 0,
          autoEscalated: Boolean(s.autoEscalated),
          assignedResponder: s.assignedResponder,
          assignedAdminName: s.ackSeconds ? 'Cmdr. Marcus Vance' : undefined,
          nextEscalationAt:
            s.status === 'pending' ? new Date(Date.now() + 90 * 1000) : undefined,
        },
        metrics: {
          acknowledgedAt: s.ackSeconds
            ? new Date(s.createdAt.getTime() + s.ackSeconds * 1000)
            : undefined,
          resolvedAt: s.resolveSeconds
            ? new Date(s.createdAt.getTime() + s.resolveSeconds * 1000)
            : undefined,
          ackTimeSeconds: s.ackSeconds,
          resolveTimeSeconds: s.resolveSeconds,
        },
        timeline,
        createdAt: s.createdAt,
        updatedAt: s.createdAt,
      });

      await dispatchIncidentAlerts(inc, inc.escalation.currentLevel);
    }

    console.log('[Seed] Created 6 realistic campus emergency incidents & alert logs.');
  }
}

// Allow standalone CLI execution: `npm run seed`
const isDirectRun =
  typeof process !== 'undefined' &&
  process.argv[1] &&
  process.argv[1].endsWith('seedDatabase.ts');

if (isDirectRun) {
  connectDatabase()
    .then(() => seedDatabaseIfEmpty())
    .then(() => disconnectDatabase())
    .then(() => {
      console.log('[Seed] Done.');
      process.exit(0);
    })
    .catch((err) => {
      console.error('[Seed] Failed:', err);
      process.exit(1);
    });
}
