import { Response } from 'express';

interface SseClient {
  id: string;
  res: Response;
  channel: 'admin' | string; // 'admin' or incidentId
}

const clients: Map<string, SseClient> = new Map();

export function registerSseClient(
  id: string,
  res: Response,
  channel: string
): void {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders?.();

  res.write(`event: connected\ndata: ${JSON.stringify({ channel, ts: Date.now() })}\n\n`);
  clients.set(id, { id, res, channel });

  const heartbeat = setInterval(() => {
    if (!clients.has(id)) {
      clearInterval(heartbeat);
      return;
    }
    res.write(`: heartbeat\n\n`);
  }, 25000);

  res.on('close', () => {
    clearInterval(heartbeat);
    clients.delete(id);
  });
}

export function broadcastEvent(
  eventName: string,
  payload: Record<string, unknown>,
  incidentId?: string
): void {
  const serialized = `event: ${eventName}\ndata: ${JSON.stringify(payload)}\n\n`;
  for (const client of clients.values()) {
    if (
      client.channel === 'admin' ||
      (incidentId && client.channel === incidentId)
    ) {
      try {
        client.res.write(serialized);
      } catch {
        clients.delete(client.id);
      }
    }
  }
}
