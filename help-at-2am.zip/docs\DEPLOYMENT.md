# Production Campus Deployment Plan — Help at 2 A.M.

## 1. Infrastructure Topology

- **Reverse Proxy / TLS Termination**: Nginx or Caddy terminating HTTPS (`443`) for `help2am.university.edu` and proxying `/api/*` to the Node.js backend (`5000`) and `/*` to Next.js (`3000`). Enable `proxy_buffering off;` on `/api/admin/stream` and `/api/incidents/*/stream` for Server-Sent Events (SSE).
- **Database**: MongoDB 7.0 Replica Set or MongoDB Atlas M10+ with automated daily snapshots and TLS encryption in transit.
- **Container Orchestration**: `docker-compose.yml` included at repository root (or Kubernetes Deployment + HorizontalPodAutoscaler for multi-campus scale).

## 2. Environment Secrets Checklist

Configure in `.env` or secret manager (AWS Secrets Manager / Vault):
- `USE_IN_MEMORY_DB=false`
- `MONGODB_URI=mongodb+srv://<user>:<password>@cluster.mongodb.net/help_at_2am`
- `JWT_SECRET=<64-char cryptographic random string>`
- `FRONTEND_URL=https://help2am.university.edu`
- `NEXT_PUBLIC_API_URL=https://help2am.university.edu/api`
- `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, `TWILIO_SMS_FROM`, `TWILIO_WHATSAPP_FROM`
- `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASS`, `SMTP_FROM`

## 3. Deploying with Docker Compose

```bash
docker compose up -d --build
```

## 4. Campus Rollout & Operational Readiness

1. **Coordinate Calibration**: Update `backend/src/config/campusData.ts` with exact GPS lat/lng coordinates of every university residence hall, academic building, clinic, security gate, and blue-light pole.
2. **On-Duty Roster Integration**: Configure Tier 1 (Night Patrol & Medical), Tier 2 (Chief Security Commander), and Tier 3 (Dean On-Call) phone numbers and emails in **Admin Operations → Alert & Escalation Config** (`/admin/settings`).
3. **SLA Tuning**: Adjust auto-escalation SLA seconds (recommended: Critical `60s`, High `120s`, Medium `240s`, Low `420s`).
4. **Nightly Readiness Drill**: Run a simulated Panic Mode drill at 02:00 AM with campus patrol to verify Twilio SMS/WhatsApp delivery and sub-60s acknowledgment in the Operations Console.
