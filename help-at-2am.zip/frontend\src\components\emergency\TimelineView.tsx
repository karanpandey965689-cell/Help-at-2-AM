'use client';

import React from 'react';
import {
  Clock,
  AlertOctagon,
  Cpu,
  Send,
  UserCheck,
  ShieldCheck,
  ArrowUpCircle,
  MessageSquare,
} from 'lucide-react';
import { TimelineEvent } from '@/lib/types';

function getEventIcon(eventType: string) {
  switch (eventType) {
    case 'PANIC_TRIGGERED':
      return { icon: AlertOctagon, color: 'text-rose-400 bg-rose-500/15 border-rose-500/40' };
    case 'AI_TRIAGE_COMPLETED':
      return { icon: Cpu, color: 'text-cyan-400 bg-cyan-500/15 border-cyan-500/40' };
    case 'ALERT_DISPATCHED':
      return { icon: Send, color: 'text-amber-400 bg-amber-500/15 border-amber-500/40' };
    case 'ACKNOWLEDGED':
    case 'RESPONDER_ASSIGNED':
      return { icon: UserCheck, color: 'text-sky-400 bg-sky-500/15 border-sky-500/40' };
    case 'AUTO_ESCALATED':
    case 'MANUAL_ESCALATED':
      return { icon: ArrowUpCircle, color: 'text-rose-400 bg-rose-500/20 border-rose-500/50' };
    case 'RESOLVED':
      return { icon: ShieldCheck, color: 'text-emerald-400 bg-emerald-500/15 border-emerald-500/40' };
    default:
      return { icon: MessageSquare, color: 'text-slate-300 bg-slate-800 border-slate-700' };
  }
}

export function TimelineView({ events }: { events: TimelineEvent[] }) {
  return (
    <div className="space-y-3">
      {events.map((ev, idx) => {
        const cfg = getEventIcon(ev.eventType);
        const Icon = cfg.icon;
        return (
          <div key={ev._id || idx} className="relative flex gap-3.5">
            {idx < events.length - 1 && (
              <div className="absolute left-4 top-9 bottom-0 w-px bg-slate-800" />
            )}
            <div
              className={`relative z-10 flex h-8 w-8 shrink-0 items-center justify-center rounded-full border ${cfg.color}`}
            >
              <Icon className="h-4 w-4" />
            </div>
            <div className="flex-1 rounded-xl border border-slate-800/80 bg-slate-900/60 p-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <p className="text-xs font-bold text-white">{ev.title}</p>
                <span className="inline-flex items-center gap-1 font-mono text-[10px] text-slate-400">
                  <Clock className="h-3 w-3" />
                  {new Date(ev.timestamp).toLocaleTimeString()}
                </span>
              </div>
              <p className="mt-1 text-xs text-slate-300 leading-relaxed">
                {ev.description}
              </p>
              <p className="mt-1.5 font-mono text-[10px] uppercase text-slate-500">
                Actor: {ev.actorName} ({ev.actorRole})
              </p>
            </div>
          </div>
        );
      })}
    </div>
  );
}
