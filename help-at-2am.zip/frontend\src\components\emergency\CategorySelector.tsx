'use client';

import React from 'react';
import { motion } from 'framer-motion';
import {
  Stethoscope,
  ShieldAlert,
  UserCheck,
  HeartPulse,
  Building2,
  Compass,
  AlertCircle,
} from 'lucide-react';
import { EMERGENCY_CATEGORIES } from '@/lib/constants';
import { EmergencyCategory } from '@/lib/types';

const ICONS: Record<EmergencyCategory, React.ComponentType<{ className?: string }>> = {
  'Medical Emergency': Stethoscope,
  'Security Emergency': ShieldAlert,
  'Personal Safety': UserCheck,
  'Mental Health': HeartPulse,
  'Hostel Problems': Building2,
  'Lost on Campus': Compass,
  'Other Emergency': AlertCircle,
};

export function CategorySelector({
  selected,
  onSelect,
}: {
  selected: EmergencyCategory;
  onSelect: (category: EmergencyCategory) => void;
}) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
      {EMERGENCY_CATEGORIES.map((cat) => {
        const Icon = ICONS[cat.id];
        const isSelected = selected === cat.id;
        return (
          <motion.button
            key={cat.id}
            type="button"
            whileHover={{ y: -2 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => onSelect(cat.id)}
            className={`text-left rounded-2xl border p-4 transition-all ${
              isSelected
                ? 'border-cyan-400 bg-cyan-500/10 shadow-lg shadow-cyan-950/30 ring-1 ring-cyan-400/50'
                : 'border-slate-800 bg-slate-900/60 hover:border-slate-700 hover:bg-slate-900'
            }`}
          >
            <div className="flex items-start justify-between gap-2">
              <div
                className={`flex h-10 w-10 items-center justify-center rounded-xl border ${cat.accent}`}
              >
                <Icon className="h-5 w-5" />
              </div>
              <span
                className={`rounded-full border px-2 py-0.5 font-mono text-[10px] font-semibold ${cat.badgeBg}`}
              >
                {cat.defaultSeverity}
              </span>
            </div>
            <h3 className="mt-3 text-sm font-bold text-white">{cat.id}</h3>
            <p className="mt-1 text-xs leading-relaxed text-slate-400">
              {cat.tagline}
            </p>
          </motion.button>
        );
      })}
    </div>
  );
}
