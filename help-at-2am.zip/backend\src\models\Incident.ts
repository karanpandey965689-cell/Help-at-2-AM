import mongoose, { Document, Schema } from 'mongoose';

export type EmergencyCategory =
  | 'Medical Emergency'
  | 'Security Emergency'
  | 'Personal Safety'
  | 'Mental Health'
  | 'Hostel Problems'
  | 'Lost on Campus'
  | 'Other Emergency';

export type IncidentSeverity = 'Low' | 'Medium' | 'High' | 'Critical';

export type IncidentStatus = 'pending' | 'active' | 'escalated' | 'resolved';

export type LocationMethod = 'map' | 'hostel' | 'building' | 'gps';

export interface ITimelineEvent {
  eventType:
    | 'INCIDENT_CREATED'
    | 'PANIC_TRIGGERED'
    | 'AI_TRIAGE_COMPLETED'
    | 'ALERT_DISPATCHED'
    | 'ACKNOWLEDGED'
    | 'RESPONDER_ASSIGNED'
    | 'AUTO_ESCALATED'
    | 'MANUAL_ESCALATED'
    | 'STATUS_UPDATED'
    | 'NOTE_ADDED'
    | 'RESOLVED';
  title: string;
  description: string;
  actorName: string;
  actorRole: string;
  timestamp: Date;
  metadata?: Record<string, unknown>;
}

export interface IGuidanceSnapshot {
  recommendedActions: string[];
  emergencySteps: string[];
  contactSuggestions: Array<{
    name: string;
    role: string;
    phone: string;
    available24x7: boolean;
    priority: 'primary' | 'secondary' | 'external';
  }>;
  escalationFlow: Array<{
    level: number;
    targetRole: string;
    slaSeconds: number;
    action: string;
  }>;
}

export interface IIncident extends Document {
  incidentCode: string;
  reporterId?: mongoose.Types.ObjectId;
  reporterName: string;
  isAnonymous: boolean;
  isPanicMode: boolean;
  emergencyType: EmergencyCategory;
  severity: IncidentSeverity;
  aiAdjustedSeverity: IncidentSeverity;
  status: IncidentStatus;
  description: string;
  contactNumber: string;
  location: {
    method: LocationMethod;
    label: string;
    zone: string;
    nodeId?: string;
    floorOrRoom?: string;
    coordinates: {
      lat: number;
      lng: number;
    };
    gpsAccuracyMeters?: number;
  };
  aiTriage: {
    riskScore: number;
    confidence: number;
    detectedSignals: string[];
    recommendedUnit: string;
    routingTier: number;
    reasoning: string;
  };
  guidance: IGuidanceSnapshot;
  escalation: {
    currentLevel: 1 | 2 | 3;
    maxLevel: 3;
    nextEscalationAt?: Date;
    escalatedCount: number;
    autoEscalated: boolean;
    assignedResponder?: string;
    assignedAdminName?: string;
  };
  metrics: {
    acknowledgedAt?: Date;
    dispatchedAt?: Date;
    resolvedAt?: Date;
    ackTimeSeconds?: number;
    resolveTimeSeconds?: number;
  };
  timeline: ITimelineEvent[];
  createdAt: Date;
  updatedAt: Date;
}

const TimelineEventSchema = new Schema<ITimelineEvent>(
  {
    eventType: { type: String, required: true },
    title: { type: String, required: true },
    description: { type: String, required: true },
    actorName: { type: String, required: true },
    actorRole: { type: String, required: true },
    timestamp: { type: Date, default: Date.now },
    metadata: { type: Schema.Types.Mixed },
  },
  { _id: true }
);

const IncidentSchema = new Schema<IIncident>(
  {
    incidentCode: { type: String, required: true, unique: true },
    reporterId: { type: Schema.Types.ObjectId, ref: 'User' },
    reporterName: { type: String, default: 'Campus Student' },
    isAnonymous: { type: Boolean, default: false },
    isPanicMode: { type: Boolean, default: false },
    emergencyType: {
      type: String,
      enum: [
        'Medical Emergency',
        'Security Emergency',
        'Personal Safety',
        'Mental Health',
        'Hostel Problems',
        'Lost on Campus',
        'Other Emergency',
      ],
      required: true,
    },
    severity: {
      type: String,
      enum: ['Low', 'Medium', 'High', 'Critical'],
      required: true,
    },
    aiAdjustedSeverity: {
      type: String,
      enum: ['Low', 'Medium', 'High', 'Critical'],
      required: true,
    },
    status: {
      type: String,
      enum: ['pending', 'active', 'escalated', 'resolved'],
      default: 'pending',
    },
    description: { type: String, required: true, trim: true },
    contactNumber: { type: String, required: true, trim: true },
    location: {
      method: { type: String, enum: ['map', 'hostel', 'building', 'gps'], required: true },
      label: { type: String, required: true },
      zone: { type: String, required: true },
      nodeId: { type: String },
      floorOrRoom: { type: String },
      coordinates: {
        lat: { type: Number, required: true },
        lng: { type: Number, required: true },
      },
      gpsAccuracyMeters: { type: Number },
    },
    aiTriage: {
      riskScore: { type: Number, required: true },
      confidence: { type: Number, required: true },
      detectedSignals: [{ type: String }],
      recommendedUnit: { type: String, required: true },
      routingTier: { type: Number, default: 1 },
      reasoning: { type: String, required: true },
    },
    guidance: {
      recommendedActions: [{ type: String }],
      emergencySteps: [{ type: String }],
      contactSuggestions: [
        {
          name: String,
          role: String,
          phone: String,
          available24x7: Boolean,
          priority: { type: String, enum: ['primary', 'secondary', 'external'] },
        },
      ],
      escalationFlow: [
        {
          level: Number,
          targetRole: String,
          slaSeconds: Number,
          action: String,
        },
      ],
    },
    escalation: {
      currentLevel: { type: Number, enum: [1, 2, 3], default: 1 },
      maxLevel: { type: Number, default: 3 },
      nextEscalationAt: { type: Date },
      escalatedCount: { type: Number, default: 0 },
      autoEscalated: { type: Boolean, default: false },
      assignedResponder: { type: String },
      assignedAdminName: { type: String },
    },
    metrics: {
      acknowledgedAt: { type: Date },
      dispatchedAt: { type: Date },
      resolvedAt: { type: Date },
      ackTimeSeconds: { type: Number },
      resolveTimeSeconds: { type: Number },
    },
    timeline: [TimelineEventSchema],
  },
  { timestamps: true }
);

IncidentSchema.index({ status: 1, createdAt: -1 });
IncidentSchema.index({ emergencyType: 1, severity: 1 });
IncidentSchema.index({ 'escalation.nextEscalationAt': 1, status: 1 });
IncidentSchema.index({ 'location.zone': 1 });

export const Incident = mongoose.model<IIncident>('Incident', IncidentSchema);
