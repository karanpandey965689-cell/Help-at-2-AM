# Help at 2 A.M. — Campus Emergency Reporting, Guidance & Response Platform

A production-ready full-stack university late-night crisis guidance, emergency dispatch, and operations command platform.

## Architecture Overview

- **Frontend (`frontend/`)**: Next.js 15 (App Router), React 19, TypeScript, TailwindCSS, Framer Motion, Leaflet + OpenStreetMap
- **Backend (`backend/`)**: Node.js, Express, TypeScript, Mongoose (MongoDB), JWT Authentication, Zod validation, Server-Sent Events (SSE)
- **Notifications**: Twilio SMS, Twilio WhatsApp / Meta Cloud API adapter, Nodemailer SMTP Email adapter, with automatic audit-logged sandbox fallback when live keys are omitted
- **Autonomous Engines**:
  - **AI-like Decision Engine** (`decisionEngine.ts`) — evaluates severity keywords, late-night vulnerability window (23:00–06:00), and zone isolation risk to compute `riskScore`, dynamic severity overrides, recommended unit, and Immediate Guidance
  - **Smart Escalation & No-Response Watchdog** (`escalationWorker.ts`) — monitors SLA timers and auto-escalates unacknowledged incidents from Tier 1 → Tier 2 → Tier 3
  - **Emergency Readiness Score** (`readinessService.ts`) — live 0–100 composite score from responder coverage, SLA compliance, alert channel health, and open load

## Quick Start (Local Development)

### 1. Configure Environment
```bash
cp backend/.env.example backend/.env
cp frontend/.env.example frontend/.env.local
```
> By default `USE_IN_MEMORY_DB=true` in `backend/.env.example` allows running immediately without a local `mongod` daemon while exercising full Mongoose schemas, queries, and indexes. Set `USE_IN_MEMORY_DB=false` and `MONGODB_URI=mongodb://...` for persistent MongoDB / Atlas.

### 2. Install Dependencies
```bash
npm run install:all
```

### 3. Run Backend & Frontend
```bash
# Terminal 1 (API on http://localhost:5000)
npm run dev:backend

# Terminal 2 (Web App on http://localhost:3000)
npm run dev:frontend
```

### 4. Seeded Accounts (Auto-seeded on first startup)
- **Student**: `student@campus.edu` / `Student@2AM`
- **Command Admin**: `admin@campus.edu` / `Command@2AM`
- **Medical Super-Admin**: `medical.admin@campus.edu` / `Command@2AM`

## Verification & Tests
```bash
npm run test:backend
npm run build:backend
npm run build:frontend
```

## Documentation
- [System, Database, API & Notification Architecture](docs/ARCHITECTURE.md)
- [Campus Production Deployment Plan](docs/DEPLOYMENT.md)
