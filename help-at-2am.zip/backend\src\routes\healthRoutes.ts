import { Router } from 'express';
import mongoose from 'mongoose';
import { isUsingInMemoryDb } from '../config/database.js';

const router = Router();

router.get('/', (_req, res) => {
  res.json({
    status: 'operational',
    service: 'Help at 2 A.M. Campus Emergency Core API',
    timestamp: new Date().toISOString(),
    database: {
      connected: mongoose.connection.readyState === 1,
      mode: isUsingInMemoryDb() ? 'in-memory-sandbox' : 'mongodb',
    },
  });
});

export default router;
