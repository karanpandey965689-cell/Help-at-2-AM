import mongoose, { Document, Schema } from 'mongoose';

export type NotificationChannel = 'sms' | 'whatsapp' | 'email';
export type NotificationDeliveryStatus = 'sent' | 'simulated' | 'failed';

export interface INotificationLog extends Document {
  incidentId: mongoose.Types.ObjectId;
  incidentCode: string;
  channel: NotificationChannel;
  recipientName: string;
  recipientRole: string;
  recipientAddress: string;
  escalationLevel: 1 | 2 | 3;
  messageBody: string;
  status: NotificationDeliveryStatus;
  provider: string;
  providerMessageId?: string;
  errorMessage?: string;
  createdAt: Date;
}

const NotificationLogSchema = new Schema<INotificationLog>(
  {
    incidentId: { type: Schema.Types.ObjectId, ref: 'Incident', required: true },
    incidentCode: { type: String, required: true },
    channel: { type: String, enum: ['sms', 'whatsapp', 'email'], required: true },
    recipientName: { type: String, required: true },
    recipientRole: { type: String, required: true },
    recipientAddress: { type: String, required: true },
    escalationLevel: { type: Number, enum: [1, 2, 3], required: true },
    messageBody: { type: String, required: true },
    status: {
      type: String,
      enum: ['sent', 'simulated', 'failed'],
      required: true,
    },
    provider: { type: String, required: true },
    providerMessageId: { type: String },
    errorMessage: { type: String },
  },
  { timestamps: true }
);

NotificationLogSchema.index({ incidentId: 1, createdAt: -1 });
NotificationLogSchema.index({ createdAt: -1 });

export const NotificationLog = mongoose.model<INotificationLog>(
  'NotificationLog',
  NotificationLogSchema
);
