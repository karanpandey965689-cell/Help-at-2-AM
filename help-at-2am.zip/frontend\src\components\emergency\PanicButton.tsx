'use client';

import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useRouter } from 'next/navigation';
import { AlertOctagon, Loader2, ShieldAlert } from 'lucide-react';
import { apiRequest } from '@/lib/api';
import { EmergencyCategory, IncidentRecord } from '@/lib/types';

export function PanicButton({
  contactNumber = '+1-555-0199',
  category = 'Security Emergency',
  size = 'lg',
}: {
  contactNumber?: string;
  category?: EmergencyCategory;
  size?: 'md' | 'lg';
}) {
  const router = useRouter();
  const [triggering, setTriggering] = useState(false);
  const [error, setError] = useState('');

  const handlePanic = async () => {
    setError('');
    setTriggering(true);

    const getCoords = (): Promise<{ lat: number; lng: number; accuracy?: number } | undefined> =>
      new Promise((resolve) => {
        if (typeof navigator === 'undefined' || !navigator.geolocation) {
          resolve(undefined);
          return;
        }
        navigator.geolocation.getCurrentPosition(
          (pos) =>
            resolve({
              lat: pos.coords.latitude,
              lng: pos.coords.longitude,
              accuracy: Math.round(pos.coords.accuracy),
            }),
          () => resolve(undefined),
          { enableHighAccuracy: true, timeout: 3500 }
        );
      });

    try {
      const coordinates = await getCoords();
      const res = await apiRequest<{ incident: IncidentRecord }>('/incidents/panic', {
        method: 'POST',
        body: JSON.stringify({
          contactNumber,
          emergencyType: category,
          coordinates,
        }),
      });
      router.push(`/incidents/${res.incident._id}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to send panic signal');
      setTriggering(false);
    }
  };

  return (
    <div className="flex flex-col items-center">
      <motion.button
        type="button"
        whileHover={{ scale: 1.03 }}
        whileTap={{ scale: 0.96 }}
        disabled={triggering}
        onClick={handlePanic}
        className={`panic-ring relative flex flex-col items-center justify-center rounded-full bg-gradient-to-b from-rose-500 via-rose-600 to-red-700 text-white shadow-2xl shadow-rose-950/70 border-4 border-rose-300/50 transition-all cursor-pointer disabled:opacity-75 ${
          size === 'lg' ? 'h-56 w-56 sm:h-64 sm:w-64' : 'h-40 w-40'
        }`}
      >
        {triggering ? (
          <Loader2 className="h-12 w-12 animate-spin text-white" />
        ) : (
          <AlertOctagon className={size === 'lg' ? 'h-14 w-14 mb-2' : 'h-10 w-10 mb-1'} />
        )}
        <span
          className={`font-black tracking-tight uppercase ${
            size === 'lg' ? 'text-2xl sm:text-3xl' : 'text-lg'
          }`}
        >
          {triggering ? 'DISPATCHING...' : 'HELP NOW'}
        </span>
        <span className="mt-1 font-mono text-[11px] uppercase tracking-widest text-rose-100/90">
          One-Click Panic
        </span>
      </motion.button>

      {error && (
        <div className="mt-4 flex items-center gap-2 rounded-xl border border-rose-500/40 bg-rose-500/10 px-4 py-2 text-xs text-rose-200">
          <ShieldAlert className="h-4 w-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}
    </div>
  );
}
