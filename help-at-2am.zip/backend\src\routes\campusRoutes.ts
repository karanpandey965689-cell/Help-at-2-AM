import { Router } from 'express';
import {
  CAMPUS_CENTER,
  CAMPUS_LOCATIONS,
  SAFE_WALK_CORRIDORS,
  findNearestCampusNode,
} from '../config/campusData.js';
import { calculateEmergencyReadiness } from '../services/readinessService.js';

const router = Router();

router.get('/locations', (_req, res) => {
  res.json({
    center: CAMPUS_CENTER,
    locations: CAMPUS_LOCATIONS,
    safeWalkCorridors: SAFE_WALK_CORRIDORS,
  });
});

router.get('/nearest', (req, res) => {
  const lat = parseFloat(String(req.query.lat || CAMPUS_CENTER.lat));
  const lng = parseFloat(String(req.query.lng || CAMPUS_CENTER.lng));
  if (Number.isNaN(lat) || Number.isNaN(lng)) {
    res.status(400).json({ error: 'Invalid lat/lng coordinates' });
    return;
  }
  const nearest = findNearestCampusNode(lat, lng);
  res.json({ nearest });
});

router.get('/readiness', async (_req, res) => {
  const readiness = await calculateEmergencyReadiness();
  res.json(readiness);
});

export default router;
