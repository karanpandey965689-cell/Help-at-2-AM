import { Router } from 'express';
import { z } from 'zod';
import {
  evaluateEmergencyTriage,
  getGuidanceForCategory,
} from '../services/decisionEngine.js';
import { validateBody } from '../middleware/validate.js';
import { EmergencyCategory, IncidentSeverity } from '../models/Incident.js';

const router = Router();

const previewSchema = z.object({
  emergencyType: z.enum([
    'Medical Emergency',
    'Security Emergency',
    'Personal Safety',
    'Mental Health',
    'Hostel Problems',
    'Lost on Campus',
    'Other Emergency',
  ]),
  severity: z.enum(['Low', 'Medium', 'High', 'Critical']).default('Medium'),
  description: z.string().default(''),
  locationNodeId: z.string().optional(),
});

router.get('/categories', (_req, res) => {
  const categories: EmergencyCategory[] = [
    'Medical Emergency',
    'Security Emergency',
    'Personal Safety',
    'Mental Health',
    'Hostel Problems',
    'Lost on Campus',
    'Other Emergency',
  ];
  res.json({
    categories: categories.map((category) => ({
      category,
      guidance: getGuidanceForCategory(category, 'Medium'),
    })),
  });
});

router.post('/evaluate', validateBody(previewSchema), (req, res) => {
  const { emergencyType, severity, description, locationNodeId } = req.body as {
    emergencyType: EmergencyCategory;
    severity: IncidentSeverity;
    description: string;
    locationNodeId?: string;
  };
  const triage = evaluateEmergencyTriage({
    emergencyType,
    severity,
    description,
    locationNodeId,
  });
  res.json({ triage });
});

export default router;
