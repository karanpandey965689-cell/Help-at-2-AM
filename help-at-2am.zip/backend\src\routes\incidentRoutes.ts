import { Router, Response } from 'express';
import mongoose from 'mongoose';
import { z } from 'zod';
import { Incident, ITimelineEvent } from '../models/Incident.js';
import { NotificationLog } from '../models/NotificationLog.js';
import { getOrCreateAdminSettings } from '../models/AdminSettings.js';
import { evaluateEmergencyTriage } from '../services/decisionEngine.js';
import { dispatchIncidentAlerts } from '../services/notificationService.js';
import { broadcastEvent, registerSseClient } from '../services/sseService.js';
import { CAMPUS_CENTER, findNearestCampusNode } from '../config/campusData.js';
import {
  AuthenticatedRequest,
  optionalAuth,
  requireAuth,
} from '../middleware/auth.js';
import { validateBody } from '../middleware/validate.js';

const router = Router();

const createIncidentSchema = z.object({
  emergencyType: z.enum([
    'Medical Emergency',
    'Security Emergency',
    'Personal Safety',
    'Mental Health',
    'Hostel Problems',
    'Lost on Campus',
    'Other Emergency',
  ]),
  severity: z.enum(['Low', 'Medium', 'High', 'Critical']),
  description: z.string().min(5, 'Please provide at least a brief description').max(2000),
  contactNumber: z.string().min(5, 'Contact number is required').max(30),
  isAnonymous: z.boolean().optional().default(false),
  isPanicMode: z.boolean().optional().default(false),
  location: z.object({
    method: z.enum(['map', 'hostel', 'building', 'gps']),
    label: z.string().min(2),
    zone: z.string().min(2),
    nodeId: z.string().optional(),
    floorOrRoom: z.string().optional(),
    coordinates: z.object({
      lat: z.number(),
      lng: z.number(),
    }),
    gpsAccuracyMeters: z.number().optional(),
  }),
});

const panicSchema = z.object({
  contactNumber: z.string().optional().default('GPS-ONLY / CHECK PROFILE'),
  emergencyType: z
    .enum([
      'Medical Emergency',
      'Security Emergency',
      'Personal Safety',
      'Mental Health',
      'Hostel Problems',
      'Lost on Campus',
      'Other Emergency',
    ])
    .optional()
    .default('Security Emergency'),
  description: z
    .string()
    .optional()
    .default('ONE-CLICK PANIC MODE ACTIVATED: Immediate assistance requested at student coordinates.'),
  coordinates: z
    .object({
      lat: z.number(),
      lng: z.number(),
      accuracy: z.number().optional(),
    })
    .optional(),
});

const noteSchema = z.object({
  note: z.string().min(2).max(1000),
});

function generateIncidentCode(): string {
  const num = Math.floor(1000 + Math.random() * 9000);
  const suffix = Date.now().toString().slice(-3);
  return `2AM-${num}-${suffix}`;
}

async function createAndDispatchIncident(
  payload: z.infer<typeof createIncidentSchema>,
  user?: AuthenticatedRequest['user']
) {
  const settings = await getOrCreateAdminSettings();
  const triage = evaluateEmergencyTriage({
    emergencyType: payload.emergencyType,
    severity: payload.severity,
    description: payload.description,
    locationNodeId: payload.location.nodeId,
    isPanicMode: payload.isPanicMode,
  });

  const effectiveSeverity = triage.aiAdjustedSeverity;
  const slaSeconds = settings.slaSeconds[effectiveSeverity] || 120;
  const incidentCode = generateIncidentCode();

  const reporterName = payload.isAnonymous
    ? 'Anonymous Student'
    : user?.name || 'Campus Student';

  const initialTimeline: ITimelineEvent[] = [
    {
      eventType: payload.isPanicMode ? 'PANIC_TRIGGERED' : 'INCIDENT_CREATED',
      title: payload.isPanicMode
        ? 'PANIC MODE Beacon Activated'
        : 'Emergency Assistance Request Submitted',
      description: `${payload.emergencyType} reported at ${payload.location.label} via ${payload.location.method.toUpperCase()}.`,
      actorName: reporterName,
      actorRole: 'student',
      timestamp: new Date(),
    },
    {
      eventType: 'AI_TRIAGE_COMPLETED',
      title: `AI Decision Engine: Risk Score ${triage.riskScore}/100 (${effectiveSeverity})`,
      description: triage.reasoning,
      actorName: 'Help@2AM Triage Engine',
      actorRole: 'system',
      timestamp: new Date(),
      metadata: {
        riskScore: triage.riskScore,
        recommendedUnit: triage.recommendedUnit,
        signals: triage.detectedSignals,
      },
    },
  ];

  const incident = await Incident.create({
    incidentCode,
    reporterId: user?.userId,
    reporterName,
    isAnonymous: payload.isAnonymous,
    isPanicMode: payload.isPanicMode,
    emergencyType: payload.emergencyType,
    severity: payload.severity,
    aiAdjustedSeverity: effectiveSeverity,
    status: 'pending',
    description: payload.description,
    contactNumber: payload.contactNumber,
    location: payload.location,
    aiTriage: {
      riskScore: triage.riskScore,
      confidence: triage.confidence,
      detectedSignals: triage.detectedSignals,
      recommendedUnit: triage.recommendedUnit,
      routingTier: triage.routingTier,
      reasoning: triage.reasoning,
    },
    guidance: triage.guidance,
    escalation: {
      currentLevel: triage.routingTier,
      maxLevel: 3,
      nextEscalationAt: new Date(Date.now() + slaSeconds * 1000),
      escalatedCount: 0,
      autoEscalated: false,
    },
    timeline: initialTimeline,
  });

  const dispatchRes = await dispatchIncidentAlerts(incident, triage.routingTier, {
    includeLowerLevels: payload.isPanicMode || effectiveSeverity === 'Critical',
    escalationNote: payload.isPanicMode ? 'PANIC BEACON' : undefined,
  });

  incident.timeline.push({
    eventType: 'ALERT_DISPATCHED',
    title: `Multi-Channel Alerts Sent (${dispatchRes.channelsUsed.join(', ').toUpperCase() || 'CONSOLE'})`,
    description: `${dispatchRes.dispatchedCount} administrator notification(s) dispatched at Tier ${triage.routingTier}.`,
    actorName: 'Notification Router',
    actorRole: 'system',
    timestamp: new Date(),
    metadata: {
      dispatchedCount: dispatchRes.dispatchedCount,
      channelsUsed: dispatchRes.channelsUsed,
    },
  });

  await incident.save();

  broadcastEvent('incident:created', {
    incident: incident.toObject(),
    alertPreview: dispatchRes.messageBody,
  });

  return { incident, alertPreview: dispatchRes.messageBody, dispatchRes };
}

router.post(
  '/',
  optionalAuth,
  validateBody(createIncidentSchema),
  async (req: AuthenticatedRequest, res: Response) => {
    const result = await createAndDispatchIncident(req.body, req.user);
    res.status(201).json({
      incident: result.incident,
      alertMessage: result.alertPreview,
      notificationsDispatched: result.dispatchRes.dispatchedCount,
      channelsUsed: result.dispatchRes.channelsUsed,
    });
  }
);

router.post(
  '/panic',
  optionalAuth,
  validateBody(panicSchema),
  async (req: AuthenticatedRequest, res: Response) => {
    const { contactNumber, emergencyType, description, coordinates } = req.body;
    const lat = coordinates?.lat ?? CAMPUS_CENTER.lat;
    const lng = coordinates?.lng ?? CAMPUS_CENTER.lng;
    const nearest = findNearestCampusNode(lat, lng);

    const payload: z.infer<typeof createIncidentSchema> = {
      emergencyType,
      severity: 'Critical',
      description,
      contactNumber,
      isAnonymous: false,
      isPanicMode: true,
      location: {
        method: coordinates ? 'gps' : 'map',
        label: `Near ${nearest.name}`,
        zone: nearest.zone,
        nodeId: nearest.id,
        coordinates: { lat, lng },
        gpsAccuracyMeters: coordinates?.accuracy,
      },
    };

    const result = await createAndDispatchIncident(payload, req.user);
    res.status(201).json({
      incident: result.incident,
      alertMessage: result.alertPreview,
      notificationsDispatched: result.dispatchRes.dispatchedCount,
      channelsUsed: result.dispatchRes.channelsUsed,
    });
  }
);

router.get('/my', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  const incidents = await Incident.find({ reporterId: req.user!.userId })
    .sort({ createdAt: -1 })
    .limit(50);
  res.json({ incidents });
});

function buildIncidentLookup(rawId: string | string[] | undefined) {
  const id = Array.isArray(rawId) ? rawId[0] : String(rawId || '');
  return mongoose.Types.ObjectId.isValid(id)
    ? { $or: [{ _id: id }, { incidentCode: id }] }
    : { incidentCode: id };
}

router.get('/:id', async (req, res: Response) => {
  const query = buildIncidentLookup(req.params.id);

  const incident = await Incident.findOne(query);
  if (!incident) {
    res.status(404).json({ error: 'Incident not found' });
    return;
  }

  const notifications = await NotificationLog.find({ incidentId: incident._id })
    .sort({ createdAt: -1 })
    .limit(30);

  res.json({ incident, notifications });
});

router.get('/:id/stream', async (req, res: Response) => {
  const query = buildIncidentLookup(req.params.id);

  const incident = await Incident.findOne(query).select('_id');
  if (!incident) {
    res.status(404).json({ error: 'Incident not found' });
    return;
  }
  const clientId = `inc-${incident._id.toString()}-${Date.now()}-${Math.random()}`;
  registerSseClient(clientId, res, incident._id.toString());
});

router.post(
  '/:id/note',
  optionalAuth,
  validateBody(noteSchema),
  async (req: AuthenticatedRequest, res: Response) => {
    const query = buildIncidentLookup(req.params.id);

    const incident = await Incident.findOne(query);
    if (!incident) {
      res.status(404).json({ error: 'Incident not found' });
      return;
    }

    incident.timeline.push({
      eventType: 'NOTE_ADDED',
      title: 'Live Situation Update',
      description: req.body.note,
      actorName: req.user?.name || incident.reporterName || 'Reporter',
      actorRole: req.user?.role || 'student',
      timestamp: new Date(),
    });

    await incident.save();
    broadcastEvent(
      'incident:updated',
      { incident: incident.toObject() },
      incident._id.toString()
    );
    res.json({ incident });
  }
);

export default router;
