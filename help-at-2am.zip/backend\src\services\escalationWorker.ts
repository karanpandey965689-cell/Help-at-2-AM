import { Incident } from '../models/Incident.js';
import { getOrCreateAdminSettings } from '../models/AdminSettings.js';
import { dispatchIncidentAlerts } from './notificationService.js';
import { broadcastEvent } from './sseService.js';
import { env } from '../config/env.js';

let workerTimer: NodeJS.Timeout | null = null;

export async function runEscalationSweep(): Promise<number> {
  const settings = await getOrCreateAdminSettings();
  if (!settings.escalationEnabled) return 0;

  const now = new Date();
  const overdueIncidents = await Incident.find({
    status: { $in: ['pending', 'escalated'] },
    'metrics.acknowledgedAt': { $exists: false },
    'escalation.currentLevel': { $lt: 3 },
    'escalation.nextEscalationAt': { $lte: now },
  });

  let escalatedCount = 0;

  for (const incident of overdueIncidents) {
    const nextLevel = Math.min(3, incident.escalation.currentLevel + 1) as 1 | 2 | 3;
    const sev = incident.aiAdjustedSeverity || incident.severity;
    const sla = settings.slaSeconds[sev] || 120;

    incident.status = 'escalated';
    incident.escalation.currentLevel = nextLevel;
    incident.escalation.escalatedCount += 1;
    incident.escalation.autoEscalated = true;
    incident.escalation.nextEscalationAt =
      nextLevel < 3 ? new Date(Date.now() + sla * 1000) : undefined;

    incident.timeline.push({
      eventType: 'AUTO_ESCALATED',
      title: `No-Response Auto-Escalation to Level ${nextLevel}`,
      description: `Unacknowledged within ${sla}s SLA. Automatically routed to Tier ${nextLevel} command.`,
      actorName: 'Smart Escalation Engine',
      actorRole: 'system',
      timestamp: new Date(),
      metadata: { level: nextLevel, slaSeconds: sla },
    });

    const dispatchRes = await dispatchIncidentAlerts(incident, nextLevel, {
      escalationNote: `NO-RESPONSE AUTO-ESCALATION (TIER ${nextLevel})`,
    });

    incident.timeline.push({
      eventType: 'ALERT_DISPATCHED',
      title: `Tier ${nextLevel} Escalation Alerts Sent`,
      description: `Dispatched ${dispatchRes.dispatchedCount} alert(s) via ${dispatchRes.channelsUsed.join(', ').toUpperCase()}.`,
      actorName: 'Notification Router',
      actorRole: 'system',
      timestamp: new Date(),
    });

    await incident.save();

    broadcastEvent(
      'incident:escalated',
      { incident: incident.toObject() },
      incident._id.toString()
    );
    escalatedCount++;
  }

  return escalatedCount;
}

export function startEscalationWorker(): void {
  if (workerTimer) return;
  workerTimer = setInterval(() => {
    runEscalationSweep().catch((err) => {
      console.error('[EscalationWorker] Sweep error:', err);
    });
  }, env.escalationCheckIntervalMs);
  console.log(
    `[EscalationWorker] Started (interval: ${env.escalationCheckIntervalMs}ms)`
  );
}

export function stopEscalationWorker(): void {
  if (workerTimer) {
    clearInterval(workerTimer);
    workerTimer = null;
  }
}
