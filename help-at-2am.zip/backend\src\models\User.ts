import mongoose, { Document, Schema } from 'mongoose';
import bcrypt from 'bcryptjs';

export type UserRole = 'student' | 'responder' | 'admin' | 'super_admin';

export interface IUser extends Document {
  name: string;
  email: string;
  passwordHash: string;
  role: UserRole;
  studentId?: string;
  phone: string;
  hostel?: string;
  department?: string;
  emergencyContactName?: string;
  emergencyContactPhone?: string;
  onDuty?: boolean;
  responderUnit?: string;
  createdAt: Date;
  updatedAt: Date;
  comparePassword(candidate: string): Promise<boolean>;
}

const UserSchema = new Schema<IUser>(
  {
    name: { type: String, required: true, trim: true },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    passwordHash: { type: String, required: true },
    role: {
      type: String,
      enum: ['student', 'responder', 'admin', 'super_admin'],
      default: 'student',
    },
    studentId: { type: String, trim: true },
    phone: { type: String, required: true, trim: true },
    hostel: { type: String, trim: true },
    department: { type: String, trim: true },
    emergencyContactName: { type: String, trim: true },
    emergencyContactPhone: { type: String, trim: true },
    onDuty: { type: Boolean, default: false },
    responderUnit: { type: String, trim: true },
  },
  { timestamps: true }
);

UserSchema.index({ role: 1, onDuty: 1 });

UserSchema.methods.comparePassword = async function (candidate: string): Promise<boolean> {
  return bcrypt.compare(candidate, this.passwordHash);
};

export const User = mongoose.model<IUser>('User', UserSchema);
