'use client';

import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import {
  ArrowLeft,
  Save,
  Plus,
  Trash2,
  BellRing,
  Clock,
  ShieldCheck,
  Loader2,
} from 'lucide-react';
import { apiRequest } from '@/lib/api';
import { useAuth } from '@/lib/authContext';
import {
  AdminContactRecipient,
  AdminSettingsData,
} from '@/lib/types';

export default function AdminSettingsPage() {
  const { user } = useAuth();
  const [settings, setSettings] = useState<AdminSettingsData | null>(null);
  const [saving, setSaving] = useState(false);
  const [savedBanner, setSavedBanner] = useState('');

  useEffect(() => {
    apiRequest<{ settings: AdminSettingsData }>('/admin/settings')
      .then((res) => setSettings(res.settings))
      .catch(() => {});
  }, []);

  if (!user || (user.role !== 'admin' && user.role !== 'super_admin')) {
    return (
      <div className="mx-auto max-w-xl px-4 py-16 text-center space-y-4">
        <p className="text-sm text-slate-300">
          Administrator authentication is required to modify alert routing and SLA settings.
        </p>
        <Link
          href="/admin"
          className="inline-flex items-center gap-2 rounded-xl bg-cyan-500 px-5 py-2.5 text-xs font-bold text-slate-950"
        >
          Go to Admin Operations Sign In
        </Link>
      </div>
    );
  }

  if (!settings) {
    return (
      <div className="mx-auto max-w-5xl px-6 py-16 flex items-center gap-2 text-slate-400 text-sm">
        <Loader2 className="h-4 w-4 animate-spin text-cyan-400" />
        Loading alert configuration...
      </div>
    );
  }

  const updateRecipient = (
    idx: number,
    patch: Partial<AdminContactRecipient>
  ) => {
    const next = [...settings.recipients];
    next[idx] = { ...next[idx], ...patch };
    setSettings({ ...settings, recipients: next });
  };

  const addRecipient = () => {
    setSettings({
      ...settings,
      recipients: [
        ...settings.recipients,
        {
          name: 'On-Duty Campus Supervisor',
          role: 'Night Shift Responder',
          level: 1,
          smsPhone: '+15550199999',
          whatsappPhone: '+15550199999',
          email: 'supervisor@campus-safety.edu',
          categories: ['Security Emergency', 'Personal Safety'],
          active: true,
        },
      ],
    });
  };

  const removeRecipient = (idx: number) => {
    setSettings({
      ...settings,
      recipients: settings.recipients.filter((_, i) => i !== idx),
    });
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setSavedBanner('');
    try {
      const res = await apiRequest<{ settings: AdminSettingsData }>(
        '/admin/settings',
        {
          method: 'PUT',
          body: JSON.stringify(settings),
        }
      );
      setSettings(res.settings);
      setSavedBanner('Alert channels, SLA timers, and admin contacts saved.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="mx-auto max-w-5xl px-4 py-8 sm:px-6 space-y-6">
      <div className="flex items-center justify-between gap-4">
        <div>
          <Link
            href="/admin"
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-400 hover:text-white mb-2"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to Operations Command
          </Link>
          <h1 className="text-2xl font-black text-white">
            Alert Channels, Escalation SLAs &amp; Admin Contact Routing
          </h1>
        </div>
      </div>

      <form onSubmit={handleSave} className="space-y-6">
        {/* Notification Channels */}
        <section className="glass-panel rounded-2xl p-6 space-y-4">
          <h2 className="flex items-center gap-2 text-sm font-bold text-white">
            <BellRing className="h-4 w-4 text-cyan-400" />
            Active Notification Transports
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {(
              [
                { key: 'smsEnabled', label: 'SMS Gateway (Twilio)' },
                { key: 'whatsappEnabled', label: 'WhatsApp Business Alerts' },
                { key: 'emailEnabled', label: 'Email Dispatch (SMTP)' },
              ] as const
            ).map((ch) => (
              <label
                key={ch.key}
                className="flex items-center justify-between rounded-xl border border-slate-800 bg-slate-900/70 p-3.5 cursor-pointer"
              >
                <span className="text-xs font-semibold text-white">
                  {ch.label}
                </span>
                <input
                  type="checkbox"
                  checked={settings.channels[ch.key]}
                  onChange={(e) =>
                    setSettings({
                      ...settings,
                      channels: {
                        ...settings.channels,
                        [ch.key]: e.target.checked,
                      },
                    })
                  }
                  className="h-4 w-4 rounded text-cyan-500"
                />
              </label>
            ))}
          </div>
        </section>

        {/* Escalation SLA Timers & Readiness Resources */}
        <section className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <div className="glass-panel rounded-2xl p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="flex items-center gap-2 text-sm font-bold text-white">
                <Clock className="h-4 w-4 text-amber-400" />
                No-Response Auto-Escalation SLAs (Seconds)
              </h2>
              <label className="flex items-center gap-2 text-xs text-slate-300">
                <input
                  type="checkbox"
                  checked={settings.escalationEnabled}
                  onChange={(e) =>
                    setSettings({
                      ...settings,
                      escalationEnabled: e.target.checked,
                    })
                  }
                />
                Enabled
              </label>
            </div>

            <div className="grid grid-cols-2 gap-3">
              {(['Critical', 'High', 'Medium', 'Low'] as const).map((sev) => (
                <div key={sev}>
                  <label className="block text-[11px] font-semibold text-slate-400 mb-1">
                    {sev} SLA (sec)
                  </label>
                  <input
                    type="number"
                    min={15}
                    value={settings.slaSeconds[sev]}
                    onChange={(e) =>
                      setSettings({
                        ...settings,
                        slaSeconds: {
                          ...settings.slaSeconds,
                          [sev]: parseInt(e.target.value || '60', 10),
                        },
                      })
                    }
                    className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 font-mono text-xs text-white"
                  />
                </div>
              ))}
            </div>
          </div>

          <div className="glass-panel rounded-2xl p-6 space-y-4">
            <h2 className="flex items-center gap-2 text-sm font-bold text-white">
              <ShieldCheck className="h-4 w-4 text-emerald-400" />
              Active Campus Shift Staffing (Readiness Inputs)
            </h2>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-semibold text-slate-400 mb-1">
                  Active Patrol Units
                </label>
                <input
                  type="number"
                  min={0}
                  value={settings.readinessConfig.patrolUnitsActive}
                  onChange={(e) =>
                    setSettings({
                      ...settings,
                      readinessConfig: {
                        ...settings.readinessConfig,
                        patrolUnitsActive: parseInt(e.target.value || '0', 10),
                      },
                    })
                  }
                  className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 font-mono text-xs text-white"
                />
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-slate-400 mb-1">
                  Medical Staff On Duty
                </label>
                <input
                  type="number"
                  min={0}
                  value={settings.readinessConfig.medicalStaffOnDuty}
                  onChange={(e) =>
                    setSettings({
                      ...settings,
                      readinessConfig: {
                        ...settings.readinessConfig,
                        medicalStaffOnDuty: parseInt(e.target.value || '0', 10),
                      },
                    })
                  }
                  className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 font-mono text-xs text-white"
                />
              </div>
            </div>
            <label className="flex items-center gap-2 text-xs text-slate-300">
              <input
                type="checkbox"
                checked={settings.readinessConfig.counselorAvailable}
                onChange={(e) =>
                  setSettings({
                    ...settings,
                    readinessConfig: {
                      ...settings.readinessConfig,
                      counselorAvailable: e.target.checked,
                    },
                  })
                }
              />
              24/7 Mental Health Crisis Counselor On Call
            </label>
          </div>
        </section>

        {/* Configurable Admin Contact Recipients */}
        <section className="glass-panel rounded-2xl p-6 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-sm font-bold text-white">
                Multi-Level Admin Routing Directory (Tier 1 – Tier 3)
              </h2>
              <p className="text-xs text-slate-400">
                Configure SMS, WhatsApp, and Email endpoints for each escalation level.
              </p>
            </div>
            <button
              type="button"
              onClick={addRecipient}
              className="inline-flex items-center gap-1.5 rounded-xl border border-cyan-500/40 bg-cyan-500/10 px-3 py-2 text-xs font-bold text-cyan-300 hover:bg-cyan-500/20"
            >
              <Plus className="h-3.5 w-3.5" />
              Add Contact
            </button>
          </div>

          <div className="space-y-3">
            {settings.recipients.map((rec, idx) => (
              <div
                key={idx}
                className="rounded-xl border border-slate-800 bg-slate-900/60 p-4 space-y-3"
              >
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                  <input
                    value={rec.name}
                    onChange={(e) => updateRecipient(idx, { name: e.target.value })}
                    placeholder="Contact Name"
                    className="rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-xs text-white"
                  />
                  <input
                    value={rec.role}
                    onChange={(e) => updateRecipient(idx, { role: e.target.value })}
                    placeholder="Role"
                    className="rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-xs text-white"
                  />
                  <select
                    value={rec.level}
                    onChange={(e) =>
                      updateRecipient(idx, {
                        level: parseInt(e.target.value, 10) as 1 | 2 | 3,
                      })
                    }
                    className="rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-xs text-white"
                  >
                    <option value={1}>Tier 1 (Primary)</option>
                    <option value={2}>Tier 2 (Command Escalation)</option>
                    <option value={3}>Tier 3 (Executive / Dean)</option>
                  </select>
                  <div className="flex items-center justify-between gap-2">
                    <label className="flex items-center gap-1.5 text-xs text-slate-300">
                      <input
                        type="checkbox"
                        checked={rec.active}
                        onChange={(e) =>
                          updateRecipient(idx, { active: e.target.checked })
                        }
                      />
                      Active
                    </label>
                    <button
                      type="button"
                      onClick={() => removeRecipient(idx)}
                      className="rounded-lg p-1.5 text-rose-400 hover:bg-rose-500/15"
                      title="Remove recipient"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <input
                    value={rec.smsPhone}
                    onChange={(e) =>
                      updateRecipient(idx, { smsPhone: e.target.value })
                    }
                    placeholder="SMS Phone (+1...)"
                    className="rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 font-mono text-xs text-white"
                  />
                  <input
                    value={rec.whatsappPhone}
                    onChange={(e) =>
                      updateRecipient(idx, { whatsappPhone: e.target.value })
                    }
                    placeholder="WhatsApp Phone (+1...)"
                    className="rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 font-mono text-xs text-white"
                  />
                  <input
                    type="email"
                    value={rec.email}
                    onChange={(e) =>
                      updateRecipient(idx, { email: e.target.value })
                    }
                    placeholder="Email address"
                    className="rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 font-mono text-xs text-white"
                  />
                </div>
              </div>
            ))}
          </div>
        </section>

        {savedBanner && (
          <div className="rounded-xl border border-emerald-500/40 bg-emerald-500/10 px-4 py-3 text-xs font-semibold text-emerald-300">
            {savedBanner}
          </div>
        )}

        <button
          type="submit"
          disabled={saving}
          className="inline-flex items-center gap-2 rounded-2xl bg-cyan-500 px-6 py-3.5 text-sm font-bold text-slate-950 hover:bg-cyan-400 transition-colors disabled:opacity-60"
        >
          {saving ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : (
            <Save className="h-4 w-4" />
          )}
          Save Alert Configuration
        </button>
      </form>
    </div>
  );
}
