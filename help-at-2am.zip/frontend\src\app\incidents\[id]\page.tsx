'use client';

import React, { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import Link from 'next/link';
import {
  Radio,
  MapPin,
  Clock,
  Send,
  BellRing,
  ArrowLeft,
  ShieldCheck,
  Loader2,
} from 'lucide-react';
import { API_BASE_URL, apiRequest } from '@/lib/api';
import { IncidentRecord, NotificationLogItem } from '@/lib/types';
import { SEVERITY_STYLES, STATUS_STYLES } from '@/lib/constants';
import { TimelineView } from '@/components/emergency/TimelineView';
import { GuidancePanel } from '@/components/emergency/GuidancePanel';

export default function IncidentDetailPage() {
  const params = useParams<{ id: string }>();
  const id = params?.id;

  const [incident, setIncident] = useState<IncidentRecord | null>(null);
  const [notifications, setNotifications] = useState<NotificationLogItem[]>([]);
  const [note, setNote] = useState('');
  const [sendingNote, setSendingNote] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!id) return;
    apiRequest<{ incident: IncidentRecord; notifications: NotificationLogItem[] }>(
      `/incidents/${id}`
    )
      .then((res) => {
        setIncident(res.incident);
        setNotifications(res.notifications);
      })
      .catch((err) => {
        setError(err instanceof Error ? err.message : 'Unable to load incident');
      })
      .finally(() => setLoading(false));

    // Live SSE stream for real-time timeline updates
    const es = new EventSource(`${API_BASE_URL}/incidents/${id}/stream`);
    const handleUpdate = (ev: MessageEvent) => {
      try {
        const parsed = JSON.parse(ev.data);
        if (parsed.incident) {
          setIncident(parsed.incident);
        }
      } catch {
        // Ignore parse errors
      }
    };
    es.addEventListener('incident:updated', handleUpdate);
    es.addEventListener('incident:escalated', handleUpdate);
    es.addEventListener('incident:resolved', handleUpdate);

    return () => {
      es.close();
    };
  }, [id]);

  const handleAddNote = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!note.trim() || !incident) return;
    setSendingNote(true);
    try {
      const res = await apiRequest<{ incident: IncidentRecord }>(
        `/incidents/${incident._id}/note`,
        {
          method: 'POST',
          body: JSON.stringify({ note }),
        }
      );
      setIncident(res.incident);
      setNote('');
    } finally {
      setSendingNote(false);
    }
  };

  if (loading) {
    return (
      <div className="mx-auto max-w-6xl px-4 py-16 flex items-center justify-center gap-3 text-slate-400">
        <Loader2 className="h-5 w-5 animate-spin text-cyan-400" />
        Loading live incident command timeline...
      </div>
    );
  }

  if (error || !incident) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-16 text-center space-y-4">
        <p className="text-rose-400 font-semibold">{error || 'Incident not found'}</p>
        <Link
          href="/emergency"
          className="inline-flex items-center gap-2 rounded-xl bg-slate-800 px-4 py-2 text-xs font-bold text-white"
        >
          <ArrowLeft className="h-4 w-4" />
          Return to Emergency Hub
        </Link>
      </div>
    );
  }

  const effectiveSeverity = incident.aiAdjustedSeverity || incident.severity;

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <Link
          href="/emergency"
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-400 hover:text-white"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to Emergency Dashboard
        </Link>
        <span className="inline-flex items-center gap-2 rounded-full border border-emerald-500/30 bg-emerald-500/10 px-3 py-1 font-mono text-[11px] text-emerald-300">
          <Radio className="h-3.5 w-3.5 animate-pulse" />
          LIVE TELEMETRY STREAM CONNECTED
        </span>
      </div>

      {/* Incident Header Card */}
      <div className="glass-panel rounded-3xl p-6 space-y-4">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="space-y-1.5">
            <div className="flex flex-wrap items-center gap-2">
              <span className="font-mono text-sm font-black text-cyan-300">
                {incident.incidentCode}
              </span>
              <span
                className={`rounded-full border px-2.5 py-0.5 text-[11px] font-bold uppercase ${
                  STATUS_STYLES[incident.status]
                }`}
              >
                {incident.status}
              </span>
              <span
                className={`rounded-full border px-2.5 py-0.5 text-[11px] font-bold ${
                  SEVERITY_STYLES[effectiveSeverity]
                }`}
              >
                {effectiveSeverity} Priority
              </span>
              {incident.isPanicMode && (
                <span className="rounded-full bg-rose-600 px-2.5 py-0.5 font-mono text-[10px] font-bold uppercase text-white">
                  PANIC BEACON
                </span>
              )}
            </div>
            <h1 className="text-2xl font-bold text-white">
              {incident.emergencyType}
            </h1>
            <p className="text-sm text-slate-300 max-w-3xl">
              {incident.description}
            </p>
          </div>

          <div className="rounded-2xl border border-slate-800 bg-slate-900/80 px-4 py-3 text-right">
            <p className="text-[11px] uppercase tracking-wider text-slate-400">
              Escalation Tier
            </p>
            <p className="font-mono text-lg font-black text-amber-300">
              LEVEL {incident.escalation.currentLevel} / 3
            </p>
            {incident.escalation.assignedResponder && (
              <p className="text-xs text-emerald-300 mt-0.5">
                Unit: {incident.escalation.assignedResponder}
              </p>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-3 border-t border-slate-800/80 text-xs">
          <div className="flex items-center gap-2 text-slate-300">
            <MapPin className="h-4 w-4 text-cyan-400 shrink-0" />
            <span>
              {incident.location.label}
              {incident.location.floorOrRoom
                ? ` (${incident.location.floorOrRoom})`
                : ''}
            </span>
          </div>
          <div className="flex items-center gap-2 text-slate-300">
            <Clock className="h-4 w-4 text-cyan-400 shrink-0" />
            <span>Reported: {new Date(incident.createdAt).toLocaleString()}</span>
          </div>
          <div className="flex items-center gap-2 text-slate-300">
            <ShieldCheck className="h-4 w-4 text-emerald-400 shrink-0" />
            <span>
              Callback: <span className="font-mono">{incident.contactNumber}</span>
            </span>
          </div>
        </div>
      </div>

      {/* Main Split: Timeline + Guidance */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-7 items-start">
        <div className="lg:col-span-7 space-y-6">
          <div className="glass-panel rounded-3xl p-6 space-y-5">
            <h2 className="text-base font-bold text-white">
              Emergency Action Timeline
            </h2>
            <TimelineView events={incident.timeline} />

            {incident.status !== 'resolved' && (
              <form
                onSubmit={handleAddNote}
                className="flex gap-2 pt-3 border-t border-slate-800"
              >
                <input
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder="Send a live update to the responder (e.g., moved to ground lobby)..."
                  className="flex-1 rounded-xl border border-slate-700 bg-slate-950 px-3.5 py-2.5 text-xs text-white placeholder:text-slate-500 focus:border-cyan-400 focus:outline-none"
                />
                <button
                  type="submit"
                  disabled={sendingNote || !note.trim()}
                  className="inline-flex items-center gap-1.5 rounded-xl bg-cyan-500 px-4 py-2.5 text-xs font-bold text-slate-950 hover:bg-cyan-400 disabled:opacity-50"
                >
                  <Send className="h-3.5 w-3.5" />
                  Update
                </button>
              </form>
            )}
          </div>

          {/* Dispatched Notification Audit Receipts */}
          <div className="glass-panel rounded-3xl p-6 space-y-4">
            <h2 className="flex items-center gap-2 text-base font-bold text-white">
              <BellRing className="h-4 w-4 text-amber-400" />
              Administrator Alert Delivery Receipts ({notifications.length})
            </h2>
            <div className="space-y-2.5">
              {notifications.map((n) => (
                <div
                  key={n._id}
                  className="rounded-xl border border-slate-800 bg-slate-900/70 p-3.5 text-xs space-y-1.5"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span className="rounded-md bg-slate-800 px-2 py-0.5 font-mono text-[10px] uppercase text-cyan-300">
                        {n.channel}
                      </span>
                      <span className="font-bold text-white">{n.recipientName}</span>
                    </div>
                    <span className="font-mono text-[10px] uppercase text-emerald-300">
                      {n.status} · TIER {n.escalationLevel}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400">
                    To: <span className="font-mono">{n.recipientAddress}</span> · Provider:{' '}
                    {n.provider}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="lg:col-span-5">
          <GuidancePanel guidance={incident.guidance} triage={incident.aiTriage} />
        </div>
      </div>
    </div>
  );
}
