import { Router, Response } from 'express';
import { z } from 'zod';
import { Incident } from '../models/Incident.js';
import { NotificationLog } from '../models/NotificationLog.js';
import { getOrCreateAdminSettings } from '../models/AdminSettings.js';
import { dispatchIncidentAlerts } from '../services/notificationService.js';
import { getCampusAnalytics } from '../services/readinessService.js';
import { runEscalationSweep } from '../services/escalationWorker.js';
import { broadcastEvent, registerSseClient } from '../services/sseService.js';
import {
  AuthenticatedRequest,
  requireAuth,
  requireRole,
} from '../middleware/auth.js';
import { validateBody } from '../middleware/validate.js';

const router = Router();

router.use(requireAuth, requireRole('admin', 'super_admin', 'responder'));

router.get('/stream', (req: AuthenticatedRequest, res: Response) => {
  const clientId = `admin-${req.user!.userId}-${Date.now()}-${Math.random()}`;
  registerSseClient(clientId, res, 'admin');
});

router.get('/incidents', async (req, res: Response) => {
  const { status, emergencyType, severity, zone, search, limit } = req.query;
  const filter: Record<string, unknown> = {};

  if (status && status !== 'all') {
    filter.status = status;
  }
  if (emergencyType && emergencyType !== 'all') {
    filter.emergencyType = emergencyType;
  }
  if (severity && severity !== 'all') {
    filter.$or = [{ aiAdjustedSeverity: severity }, { severity }];
  }
  if (zone && zone !== 'all') {
    filter['location.zone'] = zone;
  }
  if (search && typeof search === 'string' && search.trim()) {
    const regex = new RegExp(search.trim(), 'i');
    filter.$and = [
      ...(Array.isArray(filter.$and) ? filter.$and : []),
      {
        $or: [
          { incidentCode: regex },
          { description: regex },
          { 'location.label': regex },
          { reporterName: regex },
          { emergencyType: regex },
        ],
      },
    ];
  }

  const maxLimit = Math.min(200, Math.max(10, parseInt(String(limit || '100'), 10)));
  const incidents = await Incident.find(filter)
    .sort({ createdAt: -1 })
    .limit(maxLimit);

  res.json({ incidents });
});

router.patch(
  '/incidents/:id/acknowledge',
  async (req: AuthenticatedRequest, res: Response) => {
    const incident = await Incident.findById(req.params.id);
    if (!incident) {
      res.status(404).json({ error: 'Incident not found' });
      return;
    }

    const now = new Date();
    const ackSeconds = Math.max(
      1,
      Math.round((now.getTime() - incident.createdAt.getTime()) / 1000)
    );

    if (!incident.metrics.acknowledgedAt) {
      incident.metrics.acknowledgedAt = now;
      incident.metrics.ackTimeSeconds = ackSeconds;
    }

    if (incident.status === 'pending' || incident.status === 'escalated') {
      incident.status = 'active';
    }
    incident.escalation.assignedAdminName = req.user!.name;
    incident.escalation.nextEscalationAt = undefined;

    incident.timeline.push({
      eventType: 'ACKNOWLEDGED',
      title: `Acknowledged by ${req.user!.name}`,
      description: `Incident acknowledged in ${ackSeconds}s. Active response coordination initiated.`,
      actorName: req.user!.name,
      actorRole: req.user!.role,
      timestamp: now,
      metadata: { ackTimeSeconds: ackSeconds },
    });

    await incident.save();
    broadcastEvent(
      'incident:updated',
      { incident: incident.toObject() },
      incident._id.toString()
    );
    res.json({ incident });
  }
);

const assignSchema = z.object({
  responderUnit: z.string().min(2).max(120),
  note: z.string().max(500).optional(),
});

router.patch(
  '/incidents/:id/assign',
  validateBody(assignSchema),
  async (req: AuthenticatedRequest, res: Response) => {
    const incident = await Incident.findById(req.params.id);
    if (!incident) {
      res.status(404).json({ error: 'Incident not found' });
      return;
    }

    const now = new Date();
    if (!incident.metrics.acknowledgedAt) {
      incident.metrics.acknowledgedAt = now;
      incident.metrics.ackTimeSeconds = Math.max(
        1,
        Math.round((now.getTime() - incident.createdAt.getTime()) / 1000)
      );
    }
    if (!incident.metrics.dispatchedAt) {
      incident.metrics.dispatchedAt = now;
    }

    incident.status = 'active';
    incident.escalation.assignedResponder = req.body.responderUnit;
    incident.escalation.assignedAdminName = req.user!.name;
    incident.escalation.nextEscalationAt = undefined;

    incident.timeline.push({
      eventType: 'RESPONDER_ASSIGNED',
      title: `Dispatched: ${req.body.responderUnit}`,
      description:
        req.body.note ||
        `${req.body.responderUnit} assigned and en route to ${incident.location.label}.`,
      actorName: req.user!.name,
      actorRole: req.user!.role,
      timestamp: now,
    });

    await incident.save();
    broadcastEvent(
      'incident:updated',
      { incident: incident.toObject() },
      incident._id.toString()
    );
    res.json({ incident });
  }
);

router.patch(
  '/incidents/:id/escalate',
  async (req: AuthenticatedRequest, res: Response) => {
    const incident = await Incident.findById(req.params.id);
    if (!incident) {
      res.status(404).json({ error: 'Incident not found' });
      return;
    }

    const nextLevel = Math.min(3, incident.escalation.currentLevel + 1) as 1 | 2 | 3;
    incident.status = 'escalated';
    incident.escalation.currentLevel = nextLevel;
    incident.escalation.escalatedCount += 1;

    incident.timeline.push({
      eventType: 'MANUAL_ESCALATED',
      title: `Command Escalated to Tier ${nextLevel}`,
      description: `Manually escalated by ${req.user!.name} for urgent executive/command oversight.`,
      actorName: req.user!.name,
      actorRole: req.user!.role,
      timestamp: new Date(),
    });

    await dispatchIncidentAlerts(incident, nextLevel, {
      escalationNote: `MANUAL COMMAND ESCALATION (TIER ${nextLevel})`,
    });

    await incident.save();
    broadcastEvent(
      'incident:escalated',
      { incident: incident.toObject() },
      incident._id.toString()
    );
    res.json({ incident });
  }
);

const resolveSchema = z.object({
  resolutionSummary: z.string().min(3).max(1000).optional(),
});

router.patch(
  '/incidents/:id/resolve',
  validateBody(resolveSchema),
  async (req: AuthenticatedRequest, res: Response) => {
    const incident = await Incident.findById(req.params.id);
    if (!incident) {
      res.status(404).json({ error: 'Incident not found' });
      return;
    }

    const now = new Date();
    if (!incident.metrics.acknowledgedAt) {
      incident.metrics.acknowledgedAt = now;
      incident.metrics.ackTimeSeconds = Math.max(
        1,
        Math.round((now.getTime() - incident.createdAt.getTime()) / 1000)
      );
    }
    incident.metrics.resolvedAt = now;
    incident.metrics.resolveTimeSeconds = Math.max(
      1,
      Math.round((now.getTime() - incident.createdAt.getTime()) / 1000)
    );

    incident.status = 'resolved';
    incident.escalation.nextEscalationAt = undefined;

    incident.timeline.push({
      eventType: 'RESOLVED',
      title: 'Incident Resolved & Closed',
      description:
        req.body.resolutionSummary ||
        `Case resolved by ${req.user!.name}. Student safety confirmed.`,
      actorName: req.user!.name,
      actorRole: req.user!.role,
      timestamp: now,
      metadata: {
        resolveTimeSeconds: incident.metrics.resolveTimeSeconds,
      },
    });

    await incident.save();
    broadcastEvent(
      'incident:resolved',
      { incident: incident.toObject() },
      incident._id.toString()
    );
    res.json({ incident });
  }
);

router.get('/analytics', async (_req, res: Response) => {
  const analytics = await getCampusAnalytics();
  res.json(analytics);
});

router.get('/notifications', async (req, res: Response) => {
  const limit = Math.min(100, parseInt(String(req.query.limit || '50'), 10));
  const logs = await NotificationLog.find({})
    .sort({ createdAt: -1 })
    .limit(limit);
  res.json({ logs });
});

router.get('/settings', async (_req, res: Response) => {
  const settings = await getOrCreateAdminSettings();
  res.json({ settings });
});

const settingsSchema = z.object({
  campusName: z.string().min(2).max(120).optional(),
  channels: z
    .object({
      smsEnabled: z.boolean(),
      whatsappEnabled: z.boolean(),
      emailEnabled: z.boolean(),
    })
    .optional(),
  slaSeconds: z
    .object({
      Critical: z.number().min(15).max(3600),
      High: z.number().min(30).max(3600),
      Medium: z.number().min(60).max(7200),
      Low: z.number().min(60).max(14400),
    })
    .optional(),
  escalationEnabled: z.boolean().optional(),
  readinessConfig: z
    .object({
      patrolUnitsActive: z.number().min(0).max(50),
      medicalStaffOnDuty: z.number().min(0).max(50),
      counselorAvailable: z.boolean(),
    })
    .optional(),
  recipients: z
    .array(
      z.object({
        name: z.string().min(2),
        role: z.string().min(2),
        level: z.union([z.literal(1), z.literal(2), z.literal(3)]),
        smsPhone: z.string().min(5),
        whatsappPhone: z.string().min(5),
        email: z.string().email(),
        categories: z.array(z.string()),
        active: z.boolean(),
      })
    )
    .optional(),
});

router.put(
  '/settings',
  validateBody(settingsSchema),
  async (req: AuthenticatedRequest, res: Response) => {
    const settings = await getOrCreateAdminSettings();
    if (req.body.campusName) settings.campusName = req.body.campusName;
    if (req.body.channels) settings.channels = req.body.channels;
    if (req.body.slaSeconds) settings.slaSeconds = req.body.slaSeconds;
    if (typeof req.body.escalationEnabled === 'boolean') {
      settings.escalationEnabled = req.body.escalationEnabled;
    }
    if (req.body.readinessConfig) settings.readinessConfig = req.body.readinessConfig;
    if (req.body.recipients) settings.recipients = req.body.recipients;
    settings.updatedBy = req.user!.name;

    await settings.save();
    res.json({ settings });
  }
);

router.post('/escalation/sweep', async (_req, res: Response) => {
  const escalatedCount = await runEscalationSweep();
  res.json({ escalatedCount });
});

export default router;
