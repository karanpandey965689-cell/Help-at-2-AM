import { Incident } from '../models/Incident.js';
import { getOrCreateAdminSettings } from '../models/AdminSettings.js';
import { CAMPUS_LOCATIONS } from '../config/campusData.js';

export interface ReadinessMetrics {
  score: number;
  grade: 'Optimal' | 'Guarded' | 'Elevated' | 'Strain';
  factors: {
    responderCoverage: number;
    slaCompliance: number;
    channelHealth: number;
    incidentLoadFactor: number;
  };
  liveSnapshot: {
    pendingCount: number;
    activeCount: number;
    escalatedCount: number;
    resolvedTodayCount: number;
    avgAckSeconds: number;
    avgResolveSeconds: number;
    patrolUnitsActive: number;
    medicalStaffOnDuty: number;
    counselorAvailable: boolean;
  };
}

export async function calculateEmergencyReadiness(): Promise<ReadinessMetrics> {
  const settings = await getOrCreateAdminSettings();
  const [pendingCount, activeCount, escalatedCount, resolvedIncidents] =
    await Promise.all([
      Incident.countDocuments({ status: 'pending' }),
      Incident.countDocuments({ status: 'active' }),
      Incident.countDocuments({ status: 'escalated' }),
      Incident.find({ status: 'resolved' })
        .select('metrics createdAt')
        .sort({ createdAt: -1 })
        .limit(100)
        .lean(),
    ]);

  const startOfDay = new Date();
  startOfDay.setHours(0, 0, 0, 0);
  const resolvedTodayCount = await Incident.countDocuments({
    status: 'resolved',
    'metrics.resolvedAt': { $gte: startOfDay },
  });

  const ackTimes = resolvedIncidents
    .map((i) => i.metrics?.ackTimeSeconds)
    .filter((v): v is number => typeof v === 'number' && v >= 0);

  const resolveTimes = resolvedIncidents
    .map((i) => i.metrics?.resolveTimeSeconds)
    .filter((v): v is number => typeof v === 'number' && v >= 0);

  const avgAckSeconds =
    ackTimes.length > 0
      ? Math.round(ackTimes.reduce((a, b) => a + b, 0) / ackTimes.length)
      : 48;

  const avgResolveSeconds =
    resolveTimes.length > 0
      ? Math.round(resolveTimes.reduce((a, b) => a + b, 0) / resolveTimes.length)
      : 420;

  // Factor 1: Responder Coverage (0-100)
  const patrolScore = Math.min(100, (settings.readinessConfig.patrolUnitsActive / 6) * 100);
  const medScore = Math.min(100, (settings.readinessConfig.medicalStaffOnDuty / 4) * 100);
  const counselorScore = settings.readinessConfig.counselorAvailable ? 100 : 60;
  const responderCoverage = Math.round((patrolScore * 0.45 + medScore * 0.35 + counselorScore * 0.2));

  // Factor 2: SLA Compliance (0-100)
  const slaCompliance = Math.max(
    45,
    Math.min(100, Math.round(100 - Math.max(0, avgAckSeconds - 45) * 0.35 - escalatedCount * 6))
  );

  // Factor 3: Channel Health (0-100)
  const activeChannels = [
    settings.channels.smsEnabled,
    settings.channels.whatsappEnabled,
    settings.channels.emailEnabled,
  ].filter(Boolean).length;
  const channelHealth = Math.round((activeChannels / 3) * 100);

  // Factor 4: Incident Load Factor (100 = low strain, drops under high open queue)
  const openLoad = pendingCount * 7 + escalatedCount * 10 + activeCount * 3;
  const incidentLoadFactor = Math.max(30, Math.min(100, 100 - openLoad));

  const score = Math.round(
    responderCoverage * 0.3 +
      slaCompliance * 0.3 +
      channelHealth * 0.2 +
      incidentLoadFactor * 0.2
  );

  let grade: ReadinessMetrics['grade'] = 'Optimal';
  if (score < 60) grade = 'Strain';
  else if (score < 75) grade = 'Elevated';
  else if (score < 88) grade = 'Guarded';

  return {
    score,
    grade,
    factors: {
      responderCoverage,
      slaCompliance,
      channelHealth,
      incidentLoadFactor,
    },
    liveSnapshot: {
      pendingCount,
      activeCount,
      escalatedCount,
      resolvedTodayCount,
      avgAckSeconds,
      avgResolveSeconds,
      patrolUnitsActive: settings.readinessConfig.patrolUnitsActive,
      medicalStaffOnDuty: settings.readinessConfig.medicalStaffOnDuty,
      counselorAvailable: settings.readinessConfig.counselorAvailable,
    },
  };
}

export async function getCampusAnalytics() {
  const allIncidents = await Incident.find({})
    .select('emergencyType severity aiAdjustedSeverity status location metrics escalation createdAt isPanicMode')
    .sort({ createdAt: -1 })
    .limit(500)
    .lean();

  const byCategory: Record<string, number> = {};
  const bySeverity: Record<string, number> = { Low: 0, Medium: 0, High: 0, Critical: 0 };
  const byStatus: Record<string, number> = { pending: 0, active: 0, escalated: 0, resolved: 0 };
  const byHour: Record<number, number> = {};
  for (let h = 0; h < 24; h++) byHour[h] = 0;

  const zoneCounts: Record<string, { count: number; criticalCount: number; lat: number; lng: number }> = {};

  let panicCount = 0;
  let autoEscalatedCount = 0;

  for (const inc of allIncidents) {
    byCategory[inc.emergencyType] = (byCategory[inc.emergencyType] || 0) + 1;
    const sev = inc.aiAdjustedSeverity || inc.severity;
    bySeverity[sev] = (bySeverity[sev] || 0) + 1;
    byStatus[inc.status] = (byStatus[inc.status] || 0) + 1;
    const hour = new Date(inc.createdAt).getHours();
    byHour[hour] = (byHour[hour] || 0) + 1;

    if (inc.isPanicMode) panicCount++;
    if (inc.escalation?.autoEscalated) autoEscalatedCount++;

    const z = inc.location?.zone || 'Campus Core';
    if (!zoneCounts[z]) {
      zoneCounts[z] = {
        count: 0,
        criticalCount: 0,
        lat: inc.location?.coordinates?.lat ?? 37.4275,
        lng: inc.location?.coordinates?.lng ?? -122.1697,
      };
    }
    zoneCounts[z].count += 1;
    if (sev === 'Critical' || sev === 'High') {
      zoneCounts[z].criticalCount += 1;
    }
  }

  const heatmapPoints = allIncidents.map((inc) => {
    const sev = inc.aiAdjustedSeverity || inc.severity;
    const weight =
      sev === 'Critical' ? 1.0 : sev === 'High' ? 0.8 : sev === 'Medium' ? 0.55 : 0.35;
    return {
      lat: inc.location.coordinates.lat,
      lng: inc.location.coordinates.lng,
      weight,
      zone: inc.location.zone,
      category: inc.emergencyType,
      status: inc.status,
    };
  });

  const hourlyTrend = Object.entries(byHour).map(([hour, count]) => ({
    hour: `${hour.padStart(2, '0')}:00`,
    count,
  }));

  const zoneBreakdown = Object.entries(zoneCounts)
    .map(([zone, info]) => ({
      zone,
      ...info,
    }))
    .sort((a, b) => b.count - a.count);

  const readiness = await calculateEmergencyReadiness();

  return {
    totalIncidents: allIncidents.length,
    panicCount,
    autoEscalatedCount,
    escalationRate:
      allIncidents.length > 0
        ? Math.round((autoEscalatedCount / allIncidents.length) * 100)
        : 0,
    byCategory,
    bySeverity,
    byStatus,
    hourlyTrend,
    zoneBreakdown,
    heatmapPoints,
    campusSafeZonesCount: CAMPUS_LOCATIONS.length,
    readiness,
  };
}
