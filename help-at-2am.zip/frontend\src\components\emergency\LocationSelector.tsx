'use client';

import React, { useState } from 'react';
import { MapPin, Building, Home, Crosshair, Loader2, CheckCircle2 } from 'lucide-react';
import {
  CampusLocationNode,
  LocationMethod,
  SafeWalkCorridor,
} from '@/lib/types';
import { CampusMap } from '@/components/map/CampusMap';
import { apiRequest } from '@/lib/api';

export interface SelectedLocationValue {
  method: LocationMethod;
  label: string;
  zone: string;
  nodeId?: string;
  floorOrRoom?: string;
  coordinates: { lat: number; lng: number };
  gpsAccuracyMeters?: number;
}

export function LocationSelector({
  locations,
  safeCorridors,
  value,
  onChange,
}: {
  locations: CampusLocationNode[];
  safeCorridors: SafeWalkCorridor[];
  value: SelectedLocationValue;
  onChange: (val: SelectedLocationValue) => void;
}) {
  const [tab, setTab] = useState<LocationMethod>(value.method || 'hostel');
  const [gpsLoading, setGpsLoading] = useState(false);
  const [gpsError, setGpsError] = useState('');

  const hostels = locations.filter((l) => l.type === 'hostel');
  const buildings = locations.filter(
    (l) => l.type === 'building' || l.type === 'medical' || l.type === 'security' || l.type === 'safe_zone'
  );

  const selectedNode = locations.find((l) => l.id === value.nodeId);

  const selectNode = (node: CampusLocationNode, method: LocationMethod) => {
    onChange({
      method,
      label: node.name,
      zone: node.zone,
      nodeId: node.id,
      floorOrRoom: '',
      coordinates: node.coordinates,
    });
  };

  const handleMapClick = async (coords: { lat: number; lng: number }) => {
    try {
      const res = await apiRequest<{ nearest: CampusLocationNode }>(
        `/campus/nearest?lat=${coords.lat}&lng=${coords.lng}`
      );
      onChange({
        method: 'map',
        label: `Map Pin near ${res.nearest.name}`,
        zone: res.nearest.zone,
        nodeId: res.nearest.id,
        floorOrRoom: value.floorOrRoom,
        coordinates: coords,
      });
    } catch {
      onChange({
        method: 'map',
        label: `Custom Map Pin (${coords.lat.toFixed(4)}, ${coords.lng.toFixed(4)})`,
        zone: 'Campus Perimeter',
        coordinates: coords,
      });
    }
  };

  const handleLocateGps = () => {
    setGpsError('');
    if (typeof navigator === 'undefined' || !navigator.geolocation) {
      setGpsError('Browser GPS is unavailable; using campus fallback pin.');
      return;
    }
    setGpsLoading(true);
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const lat = pos.coords.latitude;
        const lng = pos.coords.longitude;
        const accuracy = Math.round(pos.coords.accuracy);
        try {
          const res = await apiRequest<{ nearest: CampusLocationNode }>(
            `/campus/nearest?lat=${lat}&lng=${lng}`
          );
          onChange({
            method: 'gps',
            label: `Live GPS (Nearest: ${res.nearest.name})`,
            zone: res.nearest.zone,
            nodeId: res.nearest.id,
            coordinates: { lat, lng },
            gpsAccuracyMeters: accuracy,
          });
        } catch {
          onChange({
            method: 'gps',
            label: `Live GPS (${lat.toFixed(5)}, ${lng.toFixed(5)})`,
            zone: 'Live GPS Coordinates',
            coordinates: { lat, lng },
            gpsAccuracyMeters: accuracy,
          });
        } finally {
          setGpsLoading(false);
        }
      },
      () => {
        setGpsLoading(false);
        setGpsError(
          'Location permission denied or unavailable. Snap to nearest campus zone or drop a pin on the map.'
        );
      },
      { enableHighAccuracy: true, timeout: 8000 }
    );
  };

  const tabs: Array<{
    id: LocationMethod;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
  }> = [
    { id: 'hostel', label: 'Hostel Selector', icon: Home },
    { id: 'building', label: 'Building Selector', icon: Building },
    { id: 'map', label: 'Interactive Map', icon: MapPin },
    { id: 'gps', label: 'Current GPS', icon: Crosshair },
  ];

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
        {tabs.map((t) => {
          const Icon = t.icon;
          const active = tab === t.id;
          return (
            <button
              key={t.id}
              type="button"
              onClick={() => setTab(t.id)}
              className={`flex items-center justify-center gap-2 rounded-xl border px-3 py-2.5 text-xs font-semibold transition-all ${
                active
                  ? 'border-cyan-400 bg-cyan-500/15 text-cyan-200'
                  : 'border-slate-800 bg-slate-900/70 text-slate-400 hover:text-white'
              }`}
            >
              <Icon className="h-4 w-4" />
              {t.label}
            </button>
          );
        })}
      </div>

      {tab === 'hostel' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          {hostels.map((h) => {
            const active = value.nodeId === h.id && value.method === 'hostel';
            return (
              <button
                key={h.id}
                type="button"
                onClick={() => selectNode(h, 'hostel')}
                className={`text-left rounded-xl border p-3.5 transition-all ${
                  active
                    ? 'border-cyan-400 bg-cyan-500/10'
                    : 'border-slate-800 bg-slate-900/60 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-mono text-[11px] text-cyan-400">{h.code}</span>
                  <span className="text-[11px] text-slate-400">{h.zone}</span>
                </div>
                <p className="mt-1 text-sm font-semibold text-white">{h.name}</p>
                <p className="mt-1 text-[11px] text-slate-400">
                  Safe Point: {h.nearestSafePoint}
                </p>
              </button>
            );
          })}
        </div>
      )}

      {tab === 'building' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          {buildings.map((b) => {
            const active = value.nodeId === b.id && value.method === 'building';
            return (
              <button
                key={b.id}
                type="button"
                onClick={() => selectNode(b, 'building')}
                className={`text-left rounded-xl border p-3.5 transition-all ${
                  active
                    ? 'border-cyan-400 bg-cyan-500/10'
                    : 'border-slate-800 bg-slate-900/60 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-mono text-[11px] text-cyan-400">{b.code}</span>
                  <span
                    className={`rounded-full px-2 py-0.5 text-[10px] font-medium ${
                      b.open24x7
                        ? 'bg-emerald-500/15 text-emerald-300'
                        : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {b.open24x7 ? '24/7 Open' : 'Night Restricted'}
                  </span>
                </div>
                <p className="mt-1 text-sm font-semibold text-white">{b.name}</p>
                <p className="mt-1 text-[11px] text-slate-400">{b.zone}</p>
              </button>
            );
          })}
        </div>
      )}

      {tab === 'map' && (
        <CampusMap
          locations={locations}
          safeCorridors={safeCorridors}
          interactiveSelect
          selectedCoordinates={value.coordinates}
          onSelectPoint={handleMapClick}
          onSelectNode={(node) => selectNode(node, 'map')}
          heightClass="h-[340px]"
        />
      )}

      {tab === 'gps' && (
        <div className="rounded-2xl border border-slate-800 bg-slate-900/70 p-5 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h4 className="text-sm font-bold text-white">
                High-Accuracy GPS Coordinate Lock
              </h4>
              <p className="text-xs text-slate-400 mt-1">
                Captures device latitude/longitude and automatically snaps to the closest campus patrol landmark.
              </p>
            </div>
            <button
              type="button"
              onClick={handleLocateGps}
              disabled={gpsLoading}
              className="inline-flex items-center justify-center gap-2 rounded-xl bg-cyan-600 px-4 py-2.5 text-xs font-bold text-white hover:bg-cyan-500 transition-colors disabled:opacity-60"
            >
              {gpsLoading ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Crosshair className="h-4 w-4" />
              )}
              {gpsLoading ? 'Acquiring GPS...' : 'Capture Live GPS'}
            </button>
          </div>
          {gpsError && (
            <p className="rounded-lg border border-amber-500/30 bg-amber-500/10 px-3 py-2 text-xs text-amber-300">
              {gpsError}
            </p>
          )}
        </div>
      )}

      {/* Floor / Room & Selected Summary */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 rounded-xl border border-slate-800 bg-slate-900/50 p-3.5">
        <div>
          <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-400">
            Selected Location
          </label>
          <div className="mt-1 flex items-start gap-2">
            <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <p className="text-xs font-bold text-white">{value.label}</p>
              <p className="font-mono text-[11px] text-slate-400">
                {value.zone} · ({value.coordinates.lat.toFixed(4)}, {value.coordinates.lng.toFixed(4)})
              </p>
            </div>
          </div>
        </div>

        <div>
          <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-400">
            Floor / Room / Landmark Detail
          </label>
          {selectedNode?.floors && selectedNode.floors.length > 0 ? (
            <div className="mt-1 flex gap-2">
              <select
                value={value.floorOrRoom || ''}
                onChange={(e) =>
                  onChange({ ...value, floorOrRoom: e.target.value })
                }
                className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-1.5 text-xs text-white focus:border-cyan-400 focus:outline-none"
              >
                <option value="">Select floor/wing...</option>
                {selectedNode.floors.map((f) => (
                  <option key={f} value={f}>
                    {f}
                  </option>
                ))}
              </select>
            </div>
          ) : (
            <input
              type="text"
              value={value.floorOrRoom || ''}
              onChange={(e) =>
                onChange({ ...value, floorOrRoom: e.target.value })
              }
              placeholder="e.g., Room 304, East Stairwell, Near Lamp #12"
              className="mt-1 w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-1.5 text-xs text-white placeholder:text-slate-500 focus:border-cyan-400 focus:outline-none"
            />
          )}
        </div>
      </div>
    </div>
  );
}
