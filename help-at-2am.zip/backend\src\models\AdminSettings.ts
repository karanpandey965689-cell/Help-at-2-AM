import mongoose, { Document, Schema } from 'mongoose';

export interface IAdminContactRecipient {
  name: string;
  role: string;
  level: 1 | 2 | 3;
  smsPhone: string;
  whatsappPhone: string;
  email: string;
  categories: string[];
  active: boolean;
}

export interface IAdminSettings extends Document {
  key: string;
  campusName: string;
  channels: {
    smsEnabled: boolean;
    whatsappEnabled: boolean;
    emailEnabled: boolean;
  };
  slaSeconds: {
    Critical: number;
    High: number;
    Medium: number;
    Low: number;
  };
  escalationEnabled: boolean;
  recipients: IAdminContactRecipient[];
  readinessConfig: {
    patrolUnitsActive: number;
    medicalStaffOnDuty: number;
    counselorAvailable: boolean;
  };
  updatedBy?: string;
  updatedAt: Date;
}

const RecipientSchema = new Schema<IAdminContactRecipient>(
  {
    name: { type: String, required: true },
    role: { type: String, required: true },
    level: { type: Number, enum: [1, 2, 3], required: true },
    smsPhone: { type: String, required: true },
    whatsappPhone: { type: String, required: true },
    email: { type: String, required: true },
    categories: [{ type: String }],
    active: { type: Boolean, default: true },
  },
  { _id: true }
);

const AdminSettingsSchema = new Schema<IAdminSettings>(
  {
    key: { type: String, unique: true, default: 'default' },
    campusName: { type: String, default: 'Northridge University Campus' },
    channels: {
      smsEnabled: { type: Boolean, default: true },
      whatsappEnabled: { type: Boolean, default: true },
      emailEnabled: { type: Boolean, default: true },
    },
    slaSeconds: {
      Critical: { type: Number, default: 60 },
      High: { type: Number, default: 120 },
      Medium: { type: Number, default: 240 },
      Low: { type: Number, default: 420 },
    },
    escalationEnabled: { type: Boolean, default: true },
    recipients: [RecipientSchema],
    readinessConfig: {
      patrolUnitsActive: { type: Number, default: 6 },
      medicalStaffOnDuty: { type: Number, default: 4 },
      counselorAvailable: { type: Boolean, default: true },
    },
    updatedBy: { type: String },
  },
  { timestamps: true }
);

export const AdminSettings = mongoose.model<IAdminSettings>(
  'AdminSettings',
  AdminSettingsSchema
);

export async function getOrCreateAdminSettings(): Promise<IAdminSettings> {
  let settings = await AdminSettings.findOne({ key: 'default' });
  if (!settings) {
    settings = await AdminSettings.create({
      key: 'default',
      campusName: 'Northridge University Campus',
      channels: {
        smsEnabled: true,
        whatsappEnabled: true,
        emailEnabled: true,
      },
      slaSeconds: {
        Critical: 60,
        High: 120,
        Medium: 240,
        Low: 420,
      },
      escalationEnabled: true,
      readinessConfig: {
        patrolUnitsActive: 6,
        medicalStaffOnDuty: 4,
        counselorAvailable: true,
      },
      recipients: [
        {
          name: 'Night Patrol Desk (L1)',
          role: 'Campus Security Shift Supervisor',
          level: 1,
          smsPhone: '+15550199001',
          whatsappPhone: '+15550199001',
          email: 'night-patrol@campus-safety.edu',
          categories: [
            'Security Emergency',
            'Personal Safety',
            'Lost on Campus',
            'Hostel Problems',
            'Other Emergency',
          ],
          active: true,
        },
        {
          name: '24/7 Campus Medical Officer (L1)',
          role: 'Emergency Triage Nurse & Paramedic Lead',
          level: 1,
          smsPhone: '+15550199002',
          whatsappPhone: '+15550199002',
          email: 'medical-triage@campus-safety.edu',
          categories: ['Medical Emergency', 'Mental Health'],
          active: true,
        },
        {
          name: 'Chief Security Commander (L2)',
          role: 'Director of Campus Safety Operations',
          level: 2,
          smsPhone: '+15550199003',
          whatsappPhone: '+15550199003',
          email: 'security-chief@campus-safety.edu',
          categories: [
            'Medical Emergency',
            'Security Emergency',
            'Personal Safety',
            'Mental Health',
            'Hostel Problems',
            'Lost on Campus',
            'Other Emergency',
          ],
          active: true,
        },
        {
          name: 'Dean On-Call & Crisis Director (L3)',
          role: 'Executive University Crisis Escalation Lead',
          level: 3,
          smsPhone: '+15550199004',
          whatsappPhone: '+15550199004',
          email: 'dean-crisis@campus-safety.edu',
          categories: [
            'Medical Emergency',
            'Security Emergency',
            'Personal Safety',
            'Mental Health',
            'Hostel Problems',
            'Lost on Campus',
            'Other Emergency',
          ],
          active: true,
        },
      ],
    });
  }
  return settings;
}
