'use client';

import React, { useCallback, useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import {
  Radio,
  Search,
  Download,
  Flame,
  BellRing,
  Settings,
  Lock,
  RefreshCw,
  CheckCircle2,
  AlertOctagon,
  Clock,
  ShieldCheck,
} from 'lucide-react';
import { API_BASE_URL, apiRequest, getStoredToken } from '@/lib/api';
import { useAuth } from '@/lib/authContext';
import {
  CampusLocationNode,
  IncidentRecord,
  NotificationLogItem,
  SafeWalkCorridor,
} from '@/lib/types';
import {
  EMERGENCY_CATEGORIES,
  SEVERITY_STYLES,
  STATUS_STYLES,
} from '@/lib/constants';
import { CampusMap } from '@/components/map/CampusMap';
import { ReadinessGauge } from '@/components/emergency/ReadinessGauge';
import {
  AnalyticsCharts,
  AnalyticsPayload,
} from '@/components/admin/AnalyticsCharts';
import { IncidentDetailModal } from '@/components/admin/IncidentDetailModal';

export default function AdminDashboardPage() {
  const { user, loading: authLoading, login } = useAuth();
  const isAuthorized =
    user?.role === 'admin' ||
    user?.role === 'super_admin' ||
    user?.role === 'responder';

  const [incidents, setIncidents] = useState<IncidentRecord[]>([]);
  const [analytics, setAnalytics] = useState<AnalyticsPayload | null>(null);
  const [notifications, setNotifications] = useState<NotificationLogItem[]>([]);
  const [locations, setLocations] = useState<CampusLocationNode[]>([]);
  const [corridors, setCorridors] = useState<SafeWalkCorridor[]>([]);

  const [activeTab, setActiveTab] = useState<
    'feed' | 'map' | 'analytics' | 'history' | 'notifications'
  >('feed');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [severityFilter, setSeverityFilter] = useState<string>('all');
  const [search, setSearch] = useState('');
  const [showHeatmap, setShowHeatmap] = useState(true);
  const [selectedIncident, setSelectedIncident] = useState<IncidentRecord | null>(
    null
  );
  const [sseConnected, setSseConnected] = useState(false);

  // Quick admin sign-in state when not signed in
  const [quickEmail, setQuickEmail] = useState('admin@campus.edu');
  const [quickPass, setQuickPass] = useState('Command@2AM');
  const [loginError, setLoginError] = useState('');

  const loadAllData = useCallback(async () => {
    if (!isAuthorized) return;
    const params = new URLSearchParams();
    if (statusFilter !== 'all') params.set('status', statusFilter);
    if (categoryFilter !== 'all') params.set('emergencyType', categoryFilter);
    if (severityFilter !== 'all') params.set('severity', severityFilter);
    if (search.trim()) params.set('search', search.trim());

    const [incRes, anaRes, notifRes, campRes] = await Promise.all([
      apiRequest<{ incidents: IncidentRecord[] }>(
        `/admin/incidents?${params.toString()}`
      ),
      apiRequest<AnalyticsPayload>('/admin/analytics'),
      apiRequest<{ logs: NotificationLogItem[] }>('/admin/notifications?limit=40'),
      apiRequest<{
        locations: CampusLocationNode[];
        safeWalkCorridors: SafeWalkCorridor[];
      }>('/campus/locations'),
    ]);

    setIncidents(incRes.incidents);
    setAnalytics(anaRes);
    setNotifications(notifRes.logs);
    setLocations(campRes.locations);
    setCorridors(campRes.safeWalkCorridors);
  }, [isAuthorized, statusFilter, categoryFilter, severityFilter, search]);

  useEffect(() => {
    loadAllData().catch(() => {});
  }, [loadAllData]);

  // Live SSE stream for real-time operations feed
  useEffect(() => {
    if (!isAuthorized) return;
    const token = getStoredToken();
    if (!token) return;

    const es = new EventSource(
      `${API_BASE_URL}/admin/stream?token=${encodeURIComponent(token)}`
    );

    es.addEventListener('connected', () => setSseConnected(true));

    const refreshOnEvent = () => {
      loadAllData().catch(() => {});
    };

    es.addEventListener('incident:created', refreshOnEvent);
    es.addEventListener('incident:updated', refreshOnEvent);
    es.addEventListener('incident:escalated', refreshOnEvent);
    es.addEventListener('incident:resolved', refreshOnEvent);
    es.onerror = () => setSseConnected(false);

    return () => {
      es.close();
      setSseConnected(false);
    };
  }, [isAuthorized, loadAllData]);

  const counts = useMemo(() => {
    return {
      pending: incidents.filter((i) => i.status === 'pending').length,
      active: incidents.filter((i) => i.status === 'active').length,
      escalated: incidents.filter((i) => i.status === 'escalated').length,
      resolved: incidents.filter((i) => i.status === 'resolved').length,
    };
  }, [incidents]);

  const handleAcknowledge = async (id: string) => {
    const res = await apiRequest<{ incident: IncidentRecord }>(
      `/admin/incidents/${id}/acknowledge`,
      { method: 'PATCH' }
    );
    setSelectedIncident(res.incident);
    await loadAllData();
  };

  const handleAssign = async (id: string, responderUnit: string) => {
    const res = await apiRequest<{ incident: IncidentRecord }>(
      `/admin/incidents/${id}/assign`,
      {
        method: 'PATCH',
        body: JSON.stringify({ responderUnit }),
      }
    );
    setSelectedIncident(res.incident);
    await loadAllData();
  };

  const handleEscalate = async (id: string) => {
    const res = await apiRequest<{ incident: IncidentRecord }>(
      `/admin/incidents/${id}/escalate`,
      { method: 'PATCH' }
    );
    setSelectedIncident(res.incident);
    await loadAllData();
  };

  const handleResolve = async (id: string, resolutionSummary: string) => {
    const res = await apiRequest<{ incident: IncidentRecord }>(
      `/admin/incidents/${id}/resolve`,
      {
        method: 'PATCH',
        body: JSON.stringify({ resolutionSummary }),
      }
    );
    setSelectedIncident(res.incident);
    await loadAllData();
  };

  const handleTriggerSweep = async () => {
    await apiRequest('/admin/escalation/sweep', { method: 'POST' });
    await loadAllData();
  };

  const exportCsv = () => {
    const header = [
      'Code',
      'Category',
      'Severity',
      'Status',
      'Location',
      'Zone',
      'RiskScore',
      'Tier',
      'CreatedAt',
    ];
    const rows = incidents.map((i) => [
      i.incidentCode,
      i.emergencyType,
      i.aiAdjustedSeverity || i.severity,
      i.status,
      `"${i.location.label.replace(/"/g, '""')}"`,
      i.location.zone,
      i.aiTriage.riskScore,
      i.escalation.currentLevel,
      i.createdAt,
    ]);
    const csv = [header.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `help-at-2am-incidents-${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (authLoading) {
    return (
      <div className="mx-auto max-w-7xl px-6 py-16 text-sm text-slate-400">
        Verifying command credentials...
      </div>
    );
  }

  if (!isAuthorized) {
    return (
      <div className="mx-auto max-w-md px-4 py-14">
        <div className="glass-panel rounded-3xl p-7 space-y-5">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-2xl border border-amber-500/40 bg-amber-500/15 text-amber-300">
              <Lock className="h-5 w-5" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-white">
                Admin Operations Access Required
              </h1>
              <p className="text-xs text-slate-400">
                Sign in with Commander / Admin JWT credentials
              </p>
            </div>
          </div>

          <form
            onSubmit={async (e) => {
              e.preventDefault();
              setLoginError('');
              try {
                await login(quickEmail, quickPass);
              } catch (err) {
                setLoginError(err instanceof Error ? err.message : 'Login failed');
              }
            }}
            className="space-y-3.5"
          >
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Admin Email
              </label>
              <input
                value={quickEmail}
                onChange={(e) => setQuickEmail(e.target.value)}
                className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3.5 py-2.5 text-sm text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Password
              </label>
              <input
                type="password"
                value={quickPass}
                onChange={(e) => setQuickPass(e.target.value)}
                className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3.5 py-2.5 text-sm text-white"
              />
            </div>
            {loginError && (
              <p className="text-xs text-rose-400">{loginError}</p>
            )}
            <button
              type="submit"
              className="w-full rounded-xl bg-amber-500 py-3 text-sm font-bold text-slate-950 hover:bg-amber-400 transition-colors"
            >
              Authenticate &amp; Open Operations Console
            </button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-7 sm:px-6 space-y-6">
      {/* Command Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <span
              className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 font-mono text-[10px] font-bold ${
                sseConnected
                  ? 'border-emerald-500/40 bg-emerald-500/10 text-emerald-300'
                  : 'border-amber-500/40 bg-amber-500/10 text-amber-300'
              }`}
            >
              <Radio className="h-3 w-3 animate-pulse" />
              {sseConnected ? 'SSE LIVE STREAM ACTIVE' : 'POLLING SYNC'}
            </span>
            <span className="font-mono text-xs text-slate-400">
              Commander: {user?.name}
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white mt-1">
            Emergency Operations Command Center
          </h1>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={handleTriggerSweep}
            className="inline-flex items-center gap-1.5 rounded-xl border border-amber-500/40 bg-amber-500/10 px-3.5 py-2 text-xs font-bold text-amber-200 hover:bg-amber-500/20"
          >
            <Clock className="h-3.5 w-3.5" />
            Run SLA Escalation Check
          </button>

          <button
            onClick={() => loadAllData()}
            className="inline-flex items-center gap-1.5 rounded-xl border border-slate-700 bg-slate-900 px-3.5 py-2 text-xs font-semibold text-slate-200 hover:bg-slate-800"
          >
            <RefreshCw className="h-3.5 w-3.5" />
            Sync
          </button>

          <Link
            href="/admin/settings"
            className="inline-flex items-center gap-1.5 rounded-xl bg-slate-800 border border-slate-700 px-3.5 py-2 text-xs font-bold text-white hover:bg-slate-700"
          >
            <Settings className="h-3.5 w-3.5 text-cyan-400" />
            Alert &amp; Escalation Config
          </Link>
        </div>
      </div>

      {/* Top KPIs + Readiness */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        <div className="lg:col-span-7 grid grid-cols-2 sm:grid-cols-4 gap-3">
          <button
            onClick={() => setStatusFilter('pending')}
            className="glass-panel rounded-2xl p-4 text-left hover:border-amber-400/50 transition-colors"
          >
            <p className="text-xs text-slate-400">Pending Cases</p>
            <p className="mt-1 font-mono text-3xl font-black text-amber-300">
              {counts.pending}
            </p>
            <p className="text-[10px] text-amber-400/80 mt-1">Awaiting Ack</p>
          </button>

          <button
            onClick={() => setStatusFilter('active')}
            className="glass-panel rounded-2xl p-4 text-left hover:border-cyan-400/50 transition-colors"
          >
            <p className="text-xs text-slate-400">Active Cases</p>
            <p className="mt-1 font-mono text-3xl font-black text-cyan-300">
              {counts.active}
            </p>
            <p className="text-[10px] text-cyan-400/80 mt-1">Units Dispatched</p>
          </button>

          <button
            onClick={() => setStatusFilter('escalated')}
            className="glass-panel rounded-2xl p-4 text-left hover:border-rose-400/50 transition-colors"
          >
            <p className="text-xs text-slate-400">Escalated</p>
            <p className="mt-1 font-mono text-3xl font-black text-rose-400">
              {counts.escalated}
            </p>
            <p className="text-[10px] text-rose-400/80 mt-1">Tier 2 / Tier 3</p>
          </button>

          <button
            onClick={() => setStatusFilter('resolved')}
            className="glass-panel rounded-2xl p-4 text-left hover:border-emerald-400/50 transition-colors"
          >
            <p className="text-xs text-slate-400">Resolved</p>
            <p className="mt-1 font-mono text-3xl font-black text-emerald-400">
              {counts.resolved}
            </p>
            <p className="text-[10px] text-emerald-400/80 mt-1">Closed Safely</p>
          </button>
        </div>

        <div className="lg:col-span-5">
          <ReadinessGauge readiness={analytics?.readiness || null} compact />
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-3">
        <div className="flex flex-wrap gap-2">
          {(
            [
              { id: 'feed', label: 'Live Incident Feed' },
              { id: 'map', label: 'Campus Map & Heatmap' },
              { id: 'analytics', label: 'Analytics & SLA Metrics' },
              { id: 'history', label: 'Incident History' },
              { id: 'notifications', label: 'SMS / WhatsApp / Email Logs' },
            ] as const
          ).map((t) => (
            <button
              key={t.id}
              onClick={() => setActiveTab(t.id)}
              className={`rounded-xl px-4 py-2 text-xs font-bold transition-colors ${
                activeTab === t.id
                  ? 'bg-cyan-500 text-slate-950'
                  : 'bg-slate-900/70 text-slate-300 hover:bg-slate-800'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        <button
          onClick={exportCsv}
          className="inline-flex items-center gap-1.5 rounded-xl border border-slate-700 bg-slate-900 px-3 py-2 text-xs font-semibold text-slate-200 hover:bg-slate-800"
        >
          <Download className="h-3.5 w-3.5" />
          Export CSV
        </button>
      </div>

      {/* Filters Bar */}
      {(activeTab === 'feed' || activeTab === 'history' || activeTab === 'map') && (
        <div className="glass-panel rounded-2xl p-3.5 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          <div className="relative">
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-500" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search code, location, description..."
              className="w-full rounded-xl border border-slate-700 bg-slate-950 pl-9 pr-3 py-2 text-xs text-white focus:border-cyan-400 focus:outline-none"
            />
          </div>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-xs text-white"
          >
            <option value="all">All Statuses</option>
            <option value="pending">Pending</option>
            <option value="active">Active</option>
            <option value="escalated">Escalated</option>
            <option value="resolved">Resolved</option>
          </select>

          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-xs text-white"
          >
            <option value="all">All Categories</option>
            {EMERGENCY_CATEGORIES.map((c) => (
              <option key={c.id} value={c.id}>
                {c.id}
              </option>
            ))}
          </select>

          <select
            value={severityFilter}
            onChange={(e) => setSeverityFilter(e.target.value)}
            className="rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-xs text-white"
          >
            <option value="all">All Severities</option>
            <option value="Critical">Critical</option>
            <option value="High">High</option>
            <option value="Medium">Medium</option>
            <option value="Low">Low</option>
          </select>
        </div>
      )}

      {/* TAB: LIVE FEED */}
      {activeTab === 'feed' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <div className="lg:col-span-7 space-y-3">
            {incidents.length === 0 ? (
              <div className="glass-panel rounded-2xl p-10 text-center text-sm text-slate-400">
                No incidents match the active filters.
              </div>
            ) : (
              incidents.map((inc) => {
                const sev = inc.aiAdjustedSeverity || inc.severity;
                return (
                  <div
                    key={inc._id}
                    className={`glass-panel rounded-2xl p-4 space-y-3 transition-all hover:border-cyan-500/40 ${
                      inc.isPanicMode && inc.status !== 'resolved'
                        ? 'border-rose-500/50 bg-rose-950/15'
                        : ''
                    }`}
                  >
                    <div className="flex flex-wrap items-start justify-between gap-2">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-mono text-xs font-black text-cyan-300">
                          {inc.incidentCode}
                        </span>
                        <span
                          className={`rounded-full border px-2 py-0.5 text-[10px] font-bold uppercase ${
                            STATUS_STYLES[inc.status]
                          }`}
                        >
                          {inc.status}
                        </span>
                        <span
                          className={`rounded-full border px-2 py-0.5 text-[10px] font-bold ${
                            SEVERITY_STYLES[sev]
                          }`}
                        >
                          {sev}
                        </span>
                        {inc.isPanicMode && (
                          <span className="inline-flex items-center gap-1 rounded-full bg-rose-600 px-2 py-0.5 font-mono text-[10px] font-bold text-white">
                            <AlertOctagon className="h-3 w-3" />
                            PANIC
                          </span>
                        )}
                      </div>
                      <span className="font-mono text-[11px] text-slate-400">
                        Risk {inc.aiTriage.riskScore}/100 · Tier{' '}
                        {inc.escalation.currentLevel}
                      </span>
                    </div>

                    <div>
                      <h3 className="text-sm font-bold text-white">
                        {inc.emergencyType} — {inc.location.label}
                      </h3>
                      <p className="text-xs text-slate-300 mt-1 line-clamp-2">
                        {inc.description}
                      </p>
                    </div>

                    <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-800/70">
                      <span className="font-mono text-[11px] text-slate-400">
                        {new Date(inc.createdAt).toLocaleString()} ·{' '}
                        {inc.escalation.assignedResponder || 'Unassigned'}
                      </span>

                      <div className="flex items-center gap-2">
                        {inc.status === 'pending' && (
                          <button
                            onClick={() => handleAcknowledge(inc._id)}
                            className="inline-flex items-center gap-1 rounded-lg bg-cyan-500 px-3 py-1.5 text-[11px] font-bold text-slate-950 hover:bg-cyan-400"
                          >
                            <CheckCircle2 className="h-3.5 w-3.5" />
                            Ack
                          </button>
                        )}
                        {inc.status !== 'resolved' && (
                          <button
                            onClick={() =>
                              handleResolve(
                                inc._id,
                                'Resolved from live operations feed.'
                              )
                            }
                            className="inline-flex items-center gap-1 rounded-lg border border-emerald-500/40 bg-emerald-500/10 px-3 py-1.5 text-[11px] font-bold text-emerald-300 hover:bg-emerald-500/20"
                          >
                            <ShieldCheck className="h-3.5 w-3.5" />
                            Resolve
                          </button>
                        )}
                        <button
                          onClick={() => setSelectedIncident(inc)}
                          className="rounded-lg border border-slate-700 bg-slate-800 px-3 py-1.5 text-[11px] font-bold text-white hover:bg-slate-700"
                        >
                          Inspect / Dispatch
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          <div className="lg:col-span-5 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-white">
                Live Campus Tactical Map
              </h3>
              <button
                onClick={() => setShowHeatmap(!showHeatmap)}
                className={`inline-flex items-center gap-1.5 rounded-lg border px-2.5 py-1 text-[11px] font-bold ${
                  showHeatmap
                    ? 'border-rose-500/40 bg-rose-500/15 text-rose-300'
                    : 'border-slate-700 bg-slate-900 text-slate-400'
                }`}
              >
                <Flame className="h-3.5 w-3.5" />
                {showHeatmap ? 'Heatmap ON' : 'Heatmap OFF'}
              </button>
            </div>
            <CampusMap
              locations={locations}
              safeCorridors={corridors}
              incidents={incidents}
              heatmapPoints={analytics?.heatmapPoints || []}
              showHeatmap={showHeatmap}
              heightClass="h-[460px]"
            />
          </div>
        </div>
      )}

      {/* TAB: FULL MAP VIEW */}
      {activeTab === 'map' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-white">
              Campus Incident &amp; Risk Heatmap
            </h2>
            <button
              onClick={() => setShowHeatmap(!showHeatmap)}
              className={`inline-flex items-center gap-1.5 rounded-xl border px-3.5 py-2 text-xs font-bold ${
                showHeatmap
                  ? 'border-rose-500/40 bg-rose-500/15 text-rose-300'
                  : 'border-slate-700 bg-slate-900 text-slate-300'
              }`}
            >
              <Flame className="h-4 w-4" />
              {showHeatmap ? 'Hide Heatmap Layer' : 'Show Heatmap Layer'}
            </button>
          </div>
          <CampusMap
            locations={locations}
            safeCorridors={corridors}
            incidents={incidents}
            heatmapPoints={analytics?.heatmapPoints || []}
            showHeatmap={showHeatmap}
            heightClass="h-[540px]"
          />
        </div>
      )}

      {/* TAB: ANALYTICS */}
      {activeTab === 'analytics' && <AnalyticsCharts analytics={analytics} />}

      {/* TAB: HISTORY TABLE */}
      {activeTab === 'history' && (
        <div className="glass-panel rounded-2xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="border-b border-slate-800 bg-slate-900/90 text-[11px] uppercase text-slate-400">
                <tr>
                  <th className="px-4 py-3">Code</th>
                  <th className="px-4 py-3">Category</th>
                  <th className="px-4 py-3">Severity</th>
                  <th className="px-4 py-3">Location</th>
                  <th className="px-4 py-3">Status</th>
                  <th className="px-4 py-3">Ack Time</th>
                  <th className="px-4 py-3">Responder</th>
                  <th className="px-4 py-3">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/70">
                {incidents.map((inc) => {
                  const sev = inc.aiAdjustedSeverity || inc.severity;
                  return (
                    <tr key={inc._id} className="hover:bg-slate-900/50">
                      <td className="px-4 py-3 font-mono font-bold text-cyan-300">
                        {inc.incidentCode}
                      </td>
                      <td className="px-4 py-3 text-white">{inc.emergencyType}</td>
                      <td className="px-4 py-3">
                        <span
                          className={`rounded-full border px-2 py-0.5 text-[10px] font-bold ${
                            SEVERITY_STYLES[sev]
                          }`}
                        >
                          {sev}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-slate-300">
                        {inc.location.label}
                      </td>
                      <td className="px-4 py-3">
                        <span
                          className={`rounded-full border px-2 py-0.5 text-[10px] font-bold uppercase ${
                            STATUS_STYLES[inc.status]
                          }`}
                        >
                          {inc.status}
                        </span>
                      </td>
                      <td className="px-4 py-3 font-mono text-slate-300">
                        {inc.metrics.ackTimeSeconds
                          ? `${inc.metrics.ackTimeSeconds}s`
                          : '—'}
                      </td>
                      <td className="px-4 py-3 text-slate-300">
                        {inc.escalation.assignedResponder || '—'}
                      </td>
                      <td className="px-4 py-3">
                        <button
                          onClick={() => setSelectedIncident(inc)}
                          className="text-cyan-400 hover:text-cyan-300 font-semibold"
                        >
                          Details
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB: NOTIFICATION LOGS */}
      {activeTab === 'notifications' && (
        <div className="glass-panel rounded-2xl p-5 space-y-3">
          <div className="flex items-center gap-2 text-sm font-bold text-white">
            <BellRing className="h-4 w-4 text-amber-400" />
            Multi-Channel Notification Audit Log (SMS, WhatsApp, Email)
          </div>
          <div className="space-y-3">
            {notifications.map((n) => (
              <div
                key={n._id}
                className="rounded-xl border border-slate-800 bg-slate-900/70 p-4 text-xs space-y-2"
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-cyan-300">
                      {n.incidentCode}
                    </span>
                    <span className="rounded bg-slate-800 px-2 py-0.5 font-mono text-[10px] uppercase text-white">
                      {n.channel}
                    </span>
                    <span className="font-semibold text-white">
                      {n.recipientName} ({n.recipientAddress})
                    </span>
                  </div>
                  <span className="font-mono text-[10px] text-emerald-300 uppercase">
                    {n.status} · {n.provider} · TIER {n.escalationLevel}
                  </span>
                </div>
                <pre className="rounded-lg bg-slate-950 p-3 font-mono text-[11px] text-slate-300 overflow-x-auto">
                  {n.messageBody}
                </pre>
              </div>
            ))}
          </div>
        </div>
      )}

      <IncidentDetailModal
        incident={selectedIncident}
        onClose={() => setSelectedIncident(null)}
        onAcknowledge={handleAcknowledge}
        onAssign={handleAssign}
        onEscalate={handleEscalate}
        onResolve={handleResolve}
      />
    </div>
  );
}
