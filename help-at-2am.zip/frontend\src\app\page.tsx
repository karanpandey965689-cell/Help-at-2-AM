'use client';

import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import {
  ShieldAlert,
  ArrowRight,
  Radio,
  Cpu,
  BellRing,
  MapPin,
  HeartHandshake,
  Clock,
  CheckCircle2,
  AlertOctagon,
  Lock,
} from 'lucide-react';
import { apiRequest } from '@/lib/api';
import { ReadinessMetrics } from '@/lib/types';
import { ReadinessGauge } from '@/components/emergency/ReadinessGauge';
import { EMERGENCY_CATEGORIES } from '@/lib/constants';

export default function LandingPage() {
  const [readiness, setReadiness] = useState<ReadinessMetrics | null>(null);

  useEffect(() => {
    apiRequest<ReadinessMetrics>('/campus/readiness')
      .then(setReadiness)
      .catch(() => {});
  }, []);

  const features = [
    {
      icon: Cpu,
      title: 'AI Triage & Guidance Engine',
      desc: 'Analyzes severity keywords, late-night isolation risk, and campus zone to compute instant protocols and dispatch routing.',
    },
    {
      icon: BellRing,
      title: 'Multi-Channel Admin Alerts',
      desc: 'Structured Student Assistance Requests dispatched concurrently via SMS, WhatsApp, Email, and live SSE Admin Command.',
    },
    {
      icon: Clock,
      title: 'Smart No-Response Escalation',
      desc: 'Autonomous SLA watchdog escalates unacknowledged Tier 1 incidents to Chief Security (Tier 2) and Dean Crisis Lead (Tier 3).',
    },
    {
      icon: MapPin,
      title: '4-Mode Campus Geolocation',
      desc: 'Report via Interactive OpenStreetMap pin, Hostel wing/room selector, Academic Building directory, or live device GPS.',
    },
  ];

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:py-14 space-y-16">
      {/* Hero Section */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45 }}
          className="lg:col-span-7 space-y-6"
        >
          <div className="inline-flex items-center gap-2 rounded-full border border-cyan-500/30 bg-cyan-500/10 px-3.5 py-1.5 text-xs font-semibold text-cyan-300">
            <Radio className="h-3.5 w-3.5 animate-pulse" />
            <span>24/7 UNIVERSITY CRISIS &amp; LATE-NIGHT RESPONSE SYSTEM</span>
          </div>

          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black tracking-tight text-white leading-[1.06]">
            Nobody navigates a{' '}
            <span className="bg-gradient-to-r from-rose-400 via-amber-300 to-cyan-400 bg-clip-text text-transparent">
              2 A.M. emergency
            </span>{' '}
            alone.
          </h1>

          <p className="max-w-2xl text-base sm:text-lg text-slate-300 leading-relaxed">
            Help at 2 A.M. is a mission-critical campus emergency reporting, immediate guidance, and multi-tier dispatch platform built for real university operations—connecting students to paramedics, patrol units, wardens, and counselors in seconds.
          </p>

          <div className="flex flex-wrap items-center gap-3.5 pt-1">
            <Link
              href="/emergency"
              className="inline-flex items-center gap-2 rounded-xl bg-cyan-500 px-6 py-3.5 text-sm font-bold text-slate-950 shadow-lg shadow-cyan-900/30 hover:bg-cyan-400 transition-all"
            >
              <ShieldAlert className="h-4 w-4" />
              Open Emergency Dashboard
              <ArrowRight className="h-4 w-4" />
            </Link>

            <Link
              href="/panic"
              className="inline-flex items-center gap-2 rounded-xl border border-rose-500/50 bg-rose-600/20 px-6 py-3.5 text-sm font-bold text-rose-200 hover:bg-rose-600/30 transition-all"
            >
              <AlertOctagon className="h-4 w-4 text-rose-400" />
              One-Click Panic Mode
            </Link>

            <Link
              href="/admin"
              className="inline-flex items-center gap-2 rounded-xl border border-slate-700 bg-slate-900/80 px-5 py-3.5 text-sm font-semibold text-slate-200 hover:bg-slate-800 transition-all"
            >
              <Lock className="h-4 w-4 text-amber-400" />
              Admin Command Console
            </Link>
          </div>

          <div className="flex flex-wrap items-center gap-6 pt-2 text-xs text-slate-400">
            <span className="inline-flex items-center gap-1.5">
              <CheckCircle2 className="h-4 w-4 text-emerald-400" />
              Instant Guidance Without Login Barrier
            </span>
            <span className="inline-flex items-center gap-1.5">
              <CheckCircle2 className="h-4 w-4 text-emerald-400" />
              SMS + WhatsApp + Email Dispatch
            </span>
            <span className="inline-flex items-center gap-1.5">
              <CheckCircle2 className="h-4 w-4 text-emerald-400" />
              Real-Time Incident Timeline
            </span>
          </div>
        </motion.div>

        {/* Live Telemetry Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="lg:col-span-5 space-y-4"
        >
          <ReadinessGauge readiness={readiness} />

          <div className="glass-panel rounded-2xl p-5 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Sample Admin Alert Dispatch Format
              </span>
              <span className="font-mono text-[10px] text-emerald-400">
                SMS · WHATSAPP · EMAIL
              </span>
            </div>
            <pre className="rounded-xl border border-slate-800 bg-[#04070f] p-3.5 font-mono text-[11px] leading-relaxed text-slate-300 overflow-x-auto">
{`Student Assistance Request

Type:
Medical Emergency

Location:
Aurora Residence Hall A (Floor 3)

Description:
Roommate collapsed with shortness of breath.

Time:
02:14:09 AM

Priority:
Critical`}
            </pre>
          </div>
        </motion.div>
      </section>

      {/* Supported Emergency Categories */}
      <section className="space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3">
          <div>
            <p className="font-mono text-xs uppercase tracking-widest text-cyan-400">
              Rapid Triage Matrix
            </p>
            <h2 className="text-2xl font-bold text-white mt-1">
              7 Dedicated Emergency Pathways
            </h2>
          </div>
          <Link
            href="/emergency"
            className="text-xs font-semibold text-cyan-400 hover:text-cyan-300 inline-flex items-center gap-1"
          >
            Report an incident now <ArrowRight className="h-3.5 w-3.5" />
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
          {EMERGENCY_CATEGORIES.map((cat) => (
            <Link
              key={cat.id}
              href={`/emergency?category=${encodeURIComponent(cat.id)}`}
              className="group glass-panel rounded-2xl p-4 hover:border-cyan-500/40 transition-all"
            >
              <div className="flex items-center justify-between">
                <span className="text-sm font-bold text-white group-hover:text-cyan-300 transition-colors">
                  {cat.id}
                </span>
                <span
                  className={`rounded-full border px-2 py-0.5 font-mono text-[10px] ${cat.badgeBg}`}
                >
                  {cat.defaultSeverity}
                </span>
              </div>
              <p className="mt-2 text-xs text-slate-400 leading-relaxed">
                {cat.tagline}
              </p>
            </Link>
          ))}

          <Link
            href="/mental-health"
            className="glass-panel rounded-2xl p-4 border-teal-500/30 bg-gradient-to-br from-teal-950/40 to-slate-900/80 hover:border-teal-400/60 transition-all"
          >
            <div className="flex items-center gap-2 text-teal-300 font-bold text-sm">
              <HeartHandshake className="h-4 w-4" />
              <span>2 A.M. Mental Health Sanctuary</span>
            </div>
            <p className="mt-2 text-xs text-slate-300 leading-relaxed">
              Guided breathing, grounding exercises, and confidential 24/7 counselor callback.
            </p>
          </Link>
        </div>
      </section>

      {/* Architecture Capabilities */}
      <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {features.map((feat) => {
          const Icon = feat.icon;
          return (
            <div key={feat.title} className="glass-panel rounded-2xl p-5 space-y-2.5">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl border border-cyan-500/30 bg-cyan-500/10 text-cyan-300">
                <Icon className="h-5 w-5" />
              </div>
              <h3 className="text-sm font-bold text-white">{feat.title}</h3>
              <p className="text-xs text-slate-400 leading-relaxed">{feat.desc}</p>
            </div>
          );
        })}
      </section>
    </div>
  );
}
