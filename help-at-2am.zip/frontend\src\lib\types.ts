export type UserRole = 'student' | 'responder' | 'admin' | 'super_admin';

export interface AuthUser {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  phone: string;
  studentId?: string;
  hostel?: string;
  department?: string;
  responderUnit?: string;
}

export type EmergencyCategory =
  | 'Medical Emergency'
  | 'Security Emergency'
  | 'Personal Safety'
  | 'Mental Health'
  | 'Hostel Problems'
  | 'Lost on Campus'
  | 'Other Emergency';

export type IncidentSeverity = 'Low' | 'Medium' | 'High' | 'Critical';
export type IncidentStatus = 'pending' | 'active' | 'escalated' | 'resolved';
export type LocationMethod = 'map' | 'hostel' | 'building' | 'gps';

export interface CampusLocationNode {
  id: string;
  name: string;
  code: string;
  type: 'hostel' | 'building' | 'medical' | 'security' | 'blue_light' | 'safe_zone';
  zone: string;
  coordinates: { lat: number; lng: number };
  floors?: string[];
  open24x7: boolean;
  riskWeight: number;
  nearestSafePoint: string;
  wardenOrContact?: string;
}

export interface SafeWalkCorridor {
  id: string;
  name: string;
  path: Array<[number, number]>;
  lightingStatus: string;
}

export interface GuidanceSnapshot {
  recommendedActions: string[];
  emergencySteps: string[];
  contactSuggestions: Array<{
    name: string;
    role: string;
    phone: string;
    available24x7: boolean;
    priority: 'primary' | 'secondary' | 'external';
  }>;
  escalationFlow: Array<{
    level: number;
    targetRole: string;
    slaSeconds: number;
    action: string;
  }>;
}

export interface TimelineEvent {
  _id?: string;
  eventType: string;
  title: string;
  description: string;
  actorName: string;
  actorRole: string;
  timestamp: string;
  metadata?: Record<string, unknown>;
}

export interface IncidentRecord {
  _id: string;
  incidentCode: string;
  reporterName: string;
  isAnonymous: boolean;
  isPanicMode: boolean;
  emergencyType: EmergencyCategory;
  severity: IncidentSeverity;
  aiAdjustedSeverity: IncidentSeverity;
  status: IncidentStatus;
  description: string;
  contactNumber: string;
  location: {
    method: LocationMethod;
    label: string;
    zone: string;
    nodeId?: string;
    floorOrRoom?: string;
    coordinates: { lat: number; lng: number };
    gpsAccuracyMeters?: number;
  };
  aiTriage: {
    riskScore: number;
    confidence: number;
    detectedSignals: string[];
    recommendedUnit: string;
    routingTier: number;
    reasoning: string;
  };
  guidance: GuidanceSnapshot;
  escalation: {
    currentLevel: 1 | 2 | 3;
    maxLevel: number;
    nextEscalationAt?: string;
    escalatedCount: number;
    autoEscalated: boolean;
    assignedResponder?: string;
    assignedAdminName?: string;
  };
  metrics: {
    acknowledgedAt?: string;
    dispatchedAt?: string;
    resolvedAt?: string;
    ackTimeSeconds?: number;
    resolveTimeSeconds?: number;
  };
  timeline: TimelineEvent[];
  createdAt: string;
  updatedAt: string;
}

export interface ReadinessMetrics {
  score: number;
  grade: 'Optimal' | 'Guarded' | 'Elevated' | 'Strain';
  factors: {
    responderCoverage: number;
    slaCompliance: number;
    channelHealth: number;
    incidentLoadFactor: number;
  };
  liveSnapshot: {
    pendingCount: number;
    activeCount: number;
    escalatedCount: number;
    resolvedTodayCount: number;
    avgAckSeconds: number;
    avgResolveSeconds: number;
    patrolUnitsActive: number;
    medicalStaffOnDuty: number;
    counselorAvailable: boolean;
  };
}

export interface NotificationLogItem {
  _id: string;
  incidentId: string;
  incidentCode: string;
  channel: 'sms' | 'whatsapp' | 'email';
  recipientName: string;
  recipientRole: string;
  recipientAddress: string;
  escalationLevel: 1 | 2 | 3;
  messageBody: string;
  status: 'sent' | 'simulated' | 'failed';
  provider: string;
  providerMessageId?: string;
  createdAt: string;
}

export interface AdminContactRecipient {
  _id?: string;
  name: string;
  role: string;
  level: 1 | 2 | 3;
  smsPhone: string;
  whatsappPhone: string;
  email: string;
  categories: string[];
  active: boolean;
}

export interface AdminSettingsData {
  campusName: string;
  channels: {
    smsEnabled: boolean;
    whatsappEnabled: boolean;
    emailEnabled: boolean;
  };
  slaSeconds: {
    Critical: number;
    High: number;
    Medium: number;
    Low: number;
  };
  escalationEnabled: boolean;
  readinessConfig: {
    patrolUnitsActive: number;
    medicalStaffOnDuty: number;
    counselorAvailable: boolean;
  };
  recipients: AdminContactRecipient[];
}
