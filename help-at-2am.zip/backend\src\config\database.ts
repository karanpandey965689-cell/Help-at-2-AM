import mongoose from 'mongoose';
import { MongoMemoryServer } from 'mongodb-memory-server';
import { env } from './env.js';

let memoryServer: MongoMemoryServer | null = null;
let usingInMemory = false;

export function isUsingInMemoryDb(): boolean {
  return usingInMemory;
}

export async function connectDatabase(): Promise<void> {
  if (mongoose.connection.readyState === 1) {
    return;
  }

  if (env.useInMemoryDb) {
    memoryServer = await MongoMemoryServer.create();
    const uri = memoryServer.getUri();
    await mongoose.connect(uri);
    usingInMemory = true;
    console.log(`[DB] Connected to in-memory MongoDB at ${uri}`);
    return;
  }

  try {
    await mongoose.connect(env.mongodbUri, {
      serverSelectionTimeoutMS: 4000,
    });
    usingInMemory = false;
    console.log(`[DB] Connected to MongoDB: ${env.mongodbUri}`);
  } catch (err) {
    if (env.nodeEnv !== 'production') {
      console.warn(
        '[DB] Primary MongoDB unavailable in non-production mode; falling back to MongoMemoryServer...'
      );
      memoryServer = await MongoMemoryServer.create();
      const uri = memoryServer.getUri();
      await mongoose.connect(uri);
      usingInMemory = true;
      console.log(`[DB] Connected to fallback in-memory MongoDB at ${uri}`);
    } else {
      throw err;
    }
  }
}

export async function disconnectDatabase(): Promise<void> {
  await mongoose.disconnect();
  if (memoryServer) {
    await memoryServer.stop();
    memoryServer = null;
  }
}
