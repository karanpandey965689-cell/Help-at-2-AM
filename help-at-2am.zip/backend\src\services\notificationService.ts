import twilio from 'twilio';
import nodemailer from 'nodemailer';
import { env } from '../config/env.js';
import { IIncident } from '../models/Incident.js';
import {
  getOrCreateAdminSettings,
  IAdminContactRecipient,
} from '../models/AdminSettings.js';
import {
  NotificationChannel,
  NotificationLog,
} from '../models/NotificationLog.js';

export function formatAlertMessage(
  incident: IIncident,
  escalationNote?: string
): string {
  const formattedTime = new Date(incident.createdAt || Date.now()).toLocaleString(
    'en-US',
    {
      year: 'numeric',
      month: 'short',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true,
    }
  );

  const locationDisplay = incident.location.floorOrRoom
    ? `${incident.location.label} (${incident.location.floorOrRoom}) — ${incident.location.zone}`
    : `${incident.location.label} — ${incident.location.zone}`;

  const lines = [
    'Student Assistance Request',
    '',
    'Type:',
    incident.emergencyType,
    '',
    'Location:',
    locationDisplay,
    '',
    'Description:',
    incident.description,
    '',
    'Time:',
    formattedTime,
    '',
    'Priority:',
    incident.aiAdjustedSeverity || incident.severity,
  ];

  if (escalationNote) {
    lines.push('', `Alert Context: ${escalationNote} | Code: ${incident.incidentCode} | Callback: ${incident.contactNumber}`);
  } else {
    lines.push('', `Incident Code: ${incident.incidentCode} | Callback: ${incident.contactNumber}`);
  }

  return lines.join('\n');
}

async function sendViaSms(
  to: string,
  body: string
): Promise<{ status: 'sent' | 'simulated' | 'failed'; provider: string; id?: string; error?: string }> {
  if (env.twilio.accountSid && env.twilio.authToken && env.twilio.smsFrom) {
    try {
      const client = twilio(env.twilio.accountSid, env.twilio.authToken);
      const msg = await client.messages.create({
        from: env.twilio.smsFrom,
        to,
        body,
      });
      return { status: 'sent', provider: 'twilio-sms', id: msg.sid };
    } catch (err) {
      return {
        status: 'failed',
        provider: 'twilio-sms',
        error: err instanceof Error ? err.message : 'Twilio SMS error',
      };
    }
  }
  return {
    status: 'simulated',
    provider: 'twilio-sms-sandbox',
    id: `SIM-SMS-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
  };
}

async function sendViaWhatsApp(
  to: string,
  body: string
): Promise<{ status: 'sent' | 'simulated' | 'failed'; provider: string; id?: string; error?: string }> {
  if (env.twilio.accountSid && env.twilio.authToken && env.twilio.whatsappFrom) {
    try {
      const client = twilio(env.twilio.accountSid, env.twilio.authToken);
      const formattedTo = to.startsWith('whatsapp:') ? to : `whatsapp:${to}`;
      const msg = await client.messages.create({
        from: env.twilio.whatsappFrom,
        to: formattedTo,
        body,
      });
      return { status: 'sent', provider: 'twilio-whatsapp', id: msg.sid };
    } catch (err) {
      return {
        status: 'failed',
        provider: 'twilio-whatsapp',
        error: err instanceof Error ? err.message : 'Twilio WhatsApp error',
      };
    }
  }
  return {
    status: 'simulated',
    provider: 'whatsapp-cloud-sandbox',
    id: `SIM-WA-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
  };
}

async function sendViaEmail(
  to: string,
  subject: string,
  body: string
): Promise<{ status: 'sent' | 'simulated' | 'failed'; provider: string; id?: string; error?: string }> {
  if (env.smtp.host && env.smtp.user && env.smtp.pass) {
    try {
      const transporter = nodemailer.createTransport({
        host: env.smtp.host,
        port: env.smtp.port,
        secure: env.smtp.secure,
        auth: { user: env.smtp.user, pass: env.smtp.pass },
      });
      const info = await transporter.sendMail({
        from: env.smtp.from,
        to,
        subject,
        text: body,
      });
      return { status: 'sent', provider: 'smtp-nodemailer', id: info.messageId };
    } catch (err) {
      return {
        status: 'failed',
        provider: 'smtp-nodemailer',
        error: err instanceof Error ? err.message : 'SMTP delivery error',
      };
    }
  }
  return {
    status: 'simulated',
    provider: 'smtp-sandbox',
    id: `SIM-MAIL-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
  };
}

export function selectRecipientsForLevel(
  recipients: IAdminContactRecipient[],
  level: 1 | 2 | 3,
  category: string,
  includeLowerLevels = false
): IAdminContactRecipient[] {
  const matched = recipients.filter((r) => {
    if (!r.active) return false;
    const levelMatch = includeLowerLevels ? r.level <= level : r.level === level;
    const categoryMatch =
      !r.categories ||
      r.categories.length === 0 ||
      r.categories.includes(category);
    return levelMatch && categoryMatch;
  });

  if (matched.length > 0) return matched;
  return recipients.filter((r) => r.active && r.level === level);
}

export async function dispatchIncidentAlerts(
  incident: IIncident,
  targetLevel: 1 | 2 | 3,
  options?: { includeLowerLevels?: boolean; escalationNote?: string }
): Promise<{
  messageBody: string;
  dispatchedCount: number;
  channelsUsed: NotificationChannel[];
}> {
  const settings = await getOrCreateAdminSettings();
  const messageBody = formatAlertMessage(incident, options?.escalationNote);
  const recipients = selectRecipientsForLevel(
    settings.recipients,
    targetLevel,
    incident.emergencyType,
    options?.includeLowerLevels ?? false
  );

  const channelsUsed = new Set<NotificationChannel>();
  let dispatchedCount = 0;

  for (const recipient of recipients) {
    if (settings.channels.smsEnabled && recipient.smsPhone) {
      const res = await sendViaSms(recipient.smsPhone, messageBody);
      await NotificationLog.create({
        incidentId: incident._id,
        incidentCode: incident.incidentCode,
        channel: 'sms',
        recipientName: recipient.name,
        recipientRole: recipient.role,
        recipientAddress: recipient.smsPhone,
        escalationLevel: targetLevel,
        messageBody,
        status: res.status,
        provider: res.provider,
        providerMessageId: res.id,
        errorMessage: res.error,
      });
      channelsUsed.add('sms');
      dispatchedCount++;
    }

    if (settings.channels.whatsappEnabled && recipient.whatsappPhone) {
      const res = await sendViaWhatsApp(recipient.whatsappPhone, messageBody);
      await NotificationLog.create({
        incidentId: incident._id,
        incidentCode: incident.incidentCode,
        channel: 'whatsapp',
        recipientName: recipient.name,
        recipientRole: recipient.role,
        recipientAddress: recipient.whatsappPhone,
        escalationLevel: targetLevel,
        messageBody,
        status: res.status,
        provider: res.provider,
        providerMessageId: res.id,
        errorMessage: res.error,
      });
      channelsUsed.add('whatsapp');
      dispatchedCount++;
    }

    if (settings.channels.emailEnabled && recipient.email) {
      const subject = `[${incident.aiAdjustedSeverity}] ${incident.emergencyType} — ${incident.incidentCode}`;
      const res = await sendViaEmail(recipient.email, subject, messageBody);
      await NotificationLog.create({
        incidentId: incident._id,
        incidentCode: incident.incidentCode,
        channel: 'email',
        recipientName: recipient.name,
        recipientRole: recipient.role,
        recipientAddress: recipient.email,
        escalationLevel: targetLevel,
        messageBody,
        status: res.status,
        provider: res.provider,
        providerMessageId: res.id,
        errorMessage: res.error,
      });
      channelsUsed.add('email');
      dispatchedCount++;
    }
  }

  return {
    messageBody,
    dispatchedCount,
    channelsUsed: Array.from(channelsUsed),
  };
}
