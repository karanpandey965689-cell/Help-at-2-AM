'use client';

import React, { Suspense, useEffect, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import {
  Send,
  AlertOctagon,
  Clock,
  ShieldCheck,
  Loader2,
  EyeOff,
  Phone,
  ArrowRight,
} from 'lucide-react';
import { apiRequest } from '@/lib/api';
import { useAuth } from '@/lib/authContext';
import {
  CampusLocationNode,
  EmergencyCategory,
  GuidanceSnapshot,
  IncidentRecord,
  IncidentSeverity,
  ReadinessMetrics,
  SafeWalkCorridor,
} from '@/lib/types';
import { EMERGENCY_CATEGORIES, SEVERITY_STYLES, STATUS_STYLES } from '@/lib/constants';
import { CategorySelector } from '@/components/emergency/CategorySelector';
import {
  LocationSelector,
  SelectedLocationValue,
} from '@/components/emergency/LocationSelector';
import { GuidancePanel } from '@/components/emergency/GuidancePanel';
import { ReadinessGauge } from '@/components/emergency/ReadinessGauge';

function EmergencyDashboardInner() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { user } = useAuth();

  const initialCat = (searchParams.get('category') as EmergencyCategory) || 'Medical Emergency';
  const [category, setCategory] = useState<EmergencyCategory>(
    EMERGENCY_CATEGORIES.some((c) => c.id === initialCat)
      ? initialCat
      : 'Medical Emergency'
  );
  const [severity, setSeverity] = useState<IncidentSeverity>('High');
  const [description, setDescription] = useState('');
  const [contactNumber, setContactNumber] = useState(user?.phone || '+1-555-0142');
  const [isAnonymous, setIsAnonymous] = useState(false);

  const [locations, setLocations] = useState<CampusLocationNode[]>([]);
  const [safeCorridors, setSafeCorridors] = useState<SafeWalkCorridor[]>([]);
  const [readiness, setReadiness] = useState<ReadinessMetrics | null>(null);
  const [myIncidents, setMyIncidents] = useState<IncidentRecord[]>([]);

  const [locationVal, setLocationVal] = useState<SelectedLocationValue>({
    method: 'hostel',
    label: 'Aurora Residence Hall A (North)',
    zone: 'North Residential Quad',
    nodeId: 'hostel-aurora-a',
    floorOrRoom: '',
    coordinates: { lat: 37.4314, lng: -122.1728 },
  });

  const [liveGuidance, setLiveGuidance] = useState<GuidanceSnapshot | null>(null);
  const [liveTriage, setLiveTriage] = useState<{
    riskScore: number;
    recommendedUnit: string;
    detectedSignals: string[];
    reasoning: string;
  } | null>(null);

  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (user?.phone) setContactNumber(user.phone);
  }, [user]);

  useEffect(() => {
    apiRequest<{
      locations: CampusLocationNode[];
      safeWalkCorridors: SafeWalkCorridor[];
    }>('/campus/locations')
      .then((res) => {
        setLocations(res.locations);
        setSafeCorridors(res.safeWalkCorridors);
      })
      .catch(() => {});

    apiRequest<ReadinessMetrics>('/campus/readiness')
      .then(setReadiness)
      .catch(() => {});
  }, []);

  useEffect(() => {
    if (user) {
      apiRequest<{ incidents: IncidentRecord[] }>('/incidents/my')
        .then((res) => setMyIncidents(res.incidents))
        .catch(() => {});
    }
  }, [user]);

  // Live Immediate Guidance + AI Decision Engine preview whenever inputs change
  useEffect(() => {
    const timer = setTimeout(() => {
      apiRequest<{
        triage: {
          riskScore: number;
          recommendedUnit: string;
          detectedSignals: string[];
          reasoning: string;
          guidance: GuidanceSnapshot;
        };
      }>('/guidance/evaluate', {
        method: 'POST',
        body: JSON.stringify({
          emergencyType: category,
          severity,
          description,
          locationNodeId: locationVal.nodeId,
        }),
      })
        .then((res) => {
          setLiveGuidance(res.triage.guidance);
          setLiveTriage({
            riskScore: res.triage.riskScore,
            recommendedUnit: res.triage.recommendedUnit,
            detectedSignals: res.triage.detectedSignals,
            reasoning: res.triage.reasoning,
          });
        })
        .catch(() => {});
    }, 220);

    return () => clearTimeout(timer);
  }, [category, severity, description, locationVal.nodeId]);

  const handleCategoryChange = (cat: EmergencyCategory) => {
    setCategory(cat);
    const meta = EMERGENCY_CATEGORIES.find((c) => c.id === cat);
    if (meta) setSeverity(meta.defaultSeverity);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSubmitting(true);
    try {
      const res = await apiRequest<{ incident: IncidentRecord }>('/incidents', {
        method: 'POST',
        body: JSON.stringify({
          emergencyType: category,
          severity,
          description,
          contactNumber,
          isAnonymous,
          location: locationVal,
        }),
      });
      router.push(`/incidents/${res.incident._id}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to submit report');
      setSubmitting(false);
    }
  };

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 space-y-8">
      {/* Header Banner */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-5 rounded-3xl border border-slate-800 bg-slate-900/70 p-6">
        <div className="space-y-1.5">
          <div className="inline-flex items-center gap-2 font-mono text-xs uppercase tracking-wider text-cyan-400">
            <ShieldCheck className="h-4 w-4" />
            Student Emergency Command &amp; Guidance Dashboard
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white">
            Report an Incident &amp; Get Immediate Guidance
          </h1>
          <p className="text-xs sm:text-sm text-slate-400">
            Select your situation below—our AI Decision Engine adapts instructions instantly and dispatches campus responders on submit.
          </p>
        </div>

        <Link
          href="/panic"
          className="inline-flex items-center justify-center gap-2.5 rounded-2xl bg-rose-600 px-6 py-4 text-sm font-black uppercase tracking-wide text-white shadow-xl shadow-rose-950/50 hover:bg-rose-500 transition-all shrink-0 border border-rose-400/40"
        >
          <AlertOctagon className="h-5 w-5 animate-pulse" />
          In Immediate Danger? Trigger Panic Mode
        </Link>
      </div>

      {/* Main Split Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-7 items-start">
        {/* Left: Report Form */}
        <form onSubmit={handleSubmit} className="lg:col-span-7 space-y-7">
          {/* Step 1: Category */}
          <section className="glass-panel rounded-3xl p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-bold text-white">
                1. Emergency Category
              </h2>
              <span className="font-mono text-xs text-cyan-400">{category}</span>
            </div>
            <CategorySelector selected={category} onSelect={handleCategoryChange} />
          </section>

          {/* Step 2: Location */}
          <section className="glass-panel rounded-3xl p-6 space-y-4">
            <h2 className="text-base font-bold text-white">
              2. Select Location (Hostel, Building, Map Pin, or GPS)
            </h2>
            <LocationSelector
              locations={locations}
              safeCorridors={safeCorridors}
              value={locationVal}
              onChange={setLocationVal}
            />
          </section>

          {/* Step 3: Details & Submit */}
          <section className="glass-panel rounded-3xl p-6 space-y-5">
            <h2 className="text-base font-bold text-white">
              3. Severity, Situation Description &amp; Callback
            </h2>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-2">
                Severity Level
              </label>
              <div className="grid grid-cols-4 gap-2">
                {(['Low', 'Medium', 'High', 'Critical'] as IncidentSeverity[]).map(
                  (sev) => (
                    <button
                      key={sev}
                      type="button"
                      onClick={() => setSeverity(sev)}
                      className={`rounded-xl border py-2.5 text-xs font-bold transition-all ${
                        severity === sev
                          ? SEVERITY_STYLES[sev] + ' ring-1 ring-white/30'
                          : 'border-slate-800 bg-slate-900/70 text-slate-400 hover:text-white'
                      }`}
                    >
                      {sev}
                    </button>
                  )
                )}
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                What is happening right now?
              </label>
              <textarea
                required
                minLength={5}
                rows={4}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Describe symptoms, threat details, people involved, or exact building hazard..."
                className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3.5 py-3 text-sm text-white placeholder:text-slate-500 focus:border-cyan-400 focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-end">
              <div>
                <label className="flex items-center gap-1.5 text-xs font-semibold text-slate-300 mb-1.5">
                  <Phone className="h-3.5 w-3.5 text-cyan-400" />
                  Callback Contact Number
                </label>
                <input
                  required
                  value={contactNumber}
                  onChange={(e) => setContactNumber(e.target.value)}
                  placeholder="+1-555-0142"
                  className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3.5 py-2.5 text-sm text-white focus:border-cyan-400 focus:outline-none"
                />
              </div>

              <label className="flex items-center gap-2.5 rounded-xl border border-slate-800 bg-slate-900/60 px-3.5 py-2.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={isAnonymous}
                  onChange={(e) => setIsAnonymous(e.target.checked)}
                  className="h-4 w-4 rounded border-slate-600 bg-slate-950 text-cyan-500"
                />
                <div className="flex items-center gap-1.5 text-xs text-slate-300">
                  <EyeOff className="h-3.5 w-3.5 text-slate-400" />
                  <span>Submit Anonymously</span>
                </div>
              </label>
            </div>

            {error && (
              <p className="rounded-xl border border-rose-500/40 bg-rose-500/10 px-4 py-2.5 text-xs text-rose-300">
                {error}
              </p>
            )}

            <button
              type="submit"
              disabled={submitting}
              className="flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-cyan-500 to-emerald-500 py-4 text-sm font-black uppercase tracking-wide text-slate-950 shadow-lg shadow-cyan-950/40 hover:brightness-110 transition-all disabled:opacity-60"
            >
              {submitting ? (
                <Loader2 className="h-5 w-5 animate-spin" />
              ) : (
                <Send className="h-5 w-5" />
              )}
              {submitting
                ? 'Dispatching SMS, WhatsApp & Command Alerts...'
                : 'Submit Emergency Request & Dispatch Help'}
            </button>
          </section>
        </form>

        {/* Right: Immediate Guidance Engine + Readiness + Recent */}
        <aside className="lg:col-span-5 space-y-5">
          <ReadinessGauge readiness={readiness} compact />

          <div className="space-y-2">
            <h2 className="text-sm font-bold uppercase tracking-wider text-slate-300">
              Immediate Guidance Engine (Live Preview)
            </h2>
            <GuidancePanel guidance={liveGuidance} triage={liveTriage} />
          </div>

          {myIncidents.length > 0 && (
            <div className="glass-panel rounded-2xl p-5 space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Clock className="h-4 w-4 text-cyan-400" />
                  Your Recent Reports
                </h3>
              </div>
              <div className="space-y-2">
                {myIncidents.slice(0, 4).map((inc) => (
                  <Link
                    key={inc._id}
                    href={`/incidents/${inc._id}`}
                    className="flex items-center justify-between gap-2 rounded-xl border border-slate-800 bg-slate-900/70 p-3 hover:border-cyan-500/40 transition-colors"
                  >
                    <div>
                      <p className="font-mono text-xs font-bold text-white">
                        {inc.incidentCode} · {inc.emergencyType}
                      </p>
                      <p className="text-[11px] text-slate-400 truncate max-w-[230px]">
                        {inc.location.label}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <span
                        className={`rounded-full border px-2 py-0.5 text-[10px] font-bold uppercase ${
                          STATUS_STYLES[inc.status]
                        }`}
                      >
                        {inc.status}
                      </span>
                      <ArrowRight className="h-3.5 w-3.5 text-slate-400" />
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          )}
        </aside>
      </div>
    </div>
  );
}

export default function EmergencyDashboardPage() {
  return (
    <Suspense
      fallback={
        <div className="mx-auto max-w-7xl px-6 py-12 text-sm text-slate-400">
          Loading Emergency Command Dashboard...
        </div>
      }
    >
      <EmergencyDashboardInner />
    </Suspense>
  );
}
