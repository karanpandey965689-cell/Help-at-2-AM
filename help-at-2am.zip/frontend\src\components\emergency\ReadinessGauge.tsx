'use client';

import React from 'react';
import { Activity, ShieldCheck, Radio, Clock } from 'lucide-react';
import { ReadinessMetrics } from '@/lib/types';

export function ReadinessGauge({
  readiness,
  compact = false,
}: {
  readiness: ReadinessMetrics | null;
  compact?: boolean;
}) {
  if (!readiness) {
    return (
      <div className="glass-panel rounded-2xl p-5 animate-pulse">
        <div className="h-5 w-40 bg-slate-800 rounded mb-3" />
        <div className="h-16 bg-slate-800/70 rounded" />
      </div>
    );
  }

  const gradeColors: Record<ReadinessMetrics['grade'], string> = {
    Optimal: 'text-emerald-400 border-emerald-500/40 bg-emerald-500/10',
    Guarded: 'text-cyan-400 border-cyan-500/40 bg-cyan-500/10',
    Elevated: 'text-amber-400 border-amber-500/40 bg-amber-500/10',
    Strain: 'text-rose-400 border-rose-500/40 bg-rose-500/10',
  };

  const ringColor =
    readiness.score >= 85
      ? '#10b981'
      : readiness.score >= 70
      ? '#06b6d4'
      : readiness.score >= 55
      ? '#f59e0b'
      : '#f43f5e';

  return (
    <div className="glass-panel rounded-2xl p-5">
      <div className="flex items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-slate-400">
            <Activity className="h-3.5 w-3.5 text-cyan-400" />
            Emergency Readiness Score
          </div>
          <div className="mt-2 flex items-baseline gap-3">
            <span className="font-mono text-4xl font-bold text-white">
              {readiness.score}
            </span>
            <span className="text-sm text-slate-400">/ 100</span>
            <span
              className={`inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold ${
                gradeColors[readiness.grade]
              }`}
            >
              {readiness.grade}
            </span>
          </div>
        </div>

        <div className="relative h-16 w-16 shrink-0">
          <svg viewBox="0 0 36 36" className="h-16 w-16 -rotate-90">
            <path
              d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
              fill="none"
              stroke="rgba(148,163,184,0.16)"
              strokeWidth="3.2"
            />
            <path
              d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
              fill="none"
              stroke={ringColor}
              strokeWidth="3.2"
              strokeDasharray={`${readiness.score}, 100`}
              strokeLinecap="round"
            />
          </svg>
          <ShieldCheck className="absolute inset-0 m-auto h-5 w-5 text-slate-200" />
        </div>
      </div>

      {!compact && (
        <>
          <div className="mt-4 grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs">
            <div className="rounded-xl bg-slate-900/70 border border-slate-800 p-2.5">
              <p className="text-slate-400">Responder Cov.</p>
              <p className="font-mono text-sm font-bold text-white mt-0.5">
                {readiness.factors.responderCoverage}%
              </p>
            </div>
            <div className="rounded-xl bg-slate-900/70 border border-slate-800 p-2.5">
              <p className="text-slate-400">SLA Adherence</p>
              <p className="font-mono text-sm font-bold text-white mt-0.5">
                {readiness.factors.slaCompliance}%
              </p>
            </div>
            <div className="rounded-xl bg-slate-900/70 border border-slate-800 p-2.5">
              <p className="text-slate-400">Alert Channels</p>
              <p className="font-mono text-sm font-bold text-emerald-400 mt-0.5">
                {readiness.factors.channelHealth}%
              </p>
            </div>
            <div className="rounded-xl bg-slate-900/70 border border-slate-800 p-2.5">
              <p className="text-slate-400">Load Capacity</p>
              <p className="font-mono text-sm font-bold text-cyan-400 mt-0.5">
                {readiness.factors.incidentLoadFactor}%
              </p>
            </div>
          </div>

          <div className="mt-3 flex flex-wrap items-center justify-between gap-2 border-t border-slate-800/80 pt-3 text-xs text-slate-400">
            <span className="inline-flex items-center gap-1.5">
              <Radio className="h-3.5 w-3.5 text-emerald-400" />
              {readiness.liveSnapshot.patrolUnitsActive} Patrols ·{' '}
              {readiness.liveSnapshot.medicalStaffOnDuty} Medics Active
            </span>
            <span className="inline-flex items-center gap-1.5 font-mono">
              <Clock className="h-3.5 w-3.5 text-cyan-400" />
              Avg Ack: {readiness.liveSnapshot.avgAckSeconds}s
            </span>
          </div>
        </>
      )}
    </div>
  );
}
