import type { Metadata } from 'next';
import './globals.css';
import { AuthProvider } from '@/lib/authContext';
import { Navbar } from '@/components/layout/Navbar';
import { Footer } from '@/components/layout/Footer';

export const metadata: Metadata = {
  title: 'Help at 2 A.M. | Campus Emergency Guidance & Response System',
  description:
    'Production-grade university late-night emergency reporting, AI-driven immediate guidance, multi-channel alert dispatch, and live operations command.',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark">
      <body className="min-h-screen flex flex-col bg-[#050811] text-slate-100 antialiased selection:bg-cyan-500/30 selection:text-cyan-200">
        <AuthProvider>
          <Navbar />
          <main className="flex-1 command-grid-bg">{children}</main>
          <Footer />
        </AuthProvider>
      </body>
    </html>
  );
}
